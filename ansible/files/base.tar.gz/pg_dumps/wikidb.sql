--
-- PostgreSQL database dump
--

\restrict aCtPEEPC3d6vAsj1aAPCi0mV0bQGyzdjruwXBNUfAOyiUketlfPeay9gM3eGnEr

-- Dumped from database version 18.3 (Ubuntu 18.3-1.pgdg24.04+1)
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: analytics; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.analytics (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    config json NOT NULL
);


ALTER TABLE public.analytics OWNER TO wiki;

--
-- Name: apiKeys; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."apiKeys" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    key text NOT NULL,
    expiration character varying(255) NOT NULL,
    "isRevoked" boolean DEFAULT false NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL
);


ALTER TABLE public."apiKeys" OWNER TO wiki;

--
-- Name: apiKeys_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."apiKeys_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."apiKeys_id_seq" OWNER TO wiki;

--
-- Name: apiKeys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."apiKeys_id_seq" OWNED BY public."apiKeys".id;


--
-- Name: assetData; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."assetData" (
    id integer NOT NULL,
    data bytea NOT NULL
);


ALTER TABLE public."assetData" OWNER TO wiki;

--
-- Name: assetFolders; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."assetFolders" (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    "parentId" integer
);


ALTER TABLE public."assetFolders" OWNER TO wiki;

--
-- Name: assetFolders_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."assetFolders_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."assetFolders_id_seq" OWNER TO wiki;

--
-- Name: assetFolders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."assetFolders_id_seq" OWNED BY public."assetFolders".id;


--
-- Name: assets; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    hash character varying(255) NOT NULL,
    ext character varying(255) NOT NULL,
    kind text DEFAULT 'binary'::text NOT NULL,
    mime character varying(255) DEFAULT 'application/octet-stream'::character varying NOT NULL,
    "fileSize" integer,
    metadata json,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL,
    "folderId" integer,
    "authorId" integer,
    CONSTRAINT assets_kind_check CHECK ((kind = ANY (ARRAY['binary'::text, 'image'::text])))
);


ALTER TABLE public.assets OWNER TO wiki;

--
-- Name: COLUMN assets."fileSize"; Type: COMMENT; Schema: public; Owner: wiki
--

COMMENT ON COLUMN public.assets."fileSize" IS 'In kilobytes';


--
-- Name: assets_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.assets_id_seq OWNER TO wiki;

--
-- Name: assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.assets_id_seq OWNED BY public.assets.id;


--
-- Name: authentication; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.authentication (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    config json NOT NULL,
    "selfRegistration" boolean DEFAULT false NOT NULL,
    "domainWhitelist" json NOT NULL,
    "autoEnrollGroups" json NOT NULL,
    "order" integer DEFAULT 0 NOT NULL,
    "strategyKey" character varying(255) DEFAULT ''::character varying NOT NULL,
    "displayName" character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.authentication OWNER TO wiki;

--
-- Name: brute; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.brute (
    key character varying(255),
    "firstRequest" bigint,
    "lastRequest" bigint,
    lifetime bigint,
    count integer
);


ALTER TABLE public.brute OWNER TO wiki;

--
-- Name: commentProviders; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."commentProviders" (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    config json NOT NULL
);


ALTER TABLE public."commentProviders" OWNER TO wiki;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.comments (
    id integer NOT NULL,
    content text NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL,
    "pageId" integer,
    "authorId" integer,
    render text DEFAULT ''::text NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    ip character varying(255) DEFAULT ''::character varying NOT NULL,
    "replyTo" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.comments OWNER TO wiki;

--
-- Name: comments_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.comments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.comments_id_seq OWNER TO wiki;

--
-- Name: comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.comments_id_seq OWNED BY public.comments.id;


--
-- Name: editors; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.editors (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    config json NOT NULL
);


ALTER TABLE public.editors OWNER TO wiki;

--
-- Name: groups; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.groups (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    permissions json NOT NULL,
    "pageRules" json NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL,
    "redirectOnLogin" character varying(255) DEFAULT '/'::character varying NOT NULL
);


ALTER TABLE public.groups OWNER TO wiki;

--
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.groups_id_seq OWNER TO wiki;

--
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- Name: locales; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.locales (
    code character varying(5) NOT NULL,
    strings json,
    "isRTL" boolean DEFAULT false NOT NULL,
    name character varying(255) NOT NULL,
    "nativeName" character varying(255) NOT NULL,
    availability integer DEFAULT 0 NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL
);


ALTER TABLE public.locales OWNER TO wiki;

--
-- Name: loggers; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.loggers (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    level character varying(255) DEFAULT 'warn'::character varying NOT NULL,
    config json
);


ALTER TABLE public.loggers OWNER TO wiki;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


ALTER TABLE public.migrations OWNER TO wiki;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_id_seq OWNER TO wiki;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: migrations_lock; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


ALTER TABLE public.migrations_lock OWNER TO wiki;

--
-- Name: migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.migrations_lock_index_seq OWNER TO wiki;

--
-- Name: migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.migrations_lock_index_seq OWNED BY public.migrations_lock.index;


--
-- Name: navigation; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.navigation (
    key character varying(255) NOT NULL,
    config json
);


ALTER TABLE public.navigation OWNER TO wiki;

--
-- Name: pageHistory; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."pageHistory" (
    id integer NOT NULL,
    path character varying(255) NOT NULL,
    hash character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    description character varying(255),
    "isPrivate" boolean DEFAULT false NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "publishStartDate" character varying(255),
    "publishEndDate" character varying(255),
    action character varying(255) DEFAULT 'updated'::character varying,
    "pageId" integer,
    content text,
    "contentType" character varying(255) NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "editorKey" character varying(255),
    "localeCode" character varying(5),
    "authorId" integer,
    "versionDate" character varying(255) DEFAULT ''::character varying NOT NULL,
    extra json DEFAULT '{}'::json NOT NULL
);


ALTER TABLE public."pageHistory" OWNER TO wiki;

--
-- Name: pageHistoryTags; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."pageHistoryTags" (
    id integer NOT NULL,
    "pageId" integer,
    "tagId" integer
);


ALTER TABLE public."pageHistoryTags" OWNER TO wiki;

--
-- Name: pageHistoryTags_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."pageHistoryTags_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pageHistoryTags_id_seq" OWNER TO wiki;

--
-- Name: pageHistoryTags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."pageHistoryTags_id_seq" OWNED BY public."pageHistoryTags".id;


--
-- Name: pageHistory_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."pageHistory_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pageHistory_id_seq" OWNER TO wiki;

--
-- Name: pageHistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."pageHistory_id_seq" OWNED BY public."pageHistory".id;


--
-- Name: pageLinks; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."pageLinks" (
    id integer NOT NULL,
    path character varying(255) NOT NULL,
    "localeCode" character varying(5) NOT NULL,
    "pageId" integer
);


ALTER TABLE public."pageLinks" OWNER TO wiki;

--
-- Name: pageLinks_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."pageLinks_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pageLinks_id_seq" OWNER TO wiki;

--
-- Name: pageLinks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."pageLinks_id_seq" OWNED BY public."pageLinks".id;


--
-- Name: pageTags; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."pageTags" (
    id integer NOT NULL,
    "pageId" integer,
    "tagId" integer
);


ALTER TABLE public."pageTags" OWNER TO wiki;

--
-- Name: pageTags_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."pageTags_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."pageTags_id_seq" OWNER TO wiki;

--
-- Name: pageTags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."pageTags_id_seq" OWNED BY public."pageTags".id;


--
-- Name: pageTree; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."pageTree" (
    id integer NOT NULL,
    path character varying(255) NOT NULL,
    depth integer NOT NULL,
    title character varying(255) NOT NULL,
    "isPrivate" boolean DEFAULT false NOT NULL,
    "isFolder" boolean DEFAULT false NOT NULL,
    "privateNS" character varying(255),
    parent integer,
    "pageId" integer,
    "localeCode" character varying(5),
    ancestors json
);


ALTER TABLE public."pageTree" OWNER TO wiki;

--
-- Name: pages; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.pages (
    id integer NOT NULL,
    path character varying(255) NOT NULL,
    hash character varying(255) NOT NULL,
    title character varying(255) NOT NULL,
    description character varying(255),
    "isPrivate" boolean DEFAULT false NOT NULL,
    "isPublished" boolean DEFAULT false NOT NULL,
    "privateNS" character varying(255),
    "publishStartDate" character varying(255),
    "publishEndDate" character varying(255),
    content text,
    render text,
    toc json,
    "contentType" character varying(255) NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL,
    "editorKey" character varying(255),
    "localeCode" character varying(5),
    "authorId" integer,
    "creatorId" integer,
    extra json DEFAULT '{}'::json NOT NULL
);


ALTER TABLE public.pages OWNER TO wiki;

--
-- Name: pages_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.pages_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.pages_id_seq OWNER TO wiki;

--
-- Name: pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.pages_id_seq OWNED BY public.pages.id;


--
-- Name: renderers; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.renderers (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    config json
);


ALTER TABLE public.renderers OWNER TO wiki;

--
-- Name: searchEngines; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."searchEngines" (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    config json
);


ALTER TABLE public."searchEngines" OWNER TO wiki;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.sessions (
    sid character varying(255) NOT NULL,
    sess json NOT NULL,
    expired timestamp with time zone NOT NULL
);


ALTER TABLE public.sessions OWNER TO wiki;

--
-- Name: settings; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.settings (
    key character varying(255) NOT NULL,
    value json,
    "updatedAt" character varying(255) NOT NULL
);


ALTER TABLE public.settings OWNER TO wiki;

--
-- Name: storage; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.storage (
    key character varying(255) NOT NULL,
    "isEnabled" boolean DEFAULT false NOT NULL,
    mode character varying(255) DEFAULT 'push'::character varying NOT NULL,
    config json,
    "syncInterval" character varying(255),
    state json
);


ALTER TABLE public.storage OWNER TO wiki;

--
-- Name: tags; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.tags (
    id integer NOT NULL,
    tag character varying(255) NOT NULL,
    title character varying(255),
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL
);


ALTER TABLE public.tags OWNER TO wiki;

--
-- Name: tags_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tags_id_seq OWNER TO wiki;

--
-- Name: tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.tags_id_seq OWNED BY public.tags.id;


--
-- Name: userAvatars; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."userAvatars" (
    id integer NOT NULL,
    data bytea NOT NULL
);


ALTER TABLE public."userAvatars" OWNER TO wiki;

--
-- Name: userGroups; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."userGroups" (
    id integer NOT NULL,
    "userId" integer,
    "groupId" integer
);


ALTER TABLE public."userGroups" OWNER TO wiki;

--
-- Name: userGroups_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."userGroups_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userGroups_id_seq" OWNER TO wiki;

--
-- Name: userGroups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."userGroups_id_seq" OWNED BY public."userGroups".id;


--
-- Name: userKeys; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public."userKeys" (
    id integer NOT NULL,
    kind character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "validUntil" character varying(255) NOT NULL,
    "userId" integer
);


ALTER TABLE public."userKeys" OWNER TO wiki;

--
-- Name: userKeys_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public."userKeys_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."userKeys_id_seq" OWNER TO wiki;

--
-- Name: userKeys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public."userKeys_id_seq" OWNED BY public."userKeys".id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: wiki
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    "providerId" character varying(255),
    password character varying(255),
    "tfaIsActive" boolean DEFAULT false NOT NULL,
    "tfaSecret" character varying(255),
    "jobTitle" character varying(255) DEFAULT ''::character varying,
    location character varying(255) DEFAULT ''::character varying,
    "pictureUrl" character varying(255),
    timezone character varying(255) DEFAULT 'America/New_York'::character varying NOT NULL,
    "isSystem" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT false NOT NULL,
    "isVerified" boolean DEFAULT false NOT NULL,
    "mustChangePwd" boolean DEFAULT false NOT NULL,
    "createdAt" character varying(255) NOT NULL,
    "updatedAt" character varying(255) NOT NULL,
    "providerKey" character varying(255) DEFAULT 'local'::character varying NOT NULL,
    "localeCode" character varying(5) DEFAULT 'en'::character varying NOT NULL,
    "defaultEditor" character varying(255) DEFAULT 'markdown'::character varying NOT NULL,
    "lastLoginAt" character varying(255),
    "dateFormat" character varying(255) DEFAULT ''::character varying NOT NULL,
    appearance character varying(255) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE public.users OWNER TO wiki;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: wiki
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO wiki;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: wiki
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: apiKeys id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."apiKeys" ALTER COLUMN id SET DEFAULT nextval('public."apiKeys_id_seq"'::regclass);


--
-- Name: assetFolders id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."assetFolders" ALTER COLUMN id SET DEFAULT nextval('public."assetFolders_id_seq"'::regclass);


--
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.assets_id_seq'::regclass);


--
-- Name: comments id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.comments ALTER COLUMN id SET DEFAULT nextval('public.comments_id_seq'::regclass);


--
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: migrations_lock index; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.migrations_lock_index_seq'::regclass);


--
-- Name: pageHistory id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistory" ALTER COLUMN id SET DEFAULT nextval('public."pageHistory_id_seq"'::regclass);


--
-- Name: pageHistoryTags id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistoryTags" ALTER COLUMN id SET DEFAULT nextval('public."pageHistoryTags_id_seq"'::regclass);


--
-- Name: pageLinks id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageLinks" ALTER COLUMN id SET DEFAULT nextval('public."pageLinks_id_seq"'::regclass);


--
-- Name: pageTags id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTags" ALTER COLUMN id SET DEFAULT nextval('public."pageTags_id_seq"'::regclass);


--
-- Name: pages id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.pages ALTER COLUMN id SET DEFAULT nextval('public.pages_id_seq'::regclass);


--
-- Name: tags id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.tags ALTER COLUMN id SET DEFAULT nextval('public.tags_id_seq'::regclass);


--
-- Name: userGroups id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userGroups" ALTER COLUMN id SET DEFAULT nextval('public."userGroups_id_seq"'::regclass);


--
-- Name: userKeys id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userKeys" ALTER COLUMN id SET DEFAULT nextval('public."userKeys_id_seq"'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: analytics; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.analytics (key, "isEnabled", config) FROM stdin;
azureinsights	f	{"instrumentationKey":""}
baidutongji	f	{"propertyTrackingId":""}
countly	f	{"appKey":"","serverUrl":""}
elasticapm	f	{"serverUrl":"http://apm.example.com:8200","serviceName":"wiki-js","environment":""}
fathom	f	{"host":"","siteId":""}
fullstory	f	{"org":""}
google	f	{"propertyTrackingId":""}
gtm	f	{"containerTrackingId":""}
hotjar	f	{"siteId":""}
matomo	f	{"siteId":1,"serverHost":"https://example.matomo.cloud"}
newrelic	f	{"licenseKey":"","appId":"","beacon":"bam.nr-data.net","errorBeacon":"bam.nr-data.net"}
plausible	f	{"domain":"","plausibleJsSrc":"https://plausible.io/js/plausible.js"}
statcounter	f	{"projectId":"","securityToken":""}
umami	f	{"websiteID":"","url":""}
umami2	f	{"websiteID":"","url":""}
yandex	f	{"tagNumber":""}
\.


--
-- Data for Name: apiKeys; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."apiKeys" (id, name, key, expiration, "isRevoked", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: assetData; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."assetData" (id, data) FROM stdin;
\.


--
-- Data for Name: assetFolders; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."assetFolders" (id, name, slug, "parentId") FROM stdin;
\.


--
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.assets (id, filename, hash, ext, kind, mime, "fileSize", metadata, "createdAt", "updatedAt", "folderId", "authorId") FROM stdin;
\.


--
-- Data for Name: authentication; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.authentication (key, "isEnabled", config, "selfRegistration", "domainWhitelist", "autoEnrollGroups", "order", "strategyKey", "displayName") FROM stdin;
local	t	{}	f	{"v":[]}	{"v":[]}	0	local	Local
\.


--
-- Data for Name: brute; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.brute (key, "firstRequest", "lastRequest", lifetime, count) FROM stdin;
\.


--
-- Data for Name: commentProviders; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."commentProviders" (key, "isEnabled", config) FROM stdin;
artalk	f	{"server":"","siteName":""}
commento	f	{"instanceUrl":"https://cdn.commento.io"}
default	t	{"akismet":"","minDelay":30}
disqus	f	{"accountName":""}
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.comments (id, content, "createdAt", "updatedAt", "pageId", "authorId", render, name, email, ip, "replyTo") FROM stdin;
\.


--
-- Data for Name: editors; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.editors (key, "isEnabled", config) FROM stdin;
api	f	{}
asciidoc	f	{}
ckeditor	f	{}
code	f	{}
markdown	t	{}
redirect	f	{}
wysiwyg	f	{}
\.


--
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.groups (id, name, permissions, "pageRules", "isSystem", "createdAt", "updatedAt", "redirectOnLogin") FROM stdin;
1	Administrators	["manage:system"]	[]	t	2026-03-20T16:26:34.025Z	2026-03-20T16:26:34.025Z	/
2	Guests	["read:pages","read:assets","read:comments"]	[{"id":"guest","roles":["read:pages","read:assets","read:comments"],"match":"START","deny":false,"path":"","locales":[]}]	t	2026-03-20T16:26:34.028Z	2026-03-20T16:26:34.028Z	/
\.


--
-- Data for Name: locales; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.locales (code, strings, "isRTL", name, "nativeName", availability, "createdAt", "updatedAt") FROM stdin;
en	{"common":{"footer":{"poweredBy":"Powered by","copyright":"© {{year}} {{company}}. All rights reserved.","license":"Content is available under the {{license}}, by {{company}}."},"actions":{"save":"Save","cancel":"Cancel","download":"Download","upload":"Upload","discard":"Discard","clear":"Clear","create":"Create","edit":"Edit","delete":"Delete","refresh":"Refresh","saveChanges":"Save Changes","proceed":"Proceed","ok":"OK","add":"Add","apply":"Apply","browse":"Browse...","close":"Close","page":"Page","discardChanges":"Discard Changes","move":"Move","rename":"Rename","optimize":"Optimize","preview":"Preview","properties":"Properties","insert":"Insert","fetch":"Fetch","generate":"Generate","confirm":"Confirm","copy":"Copy","returnToTop":"Return to top","exit":"Exit","select":"Select","convert":"Convert"},"newpage":{"title":"This page does not exist yet.","subtitle":"Would you like to create it now?","create":"Create Page","goback":"Go back"},"unauthorized":{"title":"Unauthorized","action":{"view":"You cannot view this page.","source":"You cannot view the page source.","history":"You cannot view the page history.","edit":"You cannot edit the page.","create":"You cannot create the page.","download":"You cannot download the page content.","downloadVersion":"You cannot download the content for this page version.","sourceVersion":"You cannot view the source of this version of the page."},"goback":"Go Back","login":"Login As..."},"notfound":{"gohome":"Home","title":"Not Found","subtitle":"This page does not exist."},"welcome":{"title":"Welcome to your wiki!","subtitle":"Let's get started and create the home page.","createhome":"Create Home Page","goadmin":"Administration"},"header":{"home":"Home","newPage":"New Page","currentPage":"Current Page","view":"View","edit":"Edit","history":"History","viewSource":"View Source","move":"Move / Rename","delete":"Delete","assets":"Assets","imagesFiles":"Images & Files","search":"Search...","admin":"Administration","account":"Account","myWiki":"My Wiki","profile":"Profile","logout":"Logout","login":"Login","searchHint":"Type at least 2 characters to start searching...","searchLoading":"Searching...","searchNoResult":"No pages matching your query.","searchResultsCount":"Found {{total}} results","searchDidYouMean":"Did you mean...","searchClose":"Close","searchCopyLink":"Copy Search Link","language":"Language","browseTags":"Browse by Tags","siteMap":"Site Map","pageActions":"Page Actions","duplicate":"Duplicate","convert":"Convert"},"page":{"lastEditedBy":"Last edited by","unpublished":"Unpublished","editPage":"Edit Page","toc":"Page Contents","bookmark":"Bookmark","share":"Share","printFormat":"Print Format","delete":"Delete Page","deleteTitle":"Are you sure you want to delete page {{title}}?","deleteSubtitle":"The page can be restored from the administration area.","viewingSource":"Viewing source of page {{path}}","returnNormalView":"Return to Normal View","id":"ID {{id}}","published":"Published","private":"Private","global":"Global","loading":"Loading Page...","viewingSourceVersion":"Viewing source as of {{date}} of page {{path}}","versionId":"Version ID {{id}}","unpublishedWarning":"This page is not published.","tags":"Tags","tagsMatching":"Pages matching tags","convert":"Convert Page","convertTitle":"Select the editor you want to use going forward for the page {{title}}:","convertSubtitle":"The page content will be converted into the format of the newly selected editor. Note that some formatting or non-rendered content may be lost as a result of the conversion. A snapshot will be added to the page history and can be restored at any time.","editExternal":"Edit on {{name}}"},"error":{"unexpected":"An unexpected error occurred."},"password":{"veryWeak":"Very Weak","weak":"Weak","average":"Average","strong":"Strong","veryStrong":"Very Strong"},"user":{"search":"Search User","searchPlaceholder":"Search Users..."},"duration":{"every":"Every","minutes":"Minute(s)","hours":"Hour(s)","days":"Day(s)","months":"Month(s)","years":"Year(s)"},"outdatedBrowserWarning":"Your browser is outdated. Upgrade to a {{modernBrowser}}.","modernBrowser":"modern browser","license":{"none":"None","ccby":" Creative Commons Attribution License","ccbysa":"Creative Commons Attribution-ShareAlike License","ccbynd":"Creative Commons Attribution-NoDerivs License","ccbync":"Creative Commons Attribution-NonCommercial License","ccbyncsa":"Creative Commons Attribution-NonCommercial-ShareAlike License","ccbyncnd":"Creative Commons Attribution-NonCommercial-NoDerivs License","cc0":"Public Domain","alr":"All Rights Reserved"},"sidebar":{"browse":"Browse","mainMenu":"Main Menu","currentDirectory":"Current Directory","root":"(root)"},"comments":{"title":"Comments","newPlaceholder":"Write a new comment...","fieldName":"Your Name","fieldEmail":"Your Email Address","markdownFormat":"Markdown Format","postComment":"Post Comment","loading":"Loading comments...","postingAs":"Posting as {{name}}","beFirst":"Be the first to comment.","none":"No comments yet.","updateComment":"Update Comment","deleteConfirmTitle":"Confirm Delete","deleteWarn":"Are you sure you want to permanently delete this comment?","deletePermanentWarn":"This action cannot be undone!","modified":"modified {{reldate}}","postSuccess":"New comment posted successfully.","contentMissingError":"Comment is empty or too short!","updateSuccess":"Comment was updated successfully.","deleteSuccess":"Comment was deleted successfully.","viewDiscussion":"View Discussion","newComment":"New Comment","fieldContent":"Comment Content","sdTitle":"Talk"},"pageSelector":{"createTitle":"Select New Page Location","moveTitle":"Move / Rename Page Location","selectTitle":"Select a Page","virtualFolders":"Virtual Folders","pages":"Pages","folderEmptyWarning":"This folder is empty."}},"auth":{"loginRequired":"Login required","fields":{"emailUser":"Email / Username","password":"Password","email":"Email Address","verifyPassword":"Verify Password","name":"Name","username":"Username"},"actions":{"login":"Log In","register":"Register"},"errors":{"invalidLogin":"Invalid Login","invalidLoginMsg":"The email or password is invalid.","invalidUserEmail":"Invalid User Email","loginError":"Login error","notYetAuthorized":"You have not been authorized to login to this site yet.","tooManyAttempts":"Too many attempts!","tooManyAttemptsMsg":"You've made too many failed attempts in a short period of time, please try again {{time}}.","userNotFound":"User not found"},"providers":{"local":"Local","windowslive":"Microsoft Account","azure":"Azure Active Directory","google":"Google ID","facebook":"Facebook","github":"GitHub","slack":"Slack","ldap":"LDAP / Active Directory"},"tfa":{"title":"Two Factor Authentication","subtitle":"Security code required:","placeholder":"XXXXXX","verifyToken":"Verify"},"registerTitle":"Create an account","switchToLogin":{"text":"Already have an account? {{link}}","link":"Login instead"},"loginUsingStrategy":"Login using {{strategy}}","forgotPasswordLink":"Forgot your password?","orLoginUsingStrategy":"or login using...","switchToRegister":{"text":"Don't have an account yet? {{link}}","link":"Create an account"},"invalidEmailUsername":"Enter a valid email / username.","invalidPassword":"Enter a valid password.","loginSuccess":"Login Successful! Redirecting...","signingIn":"Signing In...","genericError":"Authentication is unavailable.","registerSubTitle":"Fill-in the form below to create your account.","pleaseWait":"Please wait","registerSuccess":"Account created successfully!","registering":"Creating account...","missingEmail":"Missing email address.","invalidEmail":"Email address is invalid.","missingPassword":"Missing password.","passwordTooShort":"Password is too short.","passwordNotMatch":"Both passwords do not match.","missingName":"Name is missing.","nameTooShort":"Name is too short.","nameTooLong":"Name is too long.","forgotPasswordCancel":"Cancel","sendResetPassword":"Reset Password","forgotPasswordSubtitle":"Enter your email address to receive the instructions to reset your password:","registerCheckEmail":"Check your emails to activate your account.","changePwd":{"subtitle":"Choose a new password","instructions":"You must choose a new password:","newPasswordPlaceholder":"New Password","newPasswordVerifyPlaceholder":"Verify New Password","proceed":"Change Password","loading":"Changing password..."},"forgotPasswordLoading":"Requesting password reset...","forgotPasswordSuccess":"Check your emails for password reset instructions!","selectAuthProvider":"Select Authentication Provider","enterCredentials":"Enter your credentials","forgotPasswordTitle":"Forgot your password","tfaFormTitle":"Enter the security code generated from your trusted device:","tfaSetupTitle":"Your administrator has required Two-Factor Authentication (2FA) to be enabled on your account.","tfaSetupInstrFirst":"1) Scan the QR code below from your mobile 2FA application:","tfaSetupInstrSecond":"2) Enter the security code generated from your trusted device:"},"admin":{"dashboard":{"title":"Dashboard","subtitle":"Wiki.js","pages":"Pages","users":"Users","groups":"Groups","versionLatest":"You are running the latest version.","versionNew":"A new version is available: {{version}}","contributeSubtitle":"Wiki.js is a free and open source project. There are several ways you can contribute to the project.","contributeHelp":"We need your help!","contributeLearnMore":"Learn More","recentPages":"Recent Pages","mostPopularPages":"Most Popular Pages","lastLogins":"Last Logins"},"general":{"title":"General","subtitle":"Main settings of your wiki","siteInfo":"Site Info","siteBranding":"Site Branding","general":"General","siteUrl":"Site URL","siteUrlHint":"Full URL to your wiki, without the trailing slash. (e.g. https://wiki.example.com)","siteTitle":"Site Title","siteTitleHint":"Displayed in the top bar and appended to all pages meta title.","logo":"Logo","uploadLogo":"Upload Logo","uploadClear":"Clear","uploadSizeHint":"An image of {{size}} pixels is recommended for best results.","uploadTypesHint":"{{typeList}} or {{lastType}} files only","footerCopyright":"Footer Copyright","companyName":"Company / Organization Name","companyNameHint":"Name to use when displaying copyright notice in the footer. Leave empty to hide.","siteDescription":"Site Description","siteDescriptionHint":"Default description when none is provided for a page.","metaRobots":"Meta Robots","metaRobotsHint":"Default: Index, Follow. Can also be set on a per-page basis.","logoUrl":"Logo URL","logoUrlHint":"Specify an image to use as the logo. SVG, PNG, JPG are supported, in a square ratio, 34x34 pixels or larger. Click the button on the right to upload a new image.","contentLicense":"Content License","contentLicenseHint":"License shown in the footer of all content pages.","siteTitleInvalidChars":"Site Title contains invalid characters.","saveSuccess":"Site configuration saved successfully.","pageExtensions":"Page Extensions","pageExtensionsHint":"A comma-separated list of URL extensions that will be treated as pages. For example, adding md will treat /foobar.md the same as /foobar.","editMenuExternalName":"Button Site Name","editMenuExternalNameHint":"The name of the external site to display on the edit button. Do not include the \\"Edit on\\" prefix.","editMenuExternalIcon":"Button Icon","editMenuExternalIconHint":"The icon to display on the edit button. For example, mdi-github to display the GitHub icon.","editMenuExternalUrl":"Button URL","editMenuExternalUrlHint":"Url to the page on the external repository. Use the {filename} placeholder where the filename should be included. (e.g. https://github.com/foo/bar/blob/main/{filename} )","editShortcuts":"Edit Shortcuts","editFab":"FAB Quick Edit Menu","editFabHint":"Display the edit floating action button (FAB) with a speed-dial menu in the bottom right corner of the screen.","editMenuBar":"Edit Menu Bar","displayEditMenuBar":"Display Edit Menu Bar","displayEditMenuBarHint":"Display the edit menu bar in the page header.","displayEditMenuBtn":"Display Edit Button","displayEditMenuBtnHint":"Display a button to edit the current page.","displayEditMenuExternalBtn":"Display External Edit Button","displayEditMenuExternalBtnHint":"Display a button linking to an external repository (e.g. GitHub) where users can edit or submit a PR for the current page.","footerOverride":"Footer Text Override","footerOverrideHint":"Optionally override the footer text with a custom message. Useful if none of the above licenses are appropriate."},"locale":{"title":"Locale","subtitle":"Set localization options for your wiki","settings":"Locale Settings","namespacing":"Multilingual Namespacing","downloadTitle":"Download Locale","base":{"labelWithNS":"Base Locale","hint":"All UI text elements will be displayed in selected language.","label":"Site Locale"},"autoUpdate":{"label":"Update Automatically","hintWithNS":"Automatically download updates to all namespaced locales enabled below.","hint":"Automatically download updates to this locale as they become available."},"namespaces":{"label":"Multilingual Namespaces","hint":"Enables multiple language versions of the same page."},"activeNamespaces":{"label":"Active Namespaces","hint":"List of locales enabled for multilingual namespacing. The base locale defined above will always be included regardless of this selection."},"namespacingPrefixWarning":{"title":"The locale code will be prefixed to all paths. (e.g. /{{langCode}}/page-name)","subtitle":"Paths without a locale code will be automatically redirected to the base locale defined above."},"sideload":"Sideload Locale Package","sideloadHelp":"If you are not connected to the internet or cannot download locale files using the method above, you can instead sideload packages manually by uploading them below.","code":"Code","name":"Name","nativeName":"Native Name","rtl":"RTL","availability":"Availability","download":"Download"},"stats":{"title":"Statistics"},"theme":{"title":"Theme","subtitle":"Modify the look & feel of your wiki","siteTheme":"Site Theme","siteThemeHint":"Themes affect how content pages are displayed. Other site sections (such as the editor or admin area) are not affected.","darkMode":"Dark Mode","darkModeHint":"Not recommended for accessibility. May not be supported by all themes.","codeInjection":"Code Injection","cssOverride":"CSS Override","cssOverrideHint":"CSS code to inject after system default CSS. Consider using custom themes if you have a large amount of css code. Injecting too much CSS code will result in poor page load performance! CSS will automatically be minified.","headHtmlInjection":"Head HTML Injection","headHtmlInjectionHint":"HTML code to be injected just before the closing head tag. Usually for script tags.","bodyHtmlInjection":"Body HTML Injection","bodyHtmlInjectionHint":"HTML code to be injected just before the closing body tag.","downloadThemes":"Download Themes","iconset":"Icon Set","iconsetHint":"Set of icons to use for the sidebar navigation.","downloadName":"Name","downloadAuthor":"Author","downloadDownload":"Download","cssOverrideWarning":"{{caution}} When adding styles for page content, you must scope them to the {{cssClass}} class. Omitting this could break the layout of the editor!","cssOverrideWarningCaution":"CAUTION:","options":"Theme Options","tocHeadingLevels":"Default TOC Heading Levels","tocHeadingLevelsHint":"The table of contents will show headings from and up to the selected levels by default."},"groups":{"title":"Groups"},"users":{"title":"Users","active":"Active","inactive":"Inactive","verified":"Verified","unverified":"Unverified","edit":"Edit User","id":"ID {{id}}","basicInfo":"Basic Info","email":"Email","displayName":"Display Name","authentication":"Authentication","authProvider":"Provider","password":"Password","changePassword":"Change Password","newPassword":"New Password","tfa":"Two Factor Authentication (2FA)","toggle2FA":"Toggle 2FA","authProviderId":"Provider Id","groups":"User Groups","noGroupAssigned":"This user is not assigned to any group yet. You must assign at least 1 group to a user.","selectGroup":"Select Group...","groupAssign":"Assign","extendedMetadata":"Extended Metadata","location":"Location","jobTitle":"Job Title","timezone":"Timezone","userUpdateSuccess":"User updated successfully.","userAlreadyAssignedToGroup":"User is already assigned to this group!","deleteConfirmTitle":"Delete User?","deleteConfirmText":"Are you sure you want to delete user {{username}}?","updateUser":"Update User","groupAssignNotice":"Note that you cannot assign users to the Administrators or Guests groups from this panel.","deleteConfirmForeignNotice":"Note that you cannot delete a user that already created content. You must instead either deactivate the user or delete all content that was created by that user.","userVerifySuccess":"User has been verified successfully.","userActivateSuccess":"User has been activated successfully.","userDeactivateSuccess":"User deactivated successfully.","deleteConfirmReplaceWarn":"Any content (pages, uploads, comments, etc.) that was created by this user will be reassigned to the user selected below. It is recommended to create a dummy target user (e.g. Deleted User) if you don't want the content to be reassigned to any current active user.","userTFADisableSuccess":"2FA was disabled successfully.","userTFAEnableSuccess":"2FA was enabled successfully."},"auth":{"title":"Authentication","subtitle":"Configure the authentication settings of your wiki","strategies":"Strategies","globalAdvSettings":"Global Advanced Settings","jwtAudience":"JWT Audience","jwtAudienceHint":"Audience URN used in JWT issued upon login. Usually your domain name. (e.g. urn:your.domain.com)","tokenExpiration":"Token Expiration","tokenExpirationHint":"The expiration period of a token until it must be renewed. (default: 30m)","tokenRenewalPeriod":"Token Renewal Period","tokenRenewalPeriodHint":"The maximum period a token can be renewed when expired. (default: 14d)","strategyState":"This strategy is {{state}} {{locked}}","strategyStateActive":"active","strategyStateInactive":"not active","strategyStateLocked":"and cannot be disabled.","strategyConfiguration":"Strategy Configuration","strategyNoConfiguration":"This strategy has no configuration options you can modify.","registration":"Registration","selfRegistration":"Allow self-registration","selfRegistrationHint":"Allow any user successfully authorized by the strategy to access the wiki.","domainsWhitelist":"Limit to specific email domains","domainsWhitelistHint":"A list of domains authorized to register. The user email address domain must match one of these to gain access.","autoEnrollGroups":"Assign to group","autoEnrollGroupsHint":"Automatically assign new users to these groups.","security":"Security","force2fa":"Force all users to use Two-Factor Authentication (2FA)","force2faHint":"Users will be required to setup 2FA the first time they login and cannot be disabled by the user.","configReference":"Configuration Reference","configReferenceSubtitle":"Some strategies may require some configuration values to be set on your provider. These are provided for reference only and may not be needed by the current strategy.","siteUrlNotSetup":"You must set a valid {{siteUrl}} first! Click on {{general}} in the left sidebar.","allowedWebOrigins":"Allowed Web Origins","callbackUrl":"Callback URL / Redirect URI","loginUrl":"Login URL","logoutUrl":"Logout URL","tokenEndpointAuthMethod":"Token Endpoint Authentication Method","refreshSuccess":"List of strategies has been refreshed.","saveSuccess":"Authentication configuration saved successfully.","activeStrategies":"Active Strategies","addStrategy":"Add Strategy","strategyIsEnabled":"Active","strategyIsEnabledHint":"Are users able to login using this strategy?","displayName":"Display Name","displayNameHint":"The title shown to the end user for this authentication strategy."},"editor":{"title":"Editor"},"logging":{"title":"Logging"},"rendering":{"title":"Rendering","subtitle":"Configure the page rendering pipeline"},"search":{"title":"Search Engine","subtitle":"Configure the search capabilities of your wiki","rebuildIndex":"Rebuild Index","searchEngine":"Search Engine","engineConfig":"Engine Configuration","engineNoConfig":"This engine has no configuration options you can modify.","listRefreshSuccess":"List of search engines has been refreshed.","configSaveSuccess":"Search engine configuration saved successfully.","indexRebuildSuccess":"Index rebuilt successfully."},"storage":{"title":"Storage","subtitle":"Set backup and sync targets for your content","targets":"Targets","status":"Status","lastSync":"Last synchronization {{time}}","lastSyncAttempt":"Last attempt was {{time}}","errorMsg":"Error Message","noTarget":"You don't have any active storage target.","targetConfig":"Target Configuration","noConfigOption":"This storage target has no configuration options you can modify.","syncDirection":"Sync Direction","syncDirectionSubtitle":"Choose how content synchronization is handled for this storage target.","syncDirBi":"Bi-directional","syncDirPush":"Push to target","syncDirPull":"Pull from target","unsupported":"Unsupported","syncDirBiHint":"In bi-directional mode, content is first pulled from the storage target. Any newer content overwrites local content. New content since last sync is then pushed to the storage target, overwriting any content on target if present.","syncDirPushHint":"Content is always pushed to the storage target, overwriting any existing content. This is safest choice for backup scenarios.","syncDirPullHint":"Content is always pulled from the storage target, overwriting any local content which already exists. This choice is usually reserved for single-use content import. Caution with this option as any local content will always be overwritten!","syncSchedule":"Sync Schedule","syncScheduleHint":"For performance reasons, this storage target synchronize changes on an interval-based schedule, instead of on every change. Define at which interval should the synchronization occur.","syncScheduleCurrent":"Currently set to every {{schedule}}.","syncScheduleDefault":"The default is every {{schedule}}.","actions":"Actions","actionRun":"Run","targetState":"This storage target is {{state}}","targetStateActive":"active","targetStateInactive":"inactive","actionsInactiveWarn":"You must enable this storage target and apply changes before you can run actions."},"api":{"title":"API Access","subtitle":"Manage keys to access the API","enabled":"API Enabled","disabled":"API Disabled","enableButton":"Enable API","disableButton":"Disable API","newKeyButton":"New API Key","headerName":"Name","headerKeyEnding":"Key Ending","headerExpiration":"Expiration","headerCreated":"Created","headerLastUpdated":"Last Updated","headerRevoke":"Revoke","noKeyInfo":"No API keys have been generated yet.","revokeConfirm":"Revoke API Key?","revokeConfirmText":"Are you sure you want to revoke key {{name}}? This action cannot be undone!","revoke":"Revoke","refreshSuccess":"List of API keys has been refreshed.","revokeSuccess":"The key has been revoked successfully.","newKeyTitle":"New API Key","newKeySuccess":"API key created successfully.","newKeyNameError":"Name is missing or invalid.","newKeyGroupError":"You must select a group.","newKeyGuestGroupError":"The guests group cannot be used for API keys.","newKeyNameHint":"Purpose of this key","newKeyName":"Name","newKeyExpiration":"Expiration","newKeyExpirationHint":"You can still revoke a key anytime regardless of the expiration.","newKeyPermissionScopes":"Permission Scopes","newKeyFullAccess":"Full Access","newKeyGroupPermissions":"or use group permissions...","newKeyGroup":"Group","newKeyGroupHint":"The API key will have the same permissions as the selected group.","expiration30d":"30 days","expiration90d":"90 days","expiration180d":"180 days","expiration1y":"1 year","expiration3y":"3 years","newKeyCopyWarn":"Copy the key shown below as {{bold}}","newKeyCopyWarnBold":"it will NOT be shown again","toggleStateEnabledSuccess":"API has been enabled successfully.","toggleStateDisabledSuccess":"API has been disabled successfully."},"system":{"title":"System Info","subtitle":"Information about your system","hostInfo":"Host Information","currentVersion":"Current Version","latestVersion":"Latest Version","published":"Published","os":"Operating System","hostname":"Hostname","cpuCores":"CPU Cores","totalRAM":"Total RAM","workingDirectory":"Working Directory","configFile":"Configuration File","ramUsage":"RAM Usage: {{used}} / {{total}}","dbPartialSupport":"Your database version is not fully supported. Some functionality may be limited or not work as expected.","refreshSuccess":"System Info has been refreshed."},"utilities":{"title":"Utilities","subtitle":"Maintenance and miscellaneous tools","tools":"Tools","authTitle":"Authentication","authSubtitle":"Various tools for authentication / users","cacheTitle":"Flush Cache","cacheSubtitle":"Flush cache of various components","graphEndpointTitle":"GraphQL Endpoint","graphEndpointSubtitle":"Change the GraphQL endpoint for Wiki.js","importv1Title":"Import from Wiki.js 1.x","importv1Subtitle":"Migrate data from a previous 1.x installation","telemetryTitle":"Telemetry","telemetrySubtitle":"Enable/Disable telemetry or reset the client ID","contentTitle":"Content","contentSubtitle":"Various tools for pages","exportTitle":"Export to Disk","exportSubtitle":"Save content to tarball for backup / migration"},"dev":{"title":"Developer Tools","flags":{"title":"Flags"},"graphiql":{"title":"GraphiQL"},"voyager":{"title":"Voyager"}},"contribute":{"title":"Contribute to Wiki.js","subtitle":"Help support Wiki.js development and operations","fundOurWork":"Fund our work","spreadTheWord":"Spread the word","talkToFriends":"Talk to your friends and colleagues about how awesome Wiki.js is!","followUsOnTwitter":"Follow us on {{0}}.","submitAnIdea":"Submit an idea or vote on a proposed one on the {{0}}.","submitAnIdeaLink":"feature requests board","foundABug":"Found a bug? Submit an issue on {{0}}.","helpTranslate":"Help translate Wiki.js in your language. Let us know on {{0}}.","makeADonation":"Make a donation","contribute":"Contribute","openCollective":"Wiki.js is also part of the Open Collective initiative, a transparent fund that goes toward community resources. You can contribute financially by making a monthly or one-time donation:","needYourHelp":"We need your help to keep improving the software and run the various associated services (e.g. hosting and networking).","openSource":"Wiki.js is a free and open-source software brought to you with {{0}} by {{1}} and {{2}}.","openSourceContributors":"contributors","tshirts":"You can also buy Wiki.js t-shirts to support the project financially:","shop":"Wiki.js Shop","becomeAPatron":"Become a Patron","patreon":"Become a backer or sponsor via Patreon (goes directly into supporting lead developer Nicolas Giard's goal of working full-time on Wiki.js)","paypal":"Make a one-time or recurring donation via Paypal:","ethereum":"We accept donations using Ethereum:","github":"Become a sponsor via GitHub Sponsors (goes directly into supporting lead developer Nicolas Giard's goal of working full-time on Wiki.js)","becomeASponsor":"Become a Sponsor"},"nav":{"site":"Site","users":"Users","modules":"Modules","system":"System"},"pages":{"title":"Pages"},"navigation":{"title":"Navigation","subtitle":"Manage the site navigation","link":"Link","divider":"Divider","header":"Header","label":"Label","icon":"Icon","targetType":"Target Type","target":"Target","noSelectionText":"Select a navigation item on the left.","untitled":"Untitled {{kind}}","navType":{"external":"External Link","home":"Home","page":"Page","searchQuery":"Search Query","externalblank":"External Link (New Window)"},"edit":"Edit {{kind}}","delete":"Delete {{kind}}","saveSuccess":"Navigation saved successfully.","noItemsText":"Click the Add button to add your first navigation item.","emptyList":"Navigation is empty","visibilityMode":{"all":"Visible to everyone","restricted":"Visible to select groups..."},"selectPageButton":"Select Page...","mode":"Navigation Mode","modeSiteTree":{"title":"Site Tree","description":"Classic Tree-based Navigation"},"modeCustom":{"title":"Custom Navigation","description":"Static Navigation Menu + Site Tree Button"},"modeNone":{"title":"None","description":"Disable Site Navigation"},"copyFromLocale":"Copy from locale...","sourceLocale":"Source Locale","sourceLocaleHint":"The locale from which navigation items will be copied from.","copyFromLocaleInfoText":"Select the locale from which items will be copied from. Items will be appended to the current list of items in the active locale.","modeStatic":{"title":"Static Navigation","description":"Static Navigation Menu Only"}},"mail":{"title":"Mail","subtitle":"Configure mail settings","configuration":"Configuration","dkim":"DKIM (optional)","test":"Send a test email","testRecipient":"Recipient Email Address","testSend":"Send Email","sender":"Sender","senderName":"Sender Name","senderEmail":"Sender Email","smtp":"SMTP Settings","smtpHost":"Host","smtpPort":"Port","smtpPortHint":"Usually 465 (recommended), 587 or 25.","smtpTLS":"Secure (TLS)","smtpTLSHint":"Should be enabled when using port 465, otherwise turned off (587 or 25).","smtpUser":"Username","smtpPwd":"Password","dkimHint":"DKIM (DomainKeys Identified Mail) provides a layer of security on all emails sent from Wiki.js by providing the means for recipients to validate the domain name and ensure the message authenticity.","dkimUse":"Use DKIM","dkimDomainName":"Domain Name","dkimKeySelector":"Key Selector","dkimPrivateKey":"Private Key","dkimPrivateKeyHint":"Private key for the selector in PEM format","testHint":"Send a test email to ensure your SMTP configuration is working.","saveSuccess":"Configuration saved successfully.","sendTestSuccess":"A test email was sent successfully.","smtpVerifySSL":"Verify SSL Certificate","smtpVerifySSLHint":"Some hosts requires SSL certificate checking to be disabled. Leave enabled for proper security.","smtpName":"Client Identifying Hostname","smtpNameHint":"An optional name to send to the SMTP server to identify your mailer. Leave empty to use server hostname. For Google Workspace customers, this should be your main domain name."},"webhooks":{"title":"Webhooks","subtitle":"Manage webhooks to external services"},"adminArea":"Administration Area","analytics":{"title":"Analytics","subtitle":"Add analytics and tracking tools to your wiki","providers":"Providers","providerConfiguration":"Provider Configuration","providerNoConfiguration":"This provider has no configuration options you can modify.","refreshSuccess":"List of providers refreshed successfully.","saveSuccess":"Analytics configuration saved successfully"},"comments":{"title":"Comments","provider":"Provider","subtitle":"Add discussions to your wiki pages","providerConfig":"Provider Configuration","providerNoConfig":"This provider has no configuration options you can modify.","configSaveSuccess":"Comments configuration saved successfully."},"tags":{"title":"Tags","subtitle":"Manage page tags","emptyList":"No tags to display.","edit":"Edit Tag","tag":"Tag","label":"Label","date":"Created {{created}} and last updated {{updated}}.","delete":"Delete this tag","noSelectionText":"Select a tag from the list on the left.","noItemsText":"Add a tag to a page to get started.","refreshSuccess":"Tags have been refreshed.","deleteSuccess":"Tag deleted successfully.","saveSuccess":"Tag has been saved successfully.","filter":"Filter...","viewLinkedPages":"View Linked Pages","deleteConfirm":"Delete Tag?","deleteConfirmText":"Are you sure you want to delete tag {{tag}}? The tag will also be unlinked from all pages."},"ssl":{"title":"SSL","subtitle":"Manage SSL configuration","provider":"Provider","providerHint":"Select Custom Certificate if you have your own certificate already.","domain":"Domain","domainHint":"Enter the fully qualified domain pointing to your wiki. (e.g. wiki.example.com)","providerOptions":"Provider Options","providerDisabled":"Disabled","providerLetsEncrypt":"Let's Encrypt","providerCustomCertificate":"Custom Certificate","ports":"Ports","httpPort":"HTTP Port","httpPortHint":"Non-SSL port the server will listen to for HTTP requests. Usually 80 or 3000.","httpsPort":"HTTPS Port","httpsPortHint":"SSL port the server will listen to for HTTPS requests. Usually 443.","httpPortRedirect":"Redirect HTTP requests to HTTPS","httpPortRedirectHint":"Will automatically redirect any requests on the HTTP port to HTTPS.","writableConfigFileWarning":"Note that your config file must be writable in order to persist ports configuration.","renewCertificate":"Renew Certificate","status":"Certificate Status","expiration":"Certificate Expiration","subscriberEmail":"Subscriber Email","currentState":"Current State","httpPortRedirectTurnOn":"Turn On","httpPortRedirectTurnOff":"Turn Off","renewCertificateLoadingTitle":"Renewing Certificate...","renewCertificateLoadingSubtitle":"Do not leave this page.","renewCertificateSuccess":"Certificate renewed successfully.","httpPortRedirectSaveSuccess":"HTTP Redirection changed successfully."},"security":{"title":"Security","maxUploadSize":"Max Upload Size","maxUploadBatch":"Max Files per Upload","maxUploadBatchHint":"How many files can be uploaded in a single batch?","maxUploadSizeHint":"The maximum size for a single file.","maxUploadSizeSuffix":"bytes","maxUploadBatchSuffix":"files","uploads":"Uploads","uploadsInfo":"These settings only affect Wiki.js. If you're using a reverse-proxy (e.g. nginx, apache, Cloudflare), you must also change its settings to match.","subtitle":"Configure security settings","login":"Login","loginScreen":"Login Screen","jwt":"JWT Configuration","bypassLogin":"Bypass Login Screen","bypassLoginHint":"Should the user be redirected automatically to the first authentication provider.","loginBgUrl":"Login Background Image URL","loginBgUrlHint":"Specify an image to use as the login background. PNG and JPG are supported, 1920x1080 recommended. Leave empty for default. Click the button on the right to upload a new image. Note that the Guests group must have read-access to the selected image!","hideLocalLogin":"Hide Local Authentication Provider","hideLocalLoginHint":"Don't show the local authentication provider on the login screen. Add ?all to the URL to temporarily use it.","loginSecurity":"Security","enforce2fa":"Enforce 2FA","enforce2faHint":"Force all users to use Two-Factor Authentication when using an authentication provider with a user / password form."},"extensions":{"title":"Extensions","subtitle":"Install extensions for extra functionality"}},"editor":{"page":"Page","save":{"processing":"Rendering","pleaseWait":"Please wait...","createSuccess":"Page created successfully.","error":"An error occurred while creating the page","updateSuccess":"Page updated successfully.","saved":"Saved"},"props":{"pageProperties":"Page Properties","pageInfo":"Page Info","title":"Title","shortDescription":"Short Description","shortDescriptionHint":"Shown below the title","pathCategorization":"Path & Categorization","locale":"Locale","path":"Path","pathHint":"Do not include any leading or trailing slashes.","tags":"Tags","tagsHint":"Use tags to categorize your pages and make them easier to find.","publishState":"Publishing State","publishToggle":"Published","publishToggleHint":"Unpublished pages are still visible to users with write permissions on this page.","publishStart":"Publish starting on...","publishStartHint":"Leave empty for no start date","publishEnd":"Publish ending on...","publishEndHint":"Leave empty for no end date","info":"Info","scheduling":"Scheduling","social":"Social","categorization":"Categorization","socialFeatures":"Social Features","allowComments":"Allow Comments","allowCommentsHint":"Enable commenting abilities on this page.","allowRatings":"Allow Ratings","displayAuthor":"Display Author Info","displaySharingBar":"Display Sharing Toolbar","displaySharingBarHint":"Show a toolbar with buttons to share and print this page","displayAuthorHint":"Show the page author along with the last edition time.","allowRatingsHint":"Enable rating capabilities on this page.","scripts":"Scripts","css":"CSS","cssHint":"CSS will automatically be minified upon saving. Do not include surrounding style tags, only the actual CSS code.","styles":"Styles","html":"HTML","htmlHint":"You must surround your javascript code with HTML script tags.","toc":"TOC","tocTitle":"Table of Contents","tocUseDefault":"Use Site Defaults","tocHeadingLevels":"TOC Heading Levels","tocHeadingLevelsHint":"The table of contents will show headings from and up to the selected levels."},"unsaved":{"title":"Discard Unsaved Changes?","body":"You have unsaved changes. Are you sure you want to leave the editor and discard any modifications you made since the last save?"},"select":{"title":"Which editor do you want to use for this page?","cannotChange":"This cannot be changed once the page is created.","customView":"or create a custom view?"},"assets":{"title":"Assets","newFolder":"New Folder","folderName":"Folder Name","folderNameNamingRules":"Must follow the asset folder {{namingRules}}.","folderNameNamingRulesLink":"naming rules","folderEmpty":"This asset folder is empty.","fileCount":"{{count}} files","headerId":"ID","headerFilename":"Filename","headerType":"Type","headerFileSize":"File Size","headerAdded":"Added","headerActions":"Actions","uploadAssets":"Upload Assets","uploadAssetsDropZone":"Browse or Drop files here...","fetchImage":"Fetch Remote Image","imageAlign":"Image Alignment","renameAsset":"Rename Asset","renameAssetSubtitle":"Enter the new name for this asset:","deleteAsset":"Delete Asset","deleteAssetConfirm":"Are you sure you want to delete asset","deleteAssetWarn":"This action cannot be undone!","refreshSuccess":"List of assets refreshed successfully.","uploadFailed":"File upload failed.","folderCreateSuccess":"Asset folder created successfully.","renameSuccess":"Asset renamed successfully.","deleteSuccess":"Asset deleted successfully.","noUploadError":"You must choose a file to upload first!"},"backToEditor":"Back to Editor","markup":{"bold":"Bold","italic":"Italic","strikethrough":"Strikethrough","heading":"Heading {{level}}","subscript":"Subscript","superscript":"Superscript","blockquote":"Blockquote","blockquoteInfo":"Info Blockquote","blockquoteSuccess":"Success Blockquote","blockquoteWarning":"Warning Blockquote","blockquoteError":"Error Blockquote","unorderedList":"Unordered List","orderedList":"Ordered List","inlineCode":"Inline Code","keyboardKey":"Keyboard Key","horizontalBar":"Horizontal Bar","togglePreviewPane":"Hide / Show Preview Pane","insertLink":"Insert Link","insertAssets":"Insert Assets","insertBlock":"Insert Block","insertCodeBlock":"Insert Code Block","insertVideoAudio":"Insert Video / Audio","insertDiagram":"Insert Diagram","insertMathExpression":"Insert Math Expression","tableHelper":"Table Helper","distractionFreeMode":"Distraction Free Mode","markdownFormattingHelp":"Markdown Formatting Help","noSelectionError":"Text must be selected first!","toggleSpellcheck":"Toggle Spellcheck"},"ckeditor":{"stats":"{{chars}} chars, {{words}} words"},"conflict":{"title":"Resolve Save Conflict","useLocal":"Use Local","useRemote":"Use Remote","useRemoteHint":"Discard local changes and use latest version","useLocalHint":"Use content in the left panel","viewLatestVersion":"View Latest Version","infoGeneric":"A more recent version of this page was saved by {{authorName}}, {{date}}","whatToDo":"What do you want to do?","whatToDoLocal":"Use your current local version and ignore the latest changes.","whatToDoRemote":"Use the remote version (latest) and discard your changes.","overwrite":{"title":"Overwrite with Remote Version?","description":"Are you sure you want to replace your current version with the latest remote content? {{refEditsLost}}","editsLost":"Your current edits will be lost."},"localVersion":"Local Version {{refEditable}}","editable":"(editable)","readonly":"(read-only)","remoteVersion":"Remote Version {{refReadOnly}}","leftPanelInfo":"Your current edit, based on page version from {{date}}","rightPanelInfo":"Last edited by {{authorName}}, {{date}}","pageTitle":"Title:","pageDescription":"Description:","warning":"Save conflict! Another user has already modified this page."},"unsavedWarning":"You have unsaved edits. Are you sure you want to leave the editor?"},"tags":{"currentSelection":"Current Selection","clearSelection":"Clear Selection","selectOneMoreTags":"Select one or more tags","searchWithinResultsPlaceholder":"Search within results...","locale":"Locale","orderBy":"Order By","selectOneMoreTagsHint":"Select one or more tags on the left.","retrievingResultsLoading":"Retrieving page results...","noResults":"Couldn't find any page with the selected tags.","noResultsWithFilter":"Couldn't find any page matching the current filtering options.","pageLastUpdated":"Last Updated {{date}}","orderByField":{"creationDate":"Creation Date","ID":"ID","lastModified":"Last Modified","path":"Path","title":"Title"},"localeAny":"Any"},"history":{"restore":{"confirmTitle":"Restore page version?","confirmText":"Are you sure you want to restore this page content as it was on {{date}}? This version will be copied on top of the current history. As such, newer versions will still be preserved.","confirmButton":"Restore","success":"Page version restored succesfully!"}},"profile":{"displayName":"Display Name","location":"Location","jobTitle":"Job Title","timezone":"Timezone","title":"Profile","subtitle":"My personal info","myInfo":"My Info","viewPublicProfile":"View Public Profile","auth":{"title":"Authentication","provider":"Provider","changePassword":"Change Password","currentPassword":"Current Password","newPassword":"New Password","verifyPassword":"Confirm New Password","changePassSuccess":"Password changed successfully."},"groups":{"title":"Groups"},"activity":{"title":"Activity","joinedOn":"Joined on","lastUpdatedOn":"Profile last updated on","lastLoginOn":"Last login on","pagesCreated":"Pages created","commentsPosted":"Comments posted"},"save":{"success":"Profile saved successfully."},"pages":{"title":"Pages","subtitle":"List of pages I created or last modified","emptyList":"No pages to display.","refreshSuccess":"Page list has been refreshed.","headerTitle":"Title","headerPath":"Path","headerCreatedAt":"Created","headerUpdatedAt":"Last Updated"},"comments":{"title":"Comments"},"preferences":"Preferences","dateFormat":"Date Format","localeDefault":"Locale Default","appearance":"Appearance","appearanceDefault":"Site Default","appearanceLight":"Light","appearanceDark":"Dark"}}	f	English	English	100	2026-03-20T16:26:34.020Z	2026-03-20T16:26:38.156Z
ru	{"common":{"footer":{"poweredBy":"Powered by","copyright":"{{year}} {{company}}. Все права защищены.","license":"Содержимое доступно в соответствии с {{license}}, от {{company}}."},"actions":{"save":"Сохранить","cancel":"Отмена","download":"Скачать","upload":"Загрузить","discard":"Отменить","clear":"Очистить","create":"Создать","edit":"Редактировать","delete":"Удалить","refresh":"Обновить","saveChanges":"Сохранить изменения","proceed":"Продолжить","ok":"OK","add":"Добавить","apply":"Применить","browse":"Обзор...","close":"Закрыть","page":"Страница","discardChanges":"Отменить изменения","move":"Переместить","rename":"Переименовать","optimize":"Оптимизировать","preview":"Предпросмотр","properties":"Свойства","insert":"Вставить","fetch":"Скачать","generate":"Сгенерировать","confirm":"Подтвердить","copy":"Копировать","returnToTop":"Вернуться наверх","exit":"Выход","select":"Выбрать","convert":"Конвертировать"},"newpage":{"title":"Эта страница ещё не существует.","subtitle":"Создать страницу прямо сейчас?","create":"Создать страницу","goback":"Назад"},"unauthorized":{"title":"Вы не авторизованы","action":{"view":"Вы не можете просматривать эту страницу.","source":"Вы не можете просматривать исходный код страницы.","history":"Вы не можете просматривать историю страницы.","edit":"Вы не можете редактировать страницу.","create":"Вы не можете создать страницу.","download":"Вы не можете скачать содержимое страницы.","downloadVersion":"Вы не можете скачать содержимое для этой версии страницы.","sourceVersion":"Вы не можете просмотреть исходный код этой версии страницы."},"goback":"Назад","login":"Войти как..."},"notfound":{"gohome":"Главная","title":"Не найдено","subtitle":"Эта страница не существует."},"welcome":{"title":"Добро пожаловать в вики!","subtitle":"Давайте начнём и создадим домашнюю страницу.","createhome":"Создать домашнюю страницу","goadmin":"Администрирование"},"header":{"home":"Главная","newPage":"Новая страница","currentPage":"Текущая страница","view":"Просмотр","edit":"Редактировать","history":"История изменений","viewSource":"Просмотр исходного кода","move":"Переместить / Переименовать","delete":"Удалить","assets":"Файлы","imagesFiles":"Изображения и файлы","search":"Поиск...","admin":"Администрирование","account":"Учётная запись","myWiki":"Моя вики","profile":"Профиль","logout":"Выход","login":"Вход","searchHint":"Введите 2 или более символа, чтобы начать поиск...","searchLoading":"Поиск...","searchNoResult":"Нет страниц, соответствующих вашему запросу.","searchResultsCount":"Найдено {{total}}","searchDidYouMean":"Вы имели в виду...","searchClose":"Закрыть","searchCopyLink":"Скопировать поисковую ссылку","language":"Язык","browseTags":"Обзор по тегам","siteMap":"Карта сайта","pageActions":"Действия на странице","duplicate":"Дублировать","convert":"Конвертировать"},"page":{"lastEditedBy":"Последнее изменение","unpublished":"Не опубликовано","editPage":"Редактировать страницу","toc":"Содержание","bookmark":"В закладки","share":"Поделиться","printFormat":"Версия для печати","delete":"Удалить страницу","deleteTitle":"Вы уверены, что хотите удалить {{title}}?","deleteSubtitle":"Страница может быть восстановлена через панель администратора.","viewingSource":"Просмотр исходного кода страницы {{path}}","returnNormalView":"Вернуться к обычному виду","id":"ID {{id}}","published":"Опубликовано","private":"Частная","global":"Глобальная","loading":"Загрузка страницы...","viewingSourceVersion":"Просмотр исходного кода страницы {{path}} на {{date}}","versionId":"ID версии {{id}}","unpublishedWarning":"Эта страница не опубликована.","tags":"Теги","tagsMatching":"Страницы, соответствующие тегам","convert":"Конвертировать страницу","convertTitle":"Выберите редактор, в который вы хотите преобразовать страницу {{title}}:","convertSubtitle":"Содержимое страницы будет преобразовано в выбранный редактор. Обратите внимание, что часть форматирования или неотображаемый контент могут быть потеряны в результате преобразования. Резервная копия будет сохранена в истории изменений страницы и может быть восстановлена в любое время.","editExternal":"Редактирование на {{name}}"},"error":{"unexpected":"Произошла непредвиденная ошибка."},"password":{"veryWeak":"Очень слабый","weak":"Слабый","average":"Средний","strong":"Надежный","veryStrong":"Очень надежный"},"user":{"search":"Поиск пользователя","searchPlaceholder":"Поиск пользователей..."},"duration":{"every":"Каждые","minutes":"Минут(ы)","hours":"Час(ы)","days":"Дни","months":"Месяц(ы)","years":"Год(ы)"},"outdatedBrowserWarning":"Ваш браузер устарел. Обновите до {{modernBrowser}} .","modernBrowser":"современного браузера","license":{"none":"Отсутствует","ccby":"Лицензия Creative Commons Attribution","ccbysa":"Лицензия Creative Commons - Некоммерческая лицензия на право осуществления некоммерческой деятельности","ccbynd":"Лицензия Creative Commons - Некоммерческая лицензия на право осуществления некоммерческой деятельности","ccbync":"Лицензия Creative Commons - Некоммерческая лицензия на право осуществления некоммерческой деятельности","ccbyncsa":"Лицензия Creative Commons - Некоммерческая лицензия на право осуществления некоммерческой деятельности","ccbyncnd":"Лицензия Creative Commons - Некоммерческая лицензия на право осуществления некоммерческой деятельности","cc0":"Всеобщее достояние","alr":"Все права защищены"},"sidebar":{"browse":"Обзор","mainMenu":"Главное меню","currentDirectory":"Текущий каталог","root":"(корень)"},"comments":{"title":"Комментарии","newPlaceholder":"Написать новый комментарий...","fieldName":"Ваше имя","fieldEmail":"Ваш электронный адрес","markdownFormat":"Формат Markdown","postComment":"Оставьте комментарий","loading":"Загрузка комментариев...","postingAs":"Публикуется как {{name}}","beFirst":"Оставьте первый комментарий.","none":"Комментариев пока нет.","updateComment":"Обновить Комментарий","deleteConfirmTitle":"Подтверждение удаления","deleteWarn":"Вы уверены что хотите навсегда удалить этот комментарий?","deletePermanentWarn":"Это действие не может быть отменено!","modified":"изменено {{reldate}}","postSuccess":"Новый комментарий успешно опубликован.","contentMissingError":"Комментарий пустой или слишком короткий!","updateSuccess":"Комментарий был успешно обновлен.","deleteSuccess":"Комментарий был успешно удален.","viewDiscussion":"Перейти","newComment":"Новый комментарий","fieldContent":"Содержание комментария","sdTitle":"Обсуждение"},"pageSelector":{"createTitle":"Выберите новое расположение страницы","moveTitle":"Переместить / переименовать расположение страницы","selectTitle":"Выберите страницу","virtualFolders":"Виртуальные папки","pages":"Страницы","folderEmptyWarning":"Папка пуста."}},"auth":{"loginRequired":"Требуется войти","fields":{"emailUser":"Адрес электронной почты / Имя пользователя","password":"Пароль","email":"Адрес электронной почты","verifyPassword":"Подтвердите пароль","name":"Название","username":"Имя пользователя"},"actions":{"login":"Войти","register":"Регистрация"},"errors":{"invalidLogin":"Неверный логин","invalidLoginMsg":"Неверный адрес электронной почты или пароль","invalidUserEmail":"Недействительный адрес электронной почты пользователя","loginError":"Ошибка входа","notYetAuthorized":"Ваша регистрация на сайте ещё не подтверждена.","tooManyAttempts":"Слишком много попыток!","tooManyAttemptsMsg":"Вы сделали слишком много неудачных попыток за короткий период времени. Пожалуйста, попробуйте снова {{time}}.","userNotFound":"Пользователь не найден"},"providers":{"local":"Локальная","windowslive":"Учетная запись Microsoft","azure":"Azure Active Directory","google":"Google ID","facebook":"Facebook","github":"GitHub","slack":"Slack","ldap":"LDAP / Active Directory"},"tfa":{"title":"Двухфакторная аутентификация","subtitle":"Требуется код безопасности:","placeholder":"XXXXXX","verifyToken":"Подтвердить"},"registerTitle":"Создать учётную запись","switchToLogin":{"text":"Уже есть учётная запись? {{link}}","link":"Войти в систему"},"loginUsingStrategy":"Войти с помощью {{strategy}}","forgotPasswordLink":"Забыли пароль?","orLoginUsingStrategy":"или войдите с помощью...","switchToRegister":{"text":"Нет учётной записи? {{link}}","link":"Создать учётную запись"},"invalidEmailUsername":"Введите действительный адрес электронной почты / имя пользователя.","invalidPassword":"Введите действительный пароль.","loginSuccess":"Успешный вход в систему! Переадресация...","signingIn":"Выполняется вход...","genericError":"Аутентификация недоступна.","registerSubTitle":"Заполните форму ниже для создания учётной записи.","pleaseWait":"Пожалуйста, подождите","registerSuccess":"Учётная запись успешно создана!","registering":"Создаём учётную запись...","missingEmail":"Отсутствует адрес электронной почты.","invalidEmail":"Адрес электронной почты недействителен.","missingPassword":"Отсутствует пароль.","passwordTooShort":"Пароль слишком короткий.","passwordNotMatch":"Пароли не совпадают.","missingName":"Имя отсутствует.","nameTooShort":"Имя слишком короткое.","nameTooLong":"Имя слишком длинное.","forgotPasswordCancel":"Отмена","sendResetPassword":"Сбросить пароль","forgotPasswordSubtitle":"Введите свой адрес электронной почты для получения инструкций по сбросу пароля:","registerCheckEmail":"Проверьте входящую электронную почту для активации вашей учётной записи.","changePwd":{"subtitle":"Выберите новый пароль","instructions":"Вы должны выбрать новый пароль:","newPasswordPlaceholder":"Новый пароль","newPasswordVerifyPlaceholder":"Подтверждение пароля","proceed":"Сменить пароль","loading":"Смена пароля..."},"forgotPasswordLoading":"Запрос сброса пароля...","forgotPasswordSuccess":"Проверьте электронную почту на наличие инструкций по сбросу пароля!","selectAuthProvider":"Выберите поставщика аутентификации","enterCredentials":"Введите учетные данные","forgotPasswordTitle":"Забыли пароль?","tfaFormTitle":"Введите код безопасности, созданный на вашем доверенном устройстве:","tfaSetupTitle":"Ваш администратор потребовал, чтобы для вашей учетной записи была включена двухфакторная аутентификация (2FA).","tfaSetupInstrFirst":"1) Отсканируйте приведенный ниже QR-код из своего мобильного приложения 2FA:","tfaSetupInstrSecond":"2) Введите код безопасности, созданный на вашем доверенном устройстве:"},"admin":{"dashboard":{"title":"Панель управления","subtitle":"Wiki.js","pages":"Страницы","users":"Пользователи","groups":"Группы","versionLatest":"Вы используете последнюю версию.","versionNew":"Доступна новая версия: {{version}}","contributeSubtitle":"Wiki.js - это бесплатный проект с открытым исходным кодом. Вы можете внести свой вклад в проект несколькими способами.","contributeHelp":"Нам нужна ваша помощь!","contributeLearnMore":"Узнать больше","recentPages":"Недавние страницы","mostPopularPages":"Самые популярные страницы","lastLogins":"Последние входы"},"general":{"title":"Общие настройки","subtitle":"Основные настройки вашей вики","siteInfo":"Информация о сайте","siteBranding":"Брендирование сайта","general":"Общие настройки","siteUrl":"URL-адрес сайта","siteUrlHint":"Полный URL-адрес вашей Вики, без слэша в конце (например, https://wiki.example.com)","siteTitle":"Заголовок сайта","siteTitleHint":"Отображается в верхней панели и добавляется ко всем мета-заголовкам страниц.","logo":"Логотип","uploadLogo":"Загрузить логотип","uploadClear":"Очистить","uploadSizeHint":"Рекомендуется изображение размером {{size}} пикселей.","uploadTypesHint":"Только файлы {{typeList}} или {{lastType}}","footerCopyright":"Авторские права в нижнем колонтитуле","companyName":"Название компании / организации","companyNameHint":"Название, отображаемое в авторских правах в нижнем колонтитуле. Оставьте пустым, чтобы скрыть.","siteDescription":"Описание сайта","siteDescriptionHint":"Описание по умолчанию, если не задано для страницы.","metaRobots":"Мета-тег Robots","metaRobotsHint":"По умолчанию: Index, Follow. Может быть задано отдельно для каждой страницы.","logoUrl":"URL логотипа","logoUrlHint":"Укажите изображение для использования в качестве логотипа. Поддерживаются квадратные SVG, PNG и JPG, размером от 34x34 пикселей и больше. Нажмите кнопку справа, чтобы загрузить новое изображение.","contentLicense":"Лицензия на содержимое","contentLicenseHint":"Лицензия отображается в нижнем колонтитуле всех страниц контента.","siteTitleInvalidChars":"Название сайта содержит недопустимые символы.","saveSuccess":"Конфигурация сайта успешно сохранена.","pageExtensions":"Расширения страниц","pageExtensionsHint":"Разделенный запятыми список расширений URL-адресов, которые будут рассматриваться как страницы. Например, добавление md будет лечить /foobar.md то же самое, что и /foobar.","editMenuExternalName":"Отображаемое имя кнопки","editMenuExternalNameHint":"Имя внешнего сайта, которое будет отображаться на кнопке редактирования. Не включайте префикс \\"Редактировать на\\".","editMenuExternalIcon":"Иконка кнопки","editMenuExternalIconHint":"Значок, отображаемый на кнопке. Например, mdi-github для отображения значка GitHub.","editMenuExternalUrl":"URL-адрес кнопок","editMenuExternalUrlHint":"Ссылка на страницу во внешнем хранилище. Используйте {filename}, где имя документа должно быть указано. (например, https://github.com/foo/bar/blob/main/{filename}).","editShortcuts":"Кнопка \\"Редактировать страницу\\"","editFab":"Редактировать страницу","editFabHint":"Отобразите кнопку \\"Редактировать страницу\\" в меню быстрого набора в правом нижнем углу экрана.","editMenuBar":"Редактировать строку меню","displayEditMenuBar":"Отображение панели меню редактирования","displayEditMenuBarHint":"Отображение строки меню редактирования в заголовке страницы.","displayEditMenuBtn":"Показать кнопку \\"Редактировать\\"","displayEditMenuBtnHint":"Показать кнопку \\"Редактировать\\" на текущей странице.","displayEditMenuExternalBtn":"Отображение кнопки редактирования","displayEditMenuExternalBtnHint":"Отображение кнопки со ссылкой на внешний репозиторий (например, GitHub), где пользователи могут редактировать или отправлять отзыв для текущей страницы.","footerOverride":"Переопределение текста нижнего колонтитула","footerOverrideHint":"При желании переопределите текст нижнего колонтитула с помощью пользовательского сообщения. Полезно, если ни одна из вышеуказанных лицензий не подходит."},"locale":{"title":"Язык","subtitle":"Настройте параметры локализации для вашей вики","settings":"Настройки локали","namespacing":"Многоязычные страницы","downloadTitle":"Скачать язык","base":{"labelWithNS":"Основной язык","hint":"Все текстовые элементы пользовательского интерфейса будут отображаться на выбранном языке.","label":"Язык сайта"},"autoUpdate":{"label":"Обновлять автоматически","hintWithNS":"Автоматически скачивать обновления для всех локалей, включенных ниже.","hint":"Автоматически загружать обновления этой локали по мере их поступления."},"namespaces":{"label":"Многоязычные страницы","hint":"Включает несколько языковых версий одной и той же страницы."},"activeNamespaces":{"label":"Активные локали","hint":"Список языков, включенных для многоязычных страниц. Язык по умолчанию, заданный выше, всегда будет включен независимо от данного выбора."},"namespacingPrefixWarning":{"title":"Код локали будет добавлен ко всем путям (например, /{{langCode}}/название-страницы).","subtitle":"Ссылки без кода локализации будут автоматически перенаправлены на язык по умолчанию, заданный выше."},"sideload":"Загрузка локали","sideloadHelp":"Если вы не подключены к интернету или не можете загрузить файлы локали описанным выше способом, здесь можно загрузить файлы вручную.","code":"Код","name":"Название","nativeName":"Родное название","rtl":"Справа налево","availability":"Доступность","download":"Скачать"},"stats":{"title":"Статистика"},"theme":{"title":"Тема","subtitle":"Измените внешний вид вашей вики","siteTheme":"Тема сайта","siteThemeHint":"Темы влияют на отображение страниц вики. Другие разделы сайта (например, редактор или панель администратора) не затрагиваются.","darkMode":"Тёмный режим","darkModeHint":"Не рекомендуется для удобства просмотра. Может не поддерживаться темой.","codeInjection":"Внедрение кода","cssOverride":"Переопределение CSS","cssOverrideHint":"CSS код для внедрения после системного CSS. Рекомендуется использовать пользовательские темы CSS, если у вас большой объем внедряемого CSS кода. Внедрение большого количества CSS-кода приведет к снижению производительности при загрузке страницы! CSS будет автоматически уменьшен.","headHtmlInjection":"Внедрение в HTML <head>","headHtmlInjectionHint":"HTML-код для внедрения непосредственно перед закрывающим тегом head. Обычно используется для тегов script.","bodyHtmlInjection":"Внедрение в HTML <body>","bodyHtmlInjectionHint":"HTML-код для внедрения непосредственно перед закрывающим тегом body.","downloadThemes":"Скачать темы","iconset":"Набор иконок","iconsetHint":"Набор иконок для использования в боковой панели навигации.","downloadName":"Название","downloadAuthor":"Автор","downloadDownload":"Скачать","cssOverrideWarning":"{{caution}} Все переопределения стилей для содержимого страницы необходимо заключать в класс {{cssClass}}. Игнорирование данного требования может испортить верстку редактора!","cssOverrideWarningCaution":"ВНИМАНИЕ:","options":"Параметры темы","tocHeadingLevels":"Уровни заголовков содержания по умолчанию","tocHeadingLevelsHint":"По умолчанию в содержании будут отображаться заголовки от выбранных уровней и выше."},"groups":{"title":"Группы"},"users":{"title":"Пользователи","active":"Активный","inactive":"Неактивный","verified":"Подтвержденный","unverified":"Неподтвержденный","edit":"Редактировать пользователя","id":"ID {{id}}","basicInfo":"Основные сведения","email":"Электронная почта","displayName":"Отображаемое имя","authentication":"Аутентификация","authProvider":"Провайдер","password":"Пароль","changePassword":"Сменить пароль","newPassword":"Новый пароль","tfa":"Двухфакторная аутентификация (2FA)","toggle2FA":"Включить двухфакторную  аутентификацию (2FA)","authProviderId":"ID Провайдера","groups":"Группы пользователей","noGroupAssigned":"Этот пользователь еще не назначен ни в одну группу. Пользователю необходимо назначить не менее 1 группы.","selectGroup":"Выберите группу...","groupAssign":"Назначить","extendedMetadata":"Расширенные метаданные","location":"Расположение","jobTitle":"Должность","timezone":"Часовой пояс","userUpdateSuccess":"Пользователь успешно обновлен.","userAlreadyAssignedToGroup":"Пользователь уже назначен в эту группу!","deleteConfirmTitle":"Удалить пользователя?","deleteConfirmText":"Вы уверены, что хотите удалить пользователя {{username}}?","updateUser":"Обновить пользователя","groupAssignNotice":"Обратите внимание, что на этой панели нельзя назначать пользователей в группы «Администраторы» или «Гости».","deleteConfirmForeignNotice":"Обратите внимание, что вы не можете удалить пользователя, который уже создал контент. Вместо этого вы должны либо деактивировать пользователя, либо удалить весь контент, созданный этим пользователем.","userVerifySuccess":"Пользователь успешно прошел проверку.","userActivateSuccess":"Пользователь успешно активирован.","userDeactivateSuccess":"Пользователь успешно деактивирован.","deleteConfirmReplaceWarn":"Любые материалы, созданные текущим пользователем (страницы, загрузки, комментарии и т.д.), будут назначены пользователю, выбранному далее. Рекомендуем создать служебную учетную запись (пример: Deleted User), если не хотите назначать материалы активным пользователям.","userTFADisableSuccess":"Двухфакторная аутентификация успешно отключена.","userTFAEnableSuccess":"Двухфакторная аутентификация успешно включена."},"auth":{"title":"Авторизация","subtitle":"Настройте параметры авторизации в вики","strategies":"Способы авторизации","globalAdvSettings":"Глобальные расширенные настройки","jwtAudience":"JWT Audience","jwtAudienceHint":"URN-адрес авторизации с помощью JSON Web Token (JWT). Обычно используется ваше доменное имя (например, urn:your.domain.com)","tokenExpiration":"Срок действия токена","tokenExpirationHint":"Срок действия токена до следующего продления. (по умолчанию: 30мин)","tokenRenewalPeriod":"Период продления токена","tokenRenewalPeriodHint":"Максимальный период времени, в течение которого токен с истекшим сроком действия может быть продлён. (по умолчанию: 14дн)","strategyState":"Способ авторизации {{state}} {{locked}}","strategyStateActive":"активен","strategyStateInactive":"не активен","strategyStateLocked":"и не может быть отключен.","strategyConfiguration":"Настройка способа авторизации","strategyNoConfiguration":"Данный способ авторизации не содержит редактируемых настроек.","registration":"Регистрация","selfRegistration":"Разрешить самостоятельную регистрацию","selfRegistrationHint":"Разрешить любому пользователю, успешно авторизованному данным способом, доступ к вики.","domainsWhitelist":"Ограничить указанными почтовыми доменами","domainsWhitelistHint":"Электронная почта должна быть на одном из перечисленных доменов, чтобы пользователь мог самостоятельно зарегистрироваться.","autoEnrollGroups":"Назначить в группу","autoEnrollGroupsHint":"Автоматически назначать новых пользователей в эти группы.","security":"Безопасность","force2fa":"Все пользователи обязаны использовать двухфакторную аутентификацию (2FA)","force2faHint":"Пользователи обязаны настроить двухфакторную аутентификацию (2FA) при первом входе в систему, и не смогут отключить данную опцию.","configReference":"Справка по конфигурации","configReferenceSubtitle":"Некоторые способы авторизации могут требовать дополнительных настроек на стороне вашего провайдера. Они предоставлены исключительно для справки и могут не потребоваться в текущей конфигурации.","siteUrlNotSetup":"Вам необходимо задать корректный {{siteUrl}} ! Перейдите в {{general}} в левой боковой панели.","allowedWebOrigins":"Разрешенные Web Origins","callbackUrl":"Callback URL / Redirect URI","loginUrl":"URL-адрес входа","logoutUrl":"URL-адрес выхода","tokenEndpointAuthMethod":"Метод проверки подлинности Token Endpoint","refreshSuccess":"Список способов авторизации обновлен.","saveSuccess":"Настройки авторизации успешно сохранены.","activeStrategies":"Активные стратегии","addStrategy":"Добавить стратегию","strategyIsEnabled":"Активно","strategyIsEnabledHint":"Могут ли пользователи входить в систему используя данную стратегию?","displayName":"Отображаемое имя","displayNameHint":"Название, отображаемое конечному пользователю для этого способа аутентификации."},"editor":{"title":"Редактор"},"logging":{"title":"Журналы"},"rendering":{"title":"Рендеринг","subtitle":"Настройка конвейера рендеринга страницы"},"search":{"title":"Поисковая система","subtitle":"Настройте поисковые возможности вашей вики","rebuildIndex":"Перестроить индекс","searchEngine":"Поисковая система","engineConfig":"Настройки поисковой системы","engineNoConfig":"Выбранная поисковая система не содержит настроек.","listRefreshSuccess":"Список поисковых систем обновлен.","configSaveSuccess":"Настройки поисковой системы успешно сохранены.","indexRebuildSuccess":"Индекс успешно перестроен."},"storage":{"title":"Хранилище","subtitle":"Задайте репозитории для резервного копирования и синхронизации вашего контента","targets":"Репозитории","status":"Статус","lastSync":"Последняя синхронизация {{time}}","lastSyncAttempt":"Последняя попытка была {{time}}","errorMsg":"Сообщение об ошибке","noTarget":"У вас нет активного репозитория.","targetConfig":"Настройки репозитория","noConfigOption":"Данный репозиторий не содержит доступных для изменения настроек.","syncDirection":"Направление синхронизации","syncDirectionSubtitle":"Выберите способ синхронизации данных для указанного репозитория.","syncDirBi":"Двунаправленная синхронизация","syncDirPush":"Отправить (push) в репозиторий","syncDirPull":"Извлечь (pull) из репозитория","unsupported":"Не поддерживается","syncDirBiHint":"В двунаправленном режиме контент сначала извлекается (pull) из репозитория и перезаписывает локальные данные. Новый контент, созданный с момента последней синхронизации, затем передается в репозиторий и перезаписывает все существующее там содержимое.","syncDirPushHint":"Контент всегда отправляется (push) в репозиторий, перезаписывая все существующее там содержимое. Данная опция является наиболее безопасной для резервного копирования.","syncDirPullHint":"Контент всегда извлекается (pull) из репозитория, перезаписывая весь существующий локальный контент. Данная опция обычно используется для одноразового импорта данных. Будьте осторожны с данной опцией, поскольку весь локальный контент будет перезаписан!","syncSchedule":"Расписание синхронизации","syncScheduleHint":"По соображениям производительности, синхронизация изменений с хранилищем производится по заданному расписанию, а не по каждому изменению. Определите интервал периодической синхронизации.","syncScheduleCurrent":"Текущая настройка - каждые {{schedule}}","syncScheduleDefault":"По умолчанию - каждые {{schedule}}.","actions":"Действия","actionRun":"Запуск","targetState":"Целевое хранилище {{state}}","targetStateActive":"активно","targetStateInactive":"не активно","actionsInactiveWarn":"Вы должны включить целевое хранилище и применить изменения, прежде чем сможете выполнять действия."},"api":{"title":"Доступ к API","subtitle":"Управление ключами для доступа к API","enabled":"API включено","disabled":"API отключено","enableButton":"Включить API","disableButton":"Отключить API","newKeyButton":"Новый ключ API","headerName":"Имя","headerKeyEnding":"Окончание ключа","headerExpiration":"Срок действия","headerCreated":"Создан","headerLastUpdated":"Последнее обновление","headerRevoke":"Отозвать","noKeyInfo":"Ключи API еще не созданы.","revokeConfirm":"Отозвать ключ API?","revokeConfirmText":"Вы уверены, что хотите отозвать ключ {{name}} ? Это действие не может быть отменено!","revoke":"Отозвать","refreshSuccess":"Список ключей API обновлен.","revokeSuccess":"Ключ был успешно отозван.","newKeyTitle":"Новый ключ API","newKeySuccess":"Ключ API создан успешно.","newKeyNameError":"Имя отсутствует или недействительно.","newKeyGroupError":"Вы должны выбрать группу.","newKeyGuestGroupError":"Группа гостей не может использоваться для ключей API.","newKeyNameHint":"Назначение этого ключа","newKeyName":"Имя","newKeyExpiration":"Срок действия","newKeyExpirationHint":"Вы все еще можете отозвать ключ в любое время, независимо от истечения срока действия.","newKeyPermissionScopes":"Области разрешения","newKeyFullAccess":"Полный доступ","newKeyGroupPermissions":"или используйте групповые разрешения ...","newKeyGroup":"Группа","newKeyGroupHint":"Ключ API будет иметь те же разрешения, что и выбранная группа.","expiration30d":"30 дней","expiration90d":"90 дней","expiration180d":"180 дней","expiration1y":"1 год","expiration3y":"3 года","newKeyCopyWarn":"Скопируйте указанный ниже ключ как {{bold}}","newKeyCopyWarnBold":"он НЕ будет показан снова","toggleStateEnabledSuccess":"API был успешно включен.","toggleStateDisabledSuccess":"API был успешно отключен."},"system":{"title":"Системная информация","subtitle":"Информация о вашей системе","hostInfo":"Информация об узле","currentVersion":"Текущая версия","latestVersion":"Последняя версия","published":"Опубликовано","os":"Операционная система","hostname":"Имя узла","cpuCores":"Ядер процессора","totalRAM":"Всего ОЗУ","workingDirectory":"Рабочий каталог","configFile":"Файл конфигурации","ramUsage":"Использование ОЗУ: {{used}} / {{total}}","dbPartialSupport":"Ваша версия базы данных не полностью поддерживается. Некоторые функции могут быть ограничены или работать не так, как ожидалось.","refreshSuccess":"Системная информация обновлена."},"utilities":{"title":"Утилиты","subtitle":"Обслуживание и прочие инструменты","tools":"Инструменты","authTitle":"Аутентификация","authSubtitle":"Различные инструменты для аутентификации / пользователей","cacheTitle":"Очистить кэш","cacheSubtitle":"Очистка кеша различных компонентов","graphEndpointTitle":"Конечная точка GraphQL","graphEndpointSubtitle":"Изменить конечную точку GraphQL для Wiki.js","importv1Title":"Импорт из Wiki.js 1.x","importv1Subtitle":"Перенос данных с предыдущей установки 1.x","telemetryTitle":"Телеметрия","telemetrySubtitle":"Включить / отключить телеметрию или сбросить ID клиента","contentTitle":"Содержание","contentSubtitle":"Различные инструменты для страниц","exportTitle":"Сохранить на диск","exportSubtitle":"Сохранить содержимое в архив для резервирования / миграции"},"dev":{"title":"Инструменты разработчика","flags":{"title":"Флаги"},"graphiql":{"title":"GraphiQL"},"voyager":{"title":"Voyager"}},"contribute":{"title":"Внесите вклад в развитие Wiki.js","subtitle":"Помогите поддержать разработку и операции Wiki.js","fundOurWork":"Профинансируйте нашу работу","spreadTheWord":"Поделиться","talkToFriends":"Расскажите друзьям и коллегам о том, как крута Wiki.js!","followUsOnTwitter":"Подпишитесь на нас в {{0}}.","submitAnIdea":"Предложите идею или проголосуйте за существующую на {{0}}.","submitAnIdeaLink":"странице запроса новых функций","foundABug":"Нашли ошибку? Сообщите о ней на {{0}}.","helpTranslate":"Помогите перевести Wiki.js на Ваш язык. Дайте нам знать на {{0}}.","makeADonation":"Сделать пожертвование","contribute":"Поддержите","openCollective":"Wiki.js также является частью инициативы Open Collective, прозрачного фонда, который направляется на ресурсы сообщества. Вы можете внести финансовый вклад, сделав ежемесячное или разовое пожертвование:","needYourHelp":"Нам нужна ваша помощь, чтобы продолжать совершенствовать программное обеспечение и запускать различные сопутствующие услуги (например, хостинг и работа в сети).","openSource":"Wiki.js - это бесплатное программное обеспечение с открытым исходным кодом, созданное с {{0}} в {{1}} при содействии {{2}}.","openSourceContributors":"нас поддерживают","tshirts":"Для поддержания проекта Вы можете приобрести футболки Wiki.js:","shop":"Магазин Wiki.js","becomeAPatron":"Сделать пожертвование","patreon":"Станьте спонсором через Patreon (средства идут на поддержку ведущего разработчика Nicolas Giard, работающего полный рабочий день на Wiki.js).","paypal":"Сделайте одноразовое или повторяющееся пожертвование через Paypal:","ethereum":"Мы принимаем пожертвования с помощью Ethereum:","github":"Стать спонсором через GitHub Sponsors (средства идут в поддержку ведущего разработчика Николаса Джарда, чтобы он мог работать над Wiki.js полный рабочий день).","becomeASponsor":"Стать спонсором"},"nav":{"site":"Сайт","users":"Пользователи","modules":"Модули","system":"Система"},"pages":{"title":"Страницы"},"navigation":{"title":"Навигация","subtitle":"Управление навигацией по сайту","link":"Ссылка","divider":"Разделитель","header":"Заголовок","label":"Текст","icon":"Иконка","targetType":"Тип ссылки","target":"Ссылка","noSelectionText":"Выберите элемент навигации слева.","untitled":"{{kind}} без названия","navType":{"external":"Внешняя ссылка","home":"Главная","page":"Страница","searchQuery":"Поисковый запрос","externalblank":"Внешняя ссылка (Новое окно)"},"edit":"{{kind}}: редактирование","delete":"Удалить","saveSuccess":"Навигация успешно сохранена.","noItemsText":"Нажмите на кнопку Добавить для добавления первого элемента навигации.","emptyList":"Навигация пуста","visibilityMode":{"all":"Видят все","restricted":"Видят только следующие группы..."},"selectPageButton":"Выберите страницу...","mode":"Режим навигации","modeSiteTree":{"title":"Дерево сайта","description":"Классическая древовидная навигация"},"modeCustom":{"title":"Пользовательская навигация","description":"Статическое навигационное меню + кнопка дерева сайта"},"modeNone":{"title":"Пусто","description":"Отключить навигацию по сайту"},"copyFromLocale":"Копировать из локали...","sourceLocale":"Выбрать язык","sourceLocaleHint":"Язык, из которого будут скопированы элементы навигации.","copyFromLocaleInfoText":"Выберите язык, из которого хотите скопировать элементы. Они будут добавлены в список элементов текущего языка.","modeStatic":{"title":"Статическая навигация","description":"Только статическое меню навигации"}},"mail":{"title":"Почта","subtitle":"Настроить параметры почты","configuration":"Настройка","dkim":"DKIM (опционально)","test":"Отправить тестовое письмо по электронной почте","testRecipient":"Адрес электронной почты получателя","testSend":"Отправить письмо","sender":"Отправитель","senderName":"Имя отправителя","senderEmail":"Электронная почта отправителя","smtp":"Настройки SMTP","smtpHost":"Узел","smtpPort":"Порт","smtpPortHint":"Обычно 465 (рекомендуется), 587 или 25.","smtpTLS":"Безопасный (TLS)","smtpTLSHint":"Должно быть включено при использовании порта 465, в противном случае выключено (587 или 25).","smtpUser":"Имя пользователя","smtpPwd":"Пароль","dkimHint":"DKIM (DomainKeys Identified Mail) обеспечивает безопасность для всех писем, отправленных с Wiki.js, предоставляя получателям средства для проверки доменного имени и обеспечения подлинности сообщения.","dkimUse":"Использовать DKIM","dkimDomainName":"Доменное имя","dkimKeySelector":"Key Selector","dkimPrivateKey":"Private Key","dkimPrivateKeyHint":"Private key для селектора в формате PEM","testHint":"Отправить тестовое письмо для проверки работоспособности конфигурации SMTP","saveSuccess":"Настройки успешно сохранены.","sendTestSuccess":"Тестовое письмо успешно отправлено.","smtpVerifySSL":"Проверить SSL-сертификат","smtpVerifySSLHint":"Некоторые узлы требуют отключения проверки сертификатов SSL. Оставьте включенным для лучшей безопасности.","smtpName":"Идентификация клиента по имени хоста","smtpNameHint":"Необязательное имя для отправки на SMTP-сервер для идентификации вашей почтовой программы. Оставьте пустым, чтобы использовать имя хоста сервера. Для клиентов Google Workspace это должно быть вашим основным доменным именем."},"webhooks":{"title":"Вебхуки","subtitle":"Управление вебхуками для внешних сервисов"},"adminArea":"Администрирование","analytics":{"title":"Аналитика","subtitle":"Добавьте аналитику и инструменты отслеживания на свою вики","providers":"Провайдеры","providerConfiguration":"Настройки провайдера","providerNoConfiguration":"У этого провайдера нет изменяемых параметров конфигурации.","refreshSuccess":"Список провайдеров успешно обновлен.","saveSuccess":"Настройки аналитики успешно сохранены"},"comments":{"title":"Комментарии","provider":"Провайдер","subtitle":"Добавить обсуждения на страницы вики","providerConfig":"Конфигурация провайдера","providerNoConfig":"У этого провайдера нет изменяемых параметров конфигурации.","configSaveSuccess":"Конфигурация комментариев успешно сохранена."},"tags":{"title":"Теги","subtitle":"Управление тегами страницы","emptyList":"Нет тегов для отображения.","edit":"Редактировать тег","tag":"Тег","label":"Ярлык","date":"Создан {{created}} и последний раз обновлялся {{updated}}.","delete":"Удалить этот тег","noSelectionText":"Выберите тег из списка слева.","noItemsText":"Добавьте тег на страницу, чтобы начать работу.","refreshSuccess":"Теги были обновлены.","deleteSuccess":"Тег успешно удален.","saveSuccess":"Тег успешно сохранен.","filter":"Фильтр...","viewLinkedPages":"Просмотр связанных страниц","deleteConfirm":"Удалить тег?","deleteConfirmText":"Вы уверены, что хотите удалить тег {{tag}} ? Тег также будет удален со всех страниц."},"ssl":{"title":"SSL","subtitle":"Управление конфигурацией SSL","provider":"Провайдер","providerHint":"Выберите собственный сертификат, если он у вас уже есть.","domain":"Домен","domainHint":"Введите полный домен, указывающий на вашу вики. (например, wiki.example.com)","providerOptions":"Параметры провайдера","providerDisabled":"Отключено","providerLetsEncrypt":"Let's Encrypt","providerCustomCertificate":"Пользовательский сертификат","ports":"Порты","httpPort":"HTTP-порт","httpPortHint":"Не SSL-порт, который будет прослушиваться сервером для HTTP-запросов. Обычно 80 или 3000.","httpsPort":"Порт HTTPS","httpsPortHint":"SSL-порт, который будет прослушиваться сервером на предмет HTTPS-запросов. Обычно 443.","httpPortRedirect":"Перенаправить HTTP-запросы на HTTPS","httpPortRedirectHint":"Автоматически перенаправлять все HTTP запросы на HTTPS.","writableConfigFileWarning":"Обратите внимание, что конфигурационный файл должен быть доступен для записи, чтобы сохранять конфигурацию портов.","renewCertificate":"Обновить сертификат","status":"Статус сертификата","expiration":"Срок действия сертификата","subscriberEmail":"Электронная почта подписчика","currentState":"Текущее состояние","httpPortRedirectTurnOn":"Включить","httpPortRedirectTurnOff":"Выключить","renewCertificateLoadingTitle":"Обновление сертификата ...","renewCertificateLoadingSubtitle":"Не покидайте эту страницу.","renewCertificateSuccess":"Сертификат успешно обновлен.","httpPortRedirectSaveSuccess":"Перенаправление HTTP успешно изменено."},"security":{"title":"Безопасность","maxUploadSize":"Максимальный размер для загрузки","maxUploadBatch":"Максимум файлов для загрузки","maxUploadBatchHint":"Сколько файлов можно загрузить за один раз?","maxUploadSizeHint":"Максимальный размер для одного файла.","maxUploadSizeSuffix":"байты","maxUploadBatchSuffix":"файлы","uploads":"Загрузки","uploadsInfo":"Эти настройки влияют только на Wiki.js. Если вы используете обратный прокси-сервер (например, nginx, apache, Cloudflare), вы также должны изменить его настройки для соответствия.","subtitle":"Настроить параметры безопасности","login":"Вход","loginScreen":"Экран входа","jwt":"Конфигурация JWT","bypassLogin":"Пропустить экран входа","bypassLoginHint":"Автоматически перенаправлять пользователя к первому провайдеру аутентификации минуя экран входа.","loginBgUrl":"URL фонового изображения для входа","loginBgUrlHint":"Изображение для использования в качестве фона входа. Поддерживаются PNG и JPG, рекомендуется размер 1920x1080. Оставьте поле пустым чтобы использовать изображение по-умолчанию. Нажмите кнопку справа чтобы загрузить новое изображение. Обратите внимание что группа «Guests» должна иметь право на чтение выбранного изображения!","hideLocalLogin":"Скрыть поставщика локальной аутентификации","hideLocalLoginHint":"Не отображать локального поставщика аутентификации на экране входа. Допишите ?all в конце URL, если потребуется обойти эту настройку.","loginSecurity":"Безопасность","enforce2fa":"Принудительная двухфакторная аутентификация (2FA)","enforce2faHint":"Принудить всех пользователей использовать двухфакторную аутентификацию при использовании поставщика аутентификации с формой пользователя/пароля."},"extensions":{"title":"Расширения","subtitle":"Установить расширения для дополнительной функциональности"}},"editor":{"page":"Страница","save":{"processing":"Рендеринг","pleaseWait":"Пожалуйста, подождите...","createSuccess":"Страница создана успешно.","error":"Произошла ошибка при создании страницы","updateSuccess":"Страница успешно обновлена.","saved":"Сохранено"},"props":{"pageProperties":"Свойства страницы","pageInfo":"Информация о странице","title":"Заголовок","shortDescription":"Краткое описание","shortDescriptionHint":"Показано под заголовком","pathCategorization":"Путь и категория","locale":"Язык","path":"Путь","pathHint":"Не включайте косые черты (слэши).","tags":"Теги","tagsHint":"Используйте теги для классификации страниц и упрощения их поиска.","publishState":"Статус публикации","publishToggle":"Опубликовано","publishToggleHint":"Неопубликованные страницы могут быть просмотрены пользователями, что имеют права на изменение этих страниц.","publishStart":"Публикация начинается с...","publishStartHint":"Оставьте пустым, чтобы опубликовать без задержки","publishEnd":"Публикация заканчивается...","publishEndHint":"Оставьте пустым, если эта публикация бессрочная","info":"Информация","scheduling":"Планирование","social":"Социальные сети","categorization":"Категоризация","socialFeatures":"Социальные функции","allowComments":"Разрешить комментарии","allowCommentsHint":"Включите возможность комментирования на этой странице.","allowRatings":"Разрешить рейтинги","displayAuthor":"Отображать информацию об авторе","displaySharingBar":"Отображать панель обмена","displaySharingBarHint":"Показывать панель инструментов с кнопками обмена и печати этой страницы","displayAuthorHint":"Показывать автора страницы вместе с датой последнего изменения.","allowRatingsHint":"Включите возможность оценки этой страницы.","scripts":"Сценарии","css":"CSS","cssHint":"CSS будет автоматически уменьшена после сохранения.","styles":"Стили","html":"HTML","htmlHint":"Вы должны окружить свой код на javascript тегами HTML-скрипта.","toc":"Содержание","tocTitle":"Содержание","tocUseDefault":"Используйте настройки сайта по умолчанию","tocHeadingLevels":"Уровни заголовков содержания","tocHeadingLevelsHint":"В содержании будут показаны заголовки от выбранных уровней и выше."},"unsaved":{"title":"Отменить несохраненные изменения?","body":"У вас есть несохраненные изменения. Вы уверены, что хотите выйти из редактора и отменить все изменения, сделанные после последнего сохранения?"},"select":{"title":"Какой редактор вы хотите использовать для этой страницы?","cannotChange":"Данный выбор невозможно изменить после создания страницы.","customView":"или создать пользовательский вид?"},"assets":{"title":"Файлы","newFolder":"Новая папка","folderName":"Название папки","folderNameNamingRules":"Должно соответствовать правилам именования папок {{namingRules}}.","folderNameNamingRulesLink":"правила именования","folderEmpty":"Эта папка активов пуста.","fileCount":"{{count}} файлов","headerId":"ID","headerFilename":"Имя файла","headerType":"Тип","headerFileSize":"Размер файла","headerAdded":"Добавлен","headerActions":"Действия","uploadAssets":"Загрузить файлы","uploadAssetsDropZone":"Нажмите Обзор или перетащите файлы сюда...","fetchImage":"Загрузить изображение по ссылке","imageAlign":"Выравнивание изображения","renameAsset":"Переименовать актив","renameAssetSubtitle":"Введите новое имя для этого актива:","deleteAsset":"Удалить актив","deleteAssetConfirm":"Вы уверены, что хотите удалить актив","deleteAssetWarn":"Данное действие не может быть отменено!","refreshSuccess":"Список активов успешно обновлен.","uploadFailed":"Не удалось загрузить файл.","folderCreateSuccess":"Папка активов успешно создана.","renameSuccess":"Актив успешно переименован.","deleteSuccess":"Актив успешно удален.","noUploadError":"Сначала выберите файл для загрузки!"},"backToEditor":"Вернуться в редактор","markup":{"bold":"Жирный","italic":"Курсив","strikethrough":"Зачеркнутый","heading":"Заголовок {{level}}","subscript":"Подстрочный","superscript":"Надстрочный","blockquote":"Цитата","blockquoteInfo":"Цитата информационная","blockquoteSuccess":"Цитата успешно","blockquoteWarning":"Цитата предупреждение","blockquoteError":"Цитата ошибка","unorderedList":"Маркированный список","orderedList":"Нумерованный список","inlineCode":"Встроенный код","keyboardKey":"Кнопка клавиатуры","horizontalBar":"Горизонтальная черта","togglePreviewPane":"Скрыть / Показать панель предпросмотра","insertLink":"Вставить ссылку","insertAssets":"Вставить файлы","insertBlock":"Вставить модуль","insertCodeBlock":"Вставить код","insertVideoAudio":"Вставить видео / аудио","insertDiagram":"Вставить диаграмму","insertMathExpression":"Вставить математическое выражение","tableHelper":"Помощник по таблицам","distractionFreeMode":"Режим концентрации внимания","markdownFormattingHelp":"Справка по разметке Markdown","noSelectionError":"Сначала выделите текст!","toggleSpellcheck":"Переключить проверку орфографии"},"ckeditor":{"stats":"{{chars}} символов, {{words}} слов"},"conflict":{"title":"Исправить конфликт сохранения","useLocal":"Использовать локальную","useRemote":"Использовать удаленную","useRemoteHint":"Отменить изменения и использовать последнюю версию ","useLocalHint":"Использовать содержимое на левой панели","viewLatestVersion":"Просмотреть последнюю версию","infoGeneric":"Более свежая версия этой страницы была сохранена пользователем {{authorName}}, {{date}}.","whatToDo":"Что вы хотите сделать?","whatToDoLocal":"Использовать вашу текущую версию и игнорировать последние изменения.","whatToDoRemote":"Использовать удаленную версию (последнее) и отменить текущие изменения.","overwrite":{"title":"Заменить удаленной версией?","description":"Вы уверены, что хотите заменить вашу текущую версию на последнюю версию удаленного контента? {{refEditsLost}}","editsLost":"Ваши текущие изменения будут потеряны."},"localVersion":"Локальная версия {{refEditable}}","editable":"(редактируемо)","readonly":"(только для чтения)","remoteVersion":"Удаленная версия {{refReadOnly}}","leftPanelInfo":"Ваше текущее изменение, основанное на версии страницы от {{date}}","rightPanelInfo":"Последнее изменение: {{authorName}}, {{date}}","pageTitle":"Заголовок:","pageDescription":"Описание:","warning":"Конфликт сохранения! Другой пользователь уже изменил эту страницу."},"unsavedWarning":"У вас есть несохраненные изменения. Вы уверены, что хотите покинуть редактор?"},"tags":{"currentSelection":"Текущий выбор","clearSelection":"Очистить выбор","selectOneMoreTags":"Выберите один или несколько тегов","searchWithinResultsPlaceholder":"Поиск по результатам...","locale":"Язык","orderBy":"Сортировать по","selectOneMoreTagsHint":"Выберите один или несколько тегов слева.","retrievingResultsLoading":"Получение результатов со страницы...","noResults":"Не удалось найти страницы с выбранными тегами.","noResultsWithFilter":"Не удалось найти страницы, соответствующие текущим настройкам фильтрации.","pageLastUpdated":"Последнее обновление {{date}}","orderByField":{"creationDate":"Дата создания","ID":"ID","lastModified":"Последнее изменение","path":"Путь","title":"Заголовок"},"localeAny":"Любой"},"history":{"restore":{"confirmTitle":"Восстановить версию страницы?","confirmText":"Вы уверены, что хотите восстановить эту страницу на {{date}}? Эта версия будет скопирована поверх текущей. Таким образом, новые версии будут сохранены.","confirmButton":"Восстановить","success":"Версия страницы успешно восстановлена!"}},"profile":{"displayName":"Отображаемое имя","location":"Расположение","jobTitle":"Должность","timezone":"Часовой пояс","title":"Профиль","subtitle":"Моя личная информация","myInfo":"Моя информация","viewPublicProfile":"Просмотреть публичный профиль","auth":{"title":"Аутентификация","provider":"Провайдер","changePassword":"Сменить пароль","currentPassword":"Текущий пароль","newPassword":"Новый пароль","verifyPassword":"Подтверждение пароля","changePassSuccess":"Пароль успешно изменен."},"groups":{"title":"Группы"},"activity":{"title":"Активность","joinedOn":"Присоединился","lastUpdatedOn":"Последнее обновление профиля","lastLoginOn":"Последний вход в систему","pagesCreated":"Страницы созданы","commentsPosted":"Опубликованных комментариев"},"save":{"success":"Профиль успешно сохранен."},"pages":{"title":"Страницы","subtitle":"Список страниц, которые я создал(-а) или изменял(-а)","emptyList":"Нет страниц для отображения.","refreshSuccess":"Список страниц был обновлен.","headerTitle":"Заголовок","headerPath":"Путь","headerCreatedAt":"Создан","headerUpdatedAt":"Последнее обновление"},"comments":{"title":"Комментарии"},"preferences":"Настройки","dateFormat":"Формат даты","localeDefault":"Язык по умолчанию","appearance":"Внешний вид","appearanceDefault":"Сайт по умолчанию","appearanceLight":"Светлый режим","appearanceDark":"Темный режим"}}	f	Russian	русский язык	100	2026-03-20T16:29:53.712Z	2026-05-12T18:54:22.689Z
\.


--
-- Data for Name: loggers; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.loggers (key, "isEnabled", level, config) FROM stdin;
airbrake	f	warn	{}
bugsnag	f	warn	{"key":""}
disk	f	info	{}
eventlog	f	warn	{}
loggly	f	warn	{"token":"","subdomain":""}
logstash	f	warn	{}
newrelic	f	warn	{}
papertrail	f	warn	{"host":"","port":0}
raygun	f	warn	{}
rollbar	f	warn	{"key":""}
sentry	f	warn	{"key":""}
syslog	f	warn	{}
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.migrations (id, name, batch, migration_time) FROM stdin;
1	2.0.0.js	1	2026-03-20 16:18:21.698+00
2	2.1.85.js	1	2026-03-20 16:18:21.699+00
3	2.2.3.js	1	2026-03-20 16:18:21.702+00
4	2.2.17.js	1	2026-03-20 16:18:21.703+00
5	2.3.10.js	1	2026-03-20 16:18:21.704+00
6	2.3.23.js	1	2026-03-20 16:18:21.705+00
7	2.4.13.js	1	2026-03-20 16:18:21.707+00
8	2.4.14.js	1	2026-03-20 16:18:21.709+00
9	2.4.36.js	1	2026-03-20 16:18:21.711+00
10	2.4.61.js	1	2026-03-20 16:18:21.712+00
11	2.5.1.js	1	2026-03-20 16:18:21.715+00
12	2.5.12.js	1	2026-03-20 16:18:21.716+00
13	2.5.108.js	1	2026-03-20 16:18:21.717+00
14	2.5.118.js	1	2026-03-20 16:18:21.718+00
15	2.5.122.js	1	2026-03-20 16:18:21.719+00
16	2.5.128.js	1	2026-03-20 16:18:21.722+00
\.


--
-- Data for Name: migrations_lock; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: navigation; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.navigation (key, config) FROM stdin;
site	[{"locale":"en","items":[{"id":"8aae3476-920a-41c5-96ba-37287a7e030f","icon":"mdi-home","kind":"link","label":"Home","target":"/","targetType":"home","visibilityMode":"all","visibilityGroups":null}]}]
\.


--
-- Data for Name: pageHistory; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."pageHistory" (id, path, hash, title, description, "isPrivate", "isPublished", "publishStartDate", "publishEndDate", action, "pageId", content, "contentType", "createdAt", "editorKey", "localeCode", "authorId", "versionDate", extra) FROM stdin;
\.


--
-- Data for Name: pageHistoryTags; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."pageHistoryTags" (id, "pageId", "tagId") FROM stdin;
\.


--
-- Data for Name: pageLinks; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."pageLinks" (id, path, "localeCode", "pageId") FROM stdin;
\.


--
-- Data for Name: pageTags; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."pageTags" (id, "pageId", "tagId") FROM stdin;
\.


--
-- Data for Name: pageTree; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."pageTree" (id, path, depth, title, "isPrivate", "isFolder", "privateNS", parent, "pageId", "localeCode", ancestors) FROM stdin;
1	ClusterAPI	1	ClusterAPI	f	f	\N	\N	2	ru	[]
2	home	1	Структура AI-агента	f	f	\N	\N	1	ru	[]
\.


--
-- Data for Name: pages; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.pages (id, path, hash, title, description, "isPrivate", "isPublished", "privateNS", "publishStartDate", "publishEndDate", content, render, toc, "contentType", "createdAt", "updatedAt", "editorKey", "localeCode", "authorId", "creatorId", extra) FROM stdin;
1	home	35827cfbb14864d6ffd32eb9060e82cbf9694acd	Структура AI-агента	Описание агента	f	t	\N			# Документация AI-агента на базе n8n + Ollama + PostgreSQL + Wiki.js\n\n> **Стек:** n8n · Ollama · PostgreSQL · Wiki.js · Docker · Vagrant  \n> **Цель:** локальный AI-агент с долгосрочной памятью, изолированной БД и внутренней wiki.\n\n---\n\n## Содержание\n\n1. [Архитектура и топология сети](#1-архитектура-и-топология-сети)\n2. [Подготовка окружения (Vagrant)](#2-подготовка-окружения-vagrant)\n3. [VM: PostgreSQL — установка и настройка](#3-vm-postgresql--установка-и-настройка)\n4. [VM: n8n — Docker + первый запуск](#4-vm-n8n--docker--первый-запуск)\n5. [n8n → перевод на PostgreSQL + персистентность](#5-n8n--перевод-на-postgresql--персистентность)\n6. [VM: Ollama — Docker + LLM](#6-vm-ollama--docker--llm)\n7. [n8n: credential Ollama + минимальный workflow](#7-n8n-credential-ollama--минимальный-workflow)\n8. [n8n: AI Agent workflow](#8-n8n-ai-agent-workflow)\n9. [Память агента в PostgreSQL](#9-память-агента-в-postgresql)\n10. [VM: Wiki.js — Docker + PostgreSQL](#10-vm-wikijs--docker--postgresql)\n11. [Страница «Архитектура AI-агента» в Wiki.js](#11-страница-архитектура-ai-агента-в-wikijs)\n12. [Справочник портов и переменных](#12-справочник-портов-и-переменных)\n\n---\n\n## 1. Архитектура и топология сети\n\n```\n┌─────────────────────────────────────────────────────────────┐\n│                  Локальная подсеть 192.168.56.0/24           │\n│                                                             │\n│  ┌──────────────┐   SQL    ┌──────────────────────────────┐ │\n│  │  VM: n8n     │◄────────►│  VM: postgresql              │ │\n│  │  .10         │          │  .11                         │ │\n│  │  Docker      │          │  PostgreSQL 15               │ │\n│  │  n8n:5678    │          │  Port 5432 (только подсеть)  │ │\n│  └──────┬───────┘          │                              │ │\n│         │                  │  БД:                         │ │\n│         │ HTTP             │  • n8n_db / n8n_user         │ │\n│         │ :11434           │  • wiki_db / wiki_user       │ │\n│  ┌──────▼───────┐          │  • agent_db / agent_user     │ │\n│  │  VM: ollama  │          └──────────────────────────────┘ │\n│  │  .12         │                        ▲                  │\n│  │  Docker      │                        │ SQL              │\n│  │  Ollama      │          ┌─────────────┴──────────────┐   │\n│  └──────────────┘          │  VM: wikijs                │   │\n│                            │  .13                       │   │\n│                            │  Docker                    │   │\n│                            │  Wiki.js :3000             │   │\n│                            └────────────────────────────┘   │\n└─────────────────────────────────────────────────────────────┘\n           │ Host-only сеть (доступ с хоста)\n    Браузер хоста:\n    • n8n    → http://192.168.56.10:5678\n    • Ollama → http://192.168.56.12:11434\n    • Wiki.js→ http://192.168.56.13:3000\n```\n\n### Компоненты\n\n| Компонент | VM IP | Порт | Роль |\n|-----------|-------|------|------|\n| n8n | 192.168.56.10 | 5678 | Оркестратор воркфлоу / AI-агент |\n| PostgreSQL | 192.168.56.11 | 5432 | Хранилище данных (n8n, wiki, память) |\n| Ollama | 192.168.56.12 | 11434 | LLM inference сервер |\n| Wiki.js | 192.168.56.13 | 3000 | Внутренняя документация |\n\n---\n\n## 2. Подготовка окружения (Vagrant)\n\n### Vagrantfile\n\n```ruby\n# -*- mode: ruby -*-\n# vi: set ft=ruby :\n\nVagrant.configure("2") do |config|\n  config.vm.box = "ubuntu/jammy64"\n\n  # ── PostgreSQL ──────────────────────────────────────────────\n  config.vm.define "postgresql" do |pg|\n    pg.vm.hostname = "postgresql"\n    pg.vm.network "private_network", ip: "192.168.56.11"\n    pg.vm.provider "virtualbox" do |vb|\n      vb.memory = "1024"\n      vb.cpus   = 1\n    end\n    pg.vm.provision "shell", path: "scripts/provision_postgresql.sh"\n  end\n\n  # ── n8n ─────────────────────────────────────────────────────\n  config.vm.define "n8n" do |n8n|\n    n8n.vm.hostname = "n8n"\n    n8n.vm.network "private_network", ip: "192.168.56.10"\n    n8n.vm.network "forwarded_port", guest: 5678, host: 5678\n    n8n.vm.provider "virtualbox" do |vb|\n      vb.memory = "2048"\n      vb.cpus   = 2\n    end\n    n8n.vm.provision "shell", path: "scripts/provision_n8n.sh"\n  end\n\n  # ── Ollama ──────────────────────────────────────────────────\n  config.vm.define "ollama" do |ol|\n    ol.vm.hostname = "ollama"\n    ol.vm.network "private_network", ip: "192.168.56.12"\n    ol.vm.network "forwarded_port", guest: 11434, host: 11434\n    ol.vm.provider "virtualbox" do |vb|\n      vb.memory = "4096"   # LLM требует памяти\n      vb.cpus   = 4\n    end\n    ol.vm.provision "shell", path: "scripts/provision_ollama.sh"\n  end\n\n  # ── Wiki.js ─────────────────────────────────────────────────\n  config.vm.define "wikijs" do |wiki|\n    wiki.vm.hostname = "wikijs"\n    wiki.vm.network "private_network", ip: "192.168.56.13"\n    wiki.vm.network "forwarded_port", guest: 3000, host: 3000\n    wiki.vm.provider "virtualbox" do |vb|\n      vb.memory = "1024"\n      vb.cpus   = 1\n    end\n    wiki.vm.provision "shell", path: "scripts/provision_wikijs.sh"\n  end\nend\n```\n\n### Запуск\n\n```bash\n# Поднять все VM (займёт ~10 минут при первом запуске)\nvagrant up\n\n# Поднять отдельную VM\nvagrant up postgresql\n\n# SSH в VM\nvagrant ssh postgresql\nvagrant ssh n8n\nvagrant ssh ollama\nvagrant ssh wikijs\n\n# Остановить все\nvagrant halt\n\n# Пересоздать с нуля\nvagrant destroy -f && vagrant up\n```\n\n---\n\n## 3. VM: PostgreSQL — установка и настройка\n\n### 3.1 Установка PostgreSQL\n\n```bash\n# Файл: scripts/provision_postgresql.sh\n#!/bin/bash\nset -e\n\n# Установка PostgreSQL 15\napt-get update -qq\napt-get install -y postgresql postgresql-contrib\n\n# Запуск и автозапуск\nsystemctl enable postgresql\nsystemctl start postgresql\n```\n\n### 3.2 Настройка сетевого доступа\n\nPostgreSQL по умолчанию слушает только `localhost`. Нужно открыть доступ только из подсети VM (`192.168.56.0/24`).\n\n```bash\n# Редактируем postgresql.conf\n# Найти параметр listen_addresses\nsudo nano /etc/postgresql/15/main/postgresql.conf\n```\n\n```ini\n# postgresql.conf\nlisten_addresses = 'localhost,192.168.56.11'\n```\n\n```bash\n# Редактируем pg_hba.conf — правила аутентификации\nsudo nano /etc/postgresql/15/main/pg_hba.conf\n```\n\n```\n# pg_hba.conf — добавить строки в конец файла\n# TYPE  DATABASE        USER            ADDRESS                 METHOD\nhost    n8n_db          n8n_user        192.168.56.0/24         scram-sha-256\nhost    wiki_db         wiki_user       192.168.56.0/24         scram-sha-256\nhost    agent_db        agent_user      192.168.56.0/24         scram-sha-256\n```\n\n```bash\n# Применить изменения\nsudo systemctl restart postgresql\n```\n\n### 3.3 Создание баз данных и пользователей\n\n```bash\nsudo -u postgres psql << 'EOF'\n-- ── Пользователь и БД для n8n ──────────────────────────────\nCREATE USER n8n_user WITH PASSWORD 'n8n_strong_password_123';\nCREATE DATABASE n8n_db OWNER n8n_user;\nGRANT ALL PRIVILEGES ON DATABASE n8n_db TO n8n_user;\n\n-- ── Пользователь и БД для Wiki.js ──────────────────────────\nCREATE USER wiki_user WITH PASSWORD 'wiki_strong_password_123';\nCREATE DATABASE wiki_db OWNER wiki_user;\nGRANT ALL PRIVILEGES ON DATABASE wiki_db TO wiki_user;\n\n-- ── Пользователь и БД для памяти агента ────────────────────\nCREATE USER agent_user WITH PASSWORD 'agent_strong_password_123';\nCREATE DATABASE agent_db OWNER agent_user;\nGRANT ALL PRIVILEGES ON DATABASE agent_db TO agent_user;\n\n-- Проверка\n\\l\n\\du\nEOF\n```\n\n### 3.4 Проверка доступности из других VM\n\n```bash\n# С VM n8n (192.168.56.10) — проверяем подключение к PostgreSQL\npsql -h 192.168.56.11 -U n8n_user -d n8n_db -c "SELECT version();"\n# Пароль: n8n_strong_password_123\n\n# С VM wikijs (192.168.56.13) — аналогично\npsql -h 192.168.56.11 -U wiki_user -d wiki_db -c "SELECT version();"\n```\n\n### 3.5 Проверка ограничения доступа\n\n```bash\n# С внешней машины (не из подсети 192.168.56.0/24) — должен получить отказ\npsql -h 192.168.56.11 -U n8n_user -d n8n_db\n# Ожидаемый результат: connection refused или authentication failed\n```\n\n---\n\n## 4. VM: n8n — Docker + первый запуск\n\n### 4.1 Установка Docker\n\n```bash\n# Файл: scripts/provision_n8n.sh\n#!/bin/bash\nset -e\n\n# Установка Docker (официальный способ)\napt-get update -qq\napt-get install -y ca-certificates curl gnupg\n\ninstall -m 0755 -d /etc/apt/keyrings\ncurl -fsSL https://download.docker.com/linux/ubuntu/gpg \\\n  | gpg --dearmor -o /etc/apt/keyrings/docker.gpg\nchmod a+r /etc/apt/keyrings/docker.gpg\n\necho "deb [arch=$(dpkg --print-architecture) \\\n  signed-by=/etc/apt/keyrings/docker.gpg] \\\n  https://download.docker.com/linux/ubuntu \\\n  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \\\n  | tee /etc/apt/sources.list.d/docker.list > /dev/null\n\napt-get update -qq\napt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin\n\n# Добавить vagrant в группу docker\nusermod -aG docker vagrant\n\nsystemctl enable docker\nsystemctl start docker\n```\n\n### 4.2 Первый запуск n8n (SQLite, для проверки UI)\n\n```bash\n# Самый простой запуск — n8n с SQLite (временно, для проверки UI)\ndocker run -d \\\n  --name n8n \\\n  --restart unless-stopped \\\n  -p 5678:5678 \\\n  -e N8N_HOST=0.0.0.0 \\\n  -e WEBHOOK_URL=http://192.168.56.10:5678 \\\n  n8nio/n8n:latest\n\n# Проверить статус\ndocker ps\ndocker logs n8n -f\n```\n\n### 4.3 Проверка UI\n\nОткрой в браузере: **http://192.168.56.10:5678** (или http://localhost:5678 если пробросил порт)\n\n1. Пройди первичную регистрацию (имя, email, пароль)\n2. Нажми **"+ New workflow"**\n3. Убедись, что пустой воркфлоу создаётся и сохраняется\n\n---\n\n## 5. n8n → перевод на PostgreSQL + персистентность\n\n### 5.1 Остановить временный контейнер\n\n```bash\ndocker stop n8n && docker rm n8n\n```\n\n### 5.2 Создать volume для данных n8n\n\n```bash\ndocker volume create n8n_data\n```\n\n### 5.3 Запустить n8n с PostgreSQL\n\n```bash\ndocker run -d \\\n  --name n8n \\\n  --restart unless-stopped \\\n  -p 5678:5678 \\\n  -v n8n_data:/home/node/.n8n \\\n  -e N8N_HOST=0.0.0.0 \\\n  -e WEBHOOK_URL=http://192.168.56.10:5678 \\\n  -e DB_TYPE=postgresdb \\\n  -e DB_POSTGRESDB_HOST=192.168.56.11 \\\n  -e DB_POSTGRESDB_PORT=5432 \\\n  -e DB_POSTGRESDB_DATABASE=n8n_db \\\n  -e DB_POSTGRESDB_USER=n8n_user \\\n  -e DB_POSTGRESDB_PASSWORD=n8n_strong_password_123 \\\n  -e N8N_ENCRYPTION_KEY=change-this-to-random-32-char-string \\\n  n8nio/n8n:latest\n```\n\n> ⚠️ `N8N_ENCRYPTION_KEY` — произвольная строка длиной 32+ символа. Запиши её и не меняй: она шифрует credentials.\n\n### 5.4 Альтернатива: docker-compose (рекомендуется)\n\n```bash\nmkdir -p /opt/n8n && cd /opt/n8n\nnano docker-compose.yml\n```\n\n```yaml\n# /opt/n8n/docker-compose.yml\nversion: "3.8"\n\nservices:\n  n8n:\n    image: n8nio/n8n:latest\n    container_name: n8n\n    restart: unless-stopped\n    ports:\n      - "5678:5678"\n    volumes:\n      - n8n_data:/home/node/.n8n\n    environment:\n      - N8N_HOST=0.0.0.0\n      - WEBHOOK_URL=http://192.168.56.10:5678\n      - DB_TYPE=postgresdb\n      - DB_POSTGRESDB_HOST=192.168.56.11\n      - DB_POSTGRESDB_PORT=5432\n      - DB_POSTGRESDB_DATABASE=n8n_db\n      - DB_POSTGRESDB_USER=n8n_user\n      - DB_POSTGRESDB_PASSWORD=n8n_strong_password_123\n      - N8N_ENCRYPTION_KEY=change-this-to-random-32-char-string\n\nvolumes:\n  n8n_data:\n```\n\n```bash\ndocker compose up -d\ndocker compose logs -f\n```\n\n### 5.5 Проверка персистентности\n\n```bash\n# 1. Открыть n8n UI и создать воркфлоу с каким-нибудь именем\n# 2. Перезапустить контейнер\ndocker restart n8n\n\n# 3. Открыть UI снова — воркфлоу должен быть на месте\n# 4. Проверить данные в PostgreSQL\npsql -h 192.168.56.11 -U n8n_user -d n8n_db -c "SELECT name, created_at FROM workflow_entity;"\n```\n\n---\n\n## 6. VM: Ollama — Docker + LLM\n\n### 6.1 Установка Docker (аналогично n8n)\n\n```bash\n# Файл: scripts/provision_ollama.sh\n#!/bin/bash\nset -e\n\napt-get update -qq\napt-get install -y ca-certificates curl gnupg\n\ninstall -m 0755 -d /etc/apt/keyrings\ncurl -fsSL https://download.docker.com/linux/ubuntu/gpg \\\n  | gpg --dearmor -o /etc/apt/keyrings/docker.gpg\nchmod a+r /etc/apt/keyrings/docker.gpg\n\necho "deb [arch=$(dpkg --print-architecture) \\\n  signed-by=/etc/apt/keyrings/docker.gpg] \\\n  https://download.docker.com/linux/ubuntu \\\n  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \\\n  | tee /etc/apt/sources.list.d/docker.list > /dev/null\n\napt-get update -qq\napt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin\nusermod -aG docker vagrant\nsystemctl enable docker\nsystemctl start docker\n```\n\n### 6.2 Запуск Ollama в Docker\n\n```bash\nmkdir -p /opt/ollama && cd /opt/ollama\nnano docker-compose.yml\n```\n\n```yaml\n# /opt/ollama/docker-compose.yml\nversion: "3.8"\n\nservices:\n  ollama:\n    image: ollama/ollama:latest\n    container_name: ollama\n    restart: unless-stopped\n    ports:\n      - "11434:11434"\n    volumes:\n      - ollama_data:/root/.ollama\n    environment:\n      - OLLAMA_HOST=0.0.0.0\n\nvolumes:\n  ollama_data:\n```\n\n```bash\ndocker compose up -d\ndocker compose logs -f\n```\n\n### 6.3 Загрузка модели\n\n```bash\n# Войти в контейнер\ndocker exec -it ollama ollama pull llama3.2\n\n# Другие подходящие модели (выбери одну под свои ресурсы):\n# docker exec -it ollama ollama pull qwen2.5:3b     # лёгкая ~2GB\n# docker exec -it ollama ollama pull mistral:7b     # хорошая ~4GB\n# docker exec -it ollama ollama pull llama3.2:3b    # рекомендуем ~2GB\n\n# Список загруженных моделей\ndocker exec -it ollama ollama list\n```\n\n### 6.4 Проверка через CLI\n\n```bash\n# Тест прямо в терминале\ndocker exec -it ollama ollama run llama3.2 "Привет! Кто ты?"\n# Введи /bye чтобы выйти\n```\n\n### 6.5 Проверка через API\n\n```bash\n# С VM ollama (или любой VM в подсети)\ncurl http://localhost:11434/api/generate \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "model": "llama3.2",\n    "prompt": "Скажи привет по-русски.",\n    "stream": false\n  }'\n\n# С другой VM в подсети\ncurl http://192.168.56.12:11434/api/generate \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "model": "llama3.2",\n    "prompt": "Hello!",\n    "stream": false\n  }'\n\n# Проверить список моделей через API\ncurl http://192.168.56.12:11434/api/tags\n```\n\n---\n\n## 7. n8n: credential Ollama + минимальный workflow\n\n### 7.1 Создание Credential для Ollama\n\n1. Открой **http://192.168.56.10:5678**\n2. Перейди в **Settings → Credentials → New Credential**\n3. Выбери тип: **Ollama API**\n4. Заполни:\n   - **Base URL:** `http://192.168.56.12:11434`\n5. Нажми **Save** и **Test connection** — должен получить ✅\n\n### 7.2 Минимальный workflow: Chat → Ollama\n\nСоздай новый воркфлоу с тремя нодами:\n\n```\n[Chat Trigger] ──► [Ollama Chat Model] ──► (ответ в чат)\n```\n\n**Нода 1: Chat Trigger**\n- Тип: `Chat Trigger`\n- Режим: `Respond to Webhook`\n\n**Нода 2: Basic LLM Chain**\n- Тип: `Basic LLM Chain`\n- Chat Model: выбери `Ollama Chat Model`\n  - Credential: выбери созданный credential\n  - Model: `llama3.2`\n\n**Активация воркфлоу:**\n- Нажми переключатель **Active** (вверху справа)\n\n### 7.3 Тест в чате\n\n1. Нажми **Open Chat** (или перейди по ссылке воркфлоу)\n2. Напиши: `"Привет! Как тебя зовут?"`\n3. Проверь, что ответ возвращается из Ollama\n\n---\n\n## 8. n8n: AI Agent workflow\n\n### 8.1 Схема воркфлоу\n\n```\n[Chat Trigger] ──► [AI Agent] ──► [Ollama Chat Model]\n                       │\n                  [Window Buffer Memory]\n```\n\n### 8.2 Создание воркфлоу\n\n**Нода 1: Chat Trigger**\n- Тип: `Chat Trigger`\n\n**Нода 2: AI Agent**\n- Тип: `AI Agent`\n- Подключи к Chat Trigger\n- Agent Type: `Conversational Agent`\n- System Message:\n  ```\n  Ты полезный AI-ассистент. Отвечай на русском языке.\n  Помни контекст разговора и используй его в своих ответах.\n  ```\n\n**Нода 3: Ollama Chat Model** (подключить к AI Agent → Chat Model)\n- Тип: `Ollama Chat Model`\n- Credential: твой Ollama credential\n- Model: `llama3.2`\n- Temperature: `0.7`\n\n**Нода 4: Window Buffer Memory** (подключить к AI Agent → Memory)\n- Тип: `Window Buffer Memory`\n- Session Key: `={{ $('Chat Trigger').item.json.sessionId }}`\n- Context Window Length: `10` (запоминать последние 10 сообщений)\n\n### 8.3 Тест агента (3–5 запросов)\n\nПротестируй последовательно в чате:\n\n```\n1. "Привет! Меня зовут Саня."\n   → Агент должен поприветствовать тебя по имени\n\n2. "Что ты умеешь?"\n   → Агент описывает возможности\n\n3. "Как меня зовут?"\n   → Агент должен ответить: "Тебя зовут Саня"\n\n4. "Придумай мне шутку про программирование"\n   → Агент генерирует шутку\n\n5. "Переведи на английский то, что ты только что сказал"\n   → Агент переводит предыдущий ответ (помнит контекст)\n```\n\n---\n\n## 9. Память агента в PostgreSQL\n\n### 9.1 Создание таблицы для памяти\n\n```bash\n# Подключиться к agent_db\npsql -h 192.168.56.11 -U agent_user -d agent_db << 'EOF'\nCREATE TABLE IF NOT EXISTS agent_memory (\n    id          SERIAL PRIMARY KEY,\n    session_id  VARCHAR(255) NOT NULL,\n    role        VARCHAR(50)  NOT NULL,  -- 'user' или 'assistant'\n    content     TEXT         NOT NULL,\n    created_at  TIMESTAMPTZ  DEFAULT NOW()\n);\n\nCREATE INDEX IF NOT EXISTS idx_agent_memory_session\n    ON agent_memory(session_id, created_at);\n\n-- Проверка\n\\d agent_memory\nEOF\n```\n\n### 9.2 Настройка Postgres Chat Memory в n8n\n\nВместо `Window Buffer Memory` используй **Postgres Chat Memory**:\n\n**Нода Memory: Postgres Chat Memory**\n- Тип: `Postgres Chat Memory`\n- Credential: создай новый `PostgreSQL` credential:\n  - Host: `192.168.56.11`\n  - Port: `5432`\n  - Database: `agent_db`\n  - User: `agent_user`\n  - Password: `agent_strong_password_123`\n- Table Name: `agent_memory`\n- Session ID: `={{ $('Chat Trigger').item.json.sessionId }}`\n- Context Window Length: `20`\n\n### 9.3 Схема воркфлоу с PostgreSQL памятью\n\n```\n[Chat Trigger] ──► [AI Agent] ──► [Ollama Chat Model]\n                       │\n               [Postgres Chat Memory]\n                  (agent_db на 192.168.56.11)\n```\n\n### 9.4 Тест персистентной памяти\n\n```bash\n# Шаг 1: Отправь сообщение в чат\n# "Меня зовут Саня"\n# → Агент: "Приятно познакомиться, Саня!"\n\n# Шаг 2: Спроси\n# "Как меня зовут?"\n# → Агент: "Тебя зовут Саня"\n\n# Шаг 3: Рестарт n8n\ndocker restart n8n\n\n# Шаг 4: Дождись запуска (30-60 секунд), открой чат с тем же session_id\n# "Как меня зовут?"\n# → Агент: "Тебя зовут Саня" ← данные из PostgreSQL!\n\n# Проверка данных в БД\npsql -h 192.168.56.11 -U agent_user -d agent_db \\\n  -c "SELECT session_id, role, left(content,60) as content, created_at FROM agent_memory ORDER BY created_at;"\n```\n\n---\n\n## 10. VM: Wiki.js — Docker + PostgreSQL\n\n### 10.1 Запуск Wiki.js\n\n```bash\n# Файл: scripts/provision_wikijs.sh\n#!/bin/bash\nset -e\n\n# Установка Docker (аналогично другим VM)\napt-get update -qq\napt-get install -y ca-certificates curl gnupg\n# ... (те же шаги что для n8n)\n\nmkdir -p /opt/wikijs && cd /opt/wikijs\n```\n\n```yaml\n# /opt/wikijs/docker-compose.yml\nversion: "3.8"\n\nservices:\n  wikijs:\n    image: ghcr.io/requarks/wiki:2\n    container_name: wikijs\n    restart: unless-stopped\n    ports:\n      - "3000:3000"\n    environment:\n      DB_TYPE: postgres\n      DB_HOST: 192.168.56.11\n      DB_PORT: 5432\n      DB_USER: wiki_user\n      DB_PASS: wiki_strong_password_123\n      DB_NAME: wiki_db\n```\n\n```bash\ncd /opt/wikijs\ndocker compose up -d\ndocker compose logs -f\n```\n\n### 10.2 Начальная настройка Wiki.js\n\n1. Открой **http://192.168.56.13:3000** (или http://localhost:3000)\n2. Пройди мастер настройки:\n   - Administrator Email: `admin@local.dev`\n   - Administrator Password: (придумай сам)\n   - Site URL: `http://192.168.56.13:3000`\n3. Нажми **Install** — Wiki.js создаст таблицы в PostgreSQL автоматически\n\n### 10.3 Проверка БД\n\n```bash\npsql -h 192.168.56.11 -U wiki_user -d wiki_db \\\n  -c "SELECT table_name FROM information_schema.tables WHERE table_schema='public' LIMIT 10;"\n```\n\n---\n\n## 11. Страница «Архитектура AI-агента» в Wiki.js\n\n### Как создать страницу\n\n1. Войди в Wiki.js\n2. Нажми **+ New Page**\n3. Путь: `architecture/ai-agent`\n4. Заголовок: `Архитектура AI-агента`\n5. Выбери редактор: **Markdown**\n6. Вставь содержимое ниже\n\n---\n\n### Содержимое страницы (Markdown для Wiki.js)\n\n```markdown\n# Архитектура AI-агента\n\n> Локальный AI-агент на базе n8n + Ollama + PostgreSQL + Wiki.js.  \n> Версия: 1.0 | Обновлено: 2025\n\n## Компоненты системы\n\n| Компонент | IP | Порт | Технология | Роль |\n|-----------|-----|------|------------|------|\n| **n8n** | 192.168.56.10 | 5678 | Docker + n8n | Оркестратор воркфлоу, AI-агент |\n| **PostgreSQL** | 192.168.56.11 | 5432 | PostgreSQL 15 | Централизованное хранилище данных |\n| **Ollama** | 192.168.56.12 | 11434 | Docker + Ollama | LLM inference, языковая модель |\n| **Wiki.js** | 192.168.56.13 | 3000 | Docker + Wiki.js 2 | Документация, эта страница |\n\n## Схема взаимодействия\n\n```\nПользователь (браузер)\n        │\n        ▼ HTTP :5678\n   ┌────────────┐\n   │    n8n     │\n   │  AI Agent  │\n   └─────┬──────┘\n         │              │\n         ▼ HTTP :11434   ▼ PostgreSQL :5432\n   ┌────────────┐   ┌─────────────────────┐\n   │   Ollama   │   │     PostgreSQL       │\n   │  llama3.2  │   │                     │\n   └────────────┘   │ • n8n_db (воркфлоу) │\n                    │ • agent_db (память) │\n                    │ • wiki_db (вики)    │\n                    └─────────────────────┘\n```\n\n## Базы данных PostgreSQL\n\n### n8n_db\n- **Пользователь:** `n8n_user`\n- **Назначение:** Воркфлоу, credentials, история выполнений n8n\n- **Доступ:** Только с 192.168.56.10 (VM n8n)\n\n### agent_db\n- **Пользователь:** `agent_user`\n- **Назначение:** Долгосрочная память AI-агента (история диалогов)\n- **Ключевая таблица:** `agent_memory(session_id, role, content, created_at)`\n- **Доступ:** Только с 192.168.56.10 (VM n8n)\n\n### wiki_db\n- **Пользователь:** `wiki_user`\n- **Назначение:** Содержимое Wiki.js (страницы, пользователи, настройки)\n- **Доступ:** Только с 192.168.56.13 (VM wikijs)\n\n## Воркфлоу AI-агента в n8n\n\n```\nChat Trigger\n     │\n     ▼\n  AI Agent  ────► Ollama Chat Model (llama3.2)\n     │\n     ▼\nPostgres Chat Memory\n  (agent_db)\n```\n\n### Поток данных\n1. Пользователь отправляет сообщение через Chat Trigger\n2. AI Agent загружает историю из PostgreSQL (agent_db)\n3. AI Agent формирует промпт с контекстом и передаёт в Ollama\n4. Ollama генерирует ответ (LLM inference)\n5. AI Agent сохраняет сообщение и ответ в PostgreSQL\n6. Ответ возвращается пользователю\n\n## Что где хранится\n\n| Данные | Где хранятся | Путь / Таблица |\n|--------|-------------|----------------|\n| Воркфлоу n8n | PostgreSQL `n8n_db` | таблица `workflow_entity` |\n| Credentials n8n | PostgreSQL `n8n_db` | таблица `credentials_entity` |\n| Память агента | PostgreSQL `agent_db` | таблица `agent_memory` |\n| Модели Ollama | Docker Volume `ollama_data` | `/root/.ollama/models/` |\n| Конфиг n8n | Docker Volume `n8n_data` | `/home/node/.n8n/` |\n| Страницы Wiki | PostgreSQL `wiki_db` | таблица `pages` |\n\n## Сетевая безопасность\n\n- PostgreSQL слушает только `192.168.56.11` — недоступен снаружи подсети VM\n- `pg_hba.conf` ограничивает доступ к каждой БД конкретным источником\n- Ollama слушает `0.0.0.0:11434` — доступен из подсети (в продакшне закрыть файрволом)\n- n8n доступен с хоста через forwarded port 5678\n\n## Управление\n\n### Перезапуск сервисов\n\n```bash\n# n8n\nvagrant ssh n8n -c "docker restart n8n"\n\n# Ollama\nvagrant ssh ollama -c "cd /opt/ollama && docker compose restart"\n\n# Wiki.js\nvagrant ssh wikijs -c "cd /opt/wikijs && docker compose restart"\n\n# PostgreSQL\nvagrant ssh postgresql -c "sudo systemctl restart postgresql"\n```\n\n### Просмотр логов\n\n```bash\nvagrant ssh n8n -c "docker logs n8n --tail 50 -f"\nvagrant ssh ollama -c "docker logs ollama --tail 50 -f"\nvagrant ssh wikijs -c "docker logs wikijs --tail 50 -f"\nvagrant ssh postgresql -c "sudo journalctl -u postgresql -f"\n```\n\n### Резервное копирование PostgreSQL\n\n```bash\n# Бэкап всех БД\nvagrant ssh postgresql -c "\n  sudo -u postgres pg_dump n8n_db > /tmp/n8n_db.sql\n  sudo -u postgres pg_dump agent_db > /tmp/agent_db.sql\n  sudo -u postgres pg_dump wiki_db > /tmp/wiki_db.sql\n"\n\n# Скопировать бэкапы на хост\nvagrant scp postgresql:/tmp/n8n_db.sql ./backups/\nvagrant scp postgresql:/tmp/agent_db.sql ./backups/\nvagrant scp postgresql:/tmp/wiki_db.sql ./backups/\n```\n```\n\n---\n\n## 12. Справочник портов и переменных\n\n### Порты\n\n| Сервис | VM | Порт внутри подсети | Порт на хосте |\n|--------|-----|---------------------|---------------|\n| n8n UI | 192.168.56.10 | :5678 | localhost:5678 |\n| PostgreSQL | 192.168.56.11 | :5432 | — (не пробрасывается) |\n| Ollama API | 192.168.56.12 | :11434 | localhost:11434 |\n| Wiki.js UI | 192.168.56.13 | :3000 | localhost:3000 |\n\n### Переменные окружения n8n\n\n| Переменная | Значение | Описание |\n|-----------|---------|---------|\n| `DB_TYPE` | `postgresdb` | Тип БД |\n| `DB_POSTGRESDB_HOST` | `192.168.56.11` | IP PostgreSQL |\n| `DB_POSTGRESDB_PORT` | `5432` | Порт PostgreSQL |\n| `DB_POSTGRESDB_DATABASE` | `n8n_db` | Имя БД |\n| `DB_POSTGRESDB_USER` | `n8n_user` | Пользователь |\n| `DB_POSTGRESDB_PASSWORD` | `n8n_strong_password_123` | Пароль |\n| `N8N_ENCRYPTION_KEY` | `<32+ символа>` | Ключ шифрования credentials |\n\n### Переменные окружения Wiki.js\n\n| Переменная | Значение |\n|-----------|---------|\n| `DB_TYPE` | `postgres` |\n| `DB_HOST` | `192.168.56.11` |\n| `DB_PORT` | `5432` |\n| `DB_USER` | `wiki_user` |\n| `DB_PASS` | `wiki_strong_password_123` |\n| `DB_NAME` | `wiki_db` |\n\n### Учётные данные PostgreSQL\n\n| БД | Пользователь | Пароль (поменяй!) |\n|----|-------------|-------------------|\n| `n8n_db` | `n8n_user` | `n8n_strong_password_123` |\n| `wiki_db` | `wiki_user` | `wiki_strong_password_123` |\n| `agent_db` | `agent_user` | `agent_strong_password_123` |\n\n---\n\n*Документация создана для проекта локального AI-агента. Обновляй при изменении конфигурации.*\n	<h1 id="документация-ai-агента-на-базе-n8n-ollama-postgresql-wikijs" class="toc-header"><a class="toc-anchor" href="#документация-ai-агента-на-базе-n8n-ollama-postgresql-wikijs">¶</a> Документация AI-агента на базе n8n + Ollama + PostgreSQL + Wiki.js</h1>\n<blockquote>\n<p><strong>Стек:</strong> n8n · Ollama · PostgreSQL · Wiki.js · Docker · Vagrant<br>\n<strong>Цель:</strong> локальный AI-агент с долгосрочной памятью, изолированной БД и внутренней wiki.</p>\n</blockquote>\n<hr>\n<h2 id="содержание" class="toc-header"><a class="toc-anchor" href="#содержание">¶</a> Содержание</h2>\n<ol>\n<li><a href="#1-%D0%B0%D1%80%D1%85%D0%B8%D1%82%D0%B5%D0%BA%D1%82%D1%83%D1%80%D0%B0-%D0%B8-%D1%82%D0%BE%D0%BF%D0%BE%D0%BB%D0%BE%D0%B3%D0%B8%D1%8F-%D1%81%D0%B5%D1%82%D0%B8">Архитектура и топология сети</a></li>\n<li><a href="#2-%D0%BF%D0%BE%D0%B4%D0%B3%D0%BE%D1%82%D0%BE%D0%B2%D0%BA%D0%B0-%D0%BE%D0%BA%D1%80%D1%83%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F-vagrant">Подготовка окружения (Vagrant)</a></li>\n<li><a href="#3-vm-postgresql--%D1%83%D1%81%D1%82%D0%B0%D0%BD%D0%BE%D0%B2%D0%BA%D0%B0-%D0%B8-%D0%BD%D0%B0%D1%81%D1%82%D1%80%D0%BE%D0%B9%D0%BA%D0%B0">VM: PostgreSQL — установка и настройка</a></li>\n<li><a href="#4-vm-n8n--docker--%D0%BF%D0%B5%D1%80%D0%B2%D1%8B%D0%B9-%D0%B7%D0%B0%D0%BF%D1%83%D1%81%D0%BA">VM: n8n — Docker + первый запуск</a></li>\n<li><a href="#5-n8n--%D0%BF%D0%B5%D1%80%D0%B5%D0%B2%D0%BE%D0%B4-%D0%BD%D0%B0-postgresql--%D0%BF%D0%B5%D1%80%D1%81%D0%B8%D1%81%D1%82%D0%B5%D0%BD%D1%82%D0%BD%D0%BE%D1%81%D1%82%D1%8C">n8n → перевод на PostgreSQL + персистентность</a></li>\n<li><a href="#6-vm-ollama--docker--llm">VM: Ollama — Docker + LLM</a></li>\n<li><a href="#7-n8n-credential-ollama--%D0%BC%D0%B8%D0%BD%D0%B8%D0%BC%D0%B0%D0%BB%D1%8C%D0%BD%D1%8B%D0%B9-workflow">n8n: credential Ollama + минимальный workflow</a></li>\n<li><a href="#8-n8n-ai-agent-workflow">n8n: AI Agent workflow</a></li>\n<li><a href="#9-%D0%BF%D0%B0%D0%BC%D1%8F%D1%82%D1%8C-%D0%B0%D0%B3%D0%B5%D0%BD%D1%82%D0%B0-%D0%B2-postgresql">Память агента в PostgreSQL</a></li>\n<li><a href="#10-vm-wikijs--docker--postgresql">VM: Wiki.js — Docker + PostgreSQL</a></li>\n<li><a href="#11-%D1%81%D1%82%D1%80%D0%B0%D0%BD%D0%B8%D1%86%D0%B0-%D0%B0%D1%80%D1%85%D0%B8%D1%82%D0%B5%D0%BA%D1%82%D1%83%D1%80%D0%B0-ai-%D0%B0%D0%B3%D0%B5%D0%BD%D1%82%D0%B0-%D0%B2-wikijs">Страница «Архитектура AI-агента» в Wiki.js</a></li>\n<li><a href="#12-%D1%81%D0%BF%D1%80%D0%B0%D0%B2%D0%BE%D1%87%D0%BD%D0%B8%D0%BA-%D0%BF%D0%BE%D1%80%D1%82%D0%BE%D0%B2-%D0%B8-%D0%BF%D0%B5%D1%80%D0%B5%D0%BC%D0%B5%D0%BD%D0%BD%D1%8B%D1%85">Справочник портов и переменных</a></li>\n</ol>\n<hr>\n<h2 id="h-1-архитектура-и-топология-сети" class="toc-header"><a class="toc-anchor" href="#h-1-архитектура-и-топология-сети">¶</a> 1. Архитектура и топология сети</h2>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">┌─────────────────────────────────────────────────────────────┐\n│                  Локальная подсеть 192.168.56.0/24           │\n│                                                             │\n│  ┌──────────────┐   SQL    ┌──────────────────────────────┐ │\n│  │  VM: n8n     │◄────────►│  VM: postgresql              │ │\n│  │  .10         │          │  .11                         │ │\n│  │  Docker      │          │  PostgreSQL 15               │ │\n│  │  n8n:5678    │          │  Port 5432 (только подсеть)  │ │\n│  └──────┬───────┘          │                              │ │\n│         │                  │  БД:                         │ │\n│         │ HTTP             │  • n8n_db / n8n_user         │ │\n│         │ :11434           │  • wiki_db / wiki_user       │ │\n│  ┌──────▼───────┐          │  • agent_db / agent_user     │ │\n│  │  VM: ollama  │          └──────────────────────────────┘ │\n│  │  .12         │                        ▲                  │\n│  │  Docker      │                        │ SQL              │\n│  │  Ollama      │          ┌─────────────┴──────────────┐   │\n│  └──────────────┘          │  VM: wikijs                │   │\n│                            │  .13                       │   │\n│                            │  Docker                    │   │\n│                            │  Wiki.js :3000             │   │\n│                            └────────────────────────────┘   │\n└─────────────────────────────────────────────────────────────┘\n           │ Host-only сеть (доступ с хоста)\n    Браузер хоста:\n    • n8n    → http://192.168.56.10:5678\n    • Ollama → http://192.168.56.12:11434\n    • Wiki.js→ http://192.168.56.13:3000\n</code></pre>\n<h3 id="компоненты" class="toc-header"><a class="toc-anchor" href="#компоненты">¶</a> Компоненты</h3>\n<div class="table-container"><table>\n<thead>\n<tr>\n<th>Компонент</th>\n<th>VM IP</th>\n<th>Порт</th>\n<th>Роль</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td>n8n</td>\n<td>192.168.56.10</td>\n<td>5678</td>\n<td>Оркестратор воркфлоу / AI-агент</td>\n</tr>\n<tr>\n<td>PostgreSQL</td>\n<td>192.168.56.11</td>\n<td>5432</td>\n<td>Хранилище данных (n8n, wiki, память)</td>\n</tr>\n<tr>\n<td>Ollama</td>\n<td>192.168.56.12</td>\n<td>11434</td>\n<td>LLM inference сервер</td>\n</tr>\n<tr>\n<td>Wiki.js</td>\n<td>192.168.56.13</td>\n<td>3000</td>\n<td>Внутренняя документация</td>\n</tr>\n</tbody>\n</table></div>\n<hr>\n<h2 id="h-2-подготовка-окружения-vagrant" class="toc-header"><a class="toc-anchor" href="#h-2-подготовка-окружения-vagrant">¶</a> 2. Подготовка окружения (Vagrant)</h2>\n<h3 id="vagrantfile" class="toc-header"><a class="toc-anchor" href="#vagrantfile">¶</a> Vagrantfile</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-ruby"># -*- mode: ruby -*-\n# vi: set ft=ruby :\n\nVagrant.configure("2") do |config|\n  config.vm.box = "ubuntu/jammy64"\n\n  # ── PostgreSQL ──────────────────────────────────────────────\n  config.vm.define "postgresql" do |pg|\n    pg.vm.hostname = "postgresql"\n    pg.vm.network "private_network", ip: "192.168.56.11"\n    pg.vm.provider "virtualbox" do |vb|\n      vb.memory = "1024"\n      vb.cpus   = 1\n    end\n    pg.vm.provision "shell", path: "scripts/provision_postgresql.sh"\n  end\n\n  # ── n8n ─────────────────────────────────────────────────────\n  config.vm.define "n8n" do |n8n|\n    n8n.vm.hostname = "n8n"\n    n8n.vm.network "private_network", ip: "192.168.56.10"\n    n8n.vm.network "forwarded_port", guest: 5678, host: 5678\n    n8n.vm.provider "virtualbox" do |vb|\n      vb.memory = "2048"\n      vb.cpus   = 2\n    end\n    n8n.vm.provision "shell", path: "scripts/provision_n8n.sh"\n  end\n\n  # ── Ollama ──────────────────────────────────────────────────\n  config.vm.define "ollama" do |ol|\n    ol.vm.hostname = "ollama"\n    ol.vm.network "private_network", ip: "192.168.56.12"\n    ol.vm.network "forwarded_port", guest: 11434, host: 11434\n    ol.vm.provider "virtualbox" do |vb|\n      vb.memory = "4096"   # LLM требует памяти\n      vb.cpus   = 4\n    end\n    ol.vm.provision "shell", path: "scripts/provision_ollama.sh"\n  end\n\n  # ── Wiki.js ─────────────────────────────────────────────────\n  config.vm.define "wikijs" do |wiki|\n    wiki.vm.hostname = "wikijs"\n    wiki.vm.network "private_network", ip: "192.168.56.13"\n    wiki.vm.network "forwarded_port", guest: 3000, host: 3000\n    wiki.vm.provider "virtualbox" do |vb|\n      vb.memory = "1024"\n      vb.cpus   = 1\n    end\n    wiki.vm.provision "shell", path: "scripts/provision_wikijs.sh"\n  end\nend\n</code></pre>\n<h3 id="запуск" class="toc-header"><a class="toc-anchor" href="#запуск">¶</a> Запуск</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Поднять все VM (займёт ~10 минут при первом запуске)\nvagrant up\n\n# Поднять отдельную VM\nvagrant up postgresql\n\n# SSH в VM\nvagrant ssh postgresql\nvagrant ssh n8n\nvagrant ssh ollama\nvagrant ssh wikijs\n\n# Остановить все\nvagrant halt\n\n# Пересоздать с нуля\nvagrant destroy -f &amp;&amp; vagrant up\n</code></pre>\n<hr>\n<h2 id="h-3-vm-postgresql-установка-и-настройка" class="toc-header"><a class="toc-anchor" href="#h-3-vm-postgresql-установка-и-настройка">¶</a> 3. VM: PostgreSQL — установка и настройка</h2>\n<h3 id="h-31-установка-postgresql" class="toc-header"><a class="toc-anchor" href="#h-31-установка-postgresql">¶</a> 3.1 Установка PostgreSQL</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Файл: scripts/provision_postgresql.sh\n#!/bin/bash\nset -e\n\n# Установка PostgreSQL 15\napt-get update -qq\napt-get install -y postgresql postgresql-contrib\n\n# Запуск и автозапуск\nsystemctl enable postgresql\nsystemctl start postgresql\n</code></pre>\n<h3 id="h-32-настройка-сетевого-доступа" class="toc-header"><a class="toc-anchor" href="#h-32-настройка-сетевого-доступа">¶</a> 3.2 Настройка сетевого доступа</h3>\n<p>PostgreSQL по умолчанию слушает только <code>localhost</code>. Нужно открыть доступ только из подсети VM (<code>192.168.56.0/24</code>).</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Редактируем postgresql.conf\n# Найти параметр listen_addresses\nsudo nano /etc/postgresql/15/main/postgresql.conf\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-ini"># postgresql.conf\nlisten_addresses = 'localhost,192.168.56.11'\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Редактируем pg_hba.conf — правила аутентификации\nsudo nano /etc/postgresql/15/main/pg_hba.conf\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-"># pg_hba.conf — добавить строки в конец файла\n# TYPE  DATABASE        USER            ADDRESS                 METHOD\nhost    n8n_db          n8n_user        192.168.56.0/24         scram-sha-256\nhost    wiki_db         wiki_user       192.168.56.0/24         scram-sha-256\nhost    agent_db        agent_user      192.168.56.0/24         scram-sha-256\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Применить изменения\nsudo systemctl restart postgresql\n</code></pre>\n<h3 id="h-33-создание-баз-данных-и-пользователей" class="toc-header"><a class="toc-anchor" href="#h-33-создание-баз-данных-и-пользователей">¶</a> 3.3 Создание баз данных и пользователей</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">sudo -u postgres psql &lt;&lt; 'EOF'\n-- ── Пользователь и БД для n8n ──────────────────────────────\nCREATE USER n8n_user WITH PASSWORD 'n8n_strong_password_123';\nCREATE DATABASE n8n_db OWNER n8n_user;\nGRANT ALL PRIVILEGES ON DATABASE n8n_db TO n8n_user;\n\n-- ── Пользователь и БД для Wiki.js ──────────────────────────\nCREATE USER wiki_user WITH PASSWORD 'wiki_strong_password_123';\nCREATE DATABASE wiki_db OWNER wiki_user;\nGRANT ALL PRIVILEGES ON DATABASE wiki_db TO wiki_user;\n\n-- ── Пользователь и БД для памяти агента ────────────────────\nCREATE USER agent_user WITH PASSWORD 'agent_strong_password_123';\nCREATE DATABASE agent_db OWNER agent_user;\nGRANT ALL PRIVILEGES ON DATABASE agent_db TO agent_user;\n\n-- Проверка\n\\l\n\\du\nEOF\n</code></pre>\n<h3 id="h-34-проверка-доступности-из-других-vm" class="toc-header"><a class="toc-anchor" href="#h-34-проверка-доступности-из-других-vm">¶</a> 3.4 Проверка доступности из других VM</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># С VM n8n (192.168.56.10) — проверяем подключение к PostgreSQL\npsql -h 192.168.56.11 -U n8n_user -d n8n_db -c "SELECT version();"\n# Пароль: n8n_strong_password_123\n\n# С VM wikijs (192.168.56.13) — аналогично\npsql -h 192.168.56.11 -U wiki_user -d wiki_db -c "SELECT version();"\n</code></pre>\n<h3 id="h-35-проверка-ограничения-доступа" class="toc-header"><a class="toc-anchor" href="#h-35-проверка-ограничения-доступа">¶</a> 3.5 Проверка ограничения доступа</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># С внешней машины (не из подсети 192.168.56.0/24) — должен получить отказ\npsql -h 192.168.56.11 -U n8n_user -d n8n_db\n# Ожидаемый результат: connection refused или authentication failed\n</code></pre>\n<hr>\n<h2 id="h-4-vm-n8n-docker-первый-запуск" class="toc-header"><a class="toc-anchor" href="#h-4-vm-n8n-docker-первый-запуск">¶</a> 4. VM: n8n — Docker + первый запуск</h2>\n<h3 id="h-41-установка-docker" class="toc-header"><a class="toc-anchor" href="#h-41-установка-docker">¶</a> 4.1 Установка Docker</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Файл: scripts/provision_n8n.sh\n#!/bin/bash\nset -e\n\n# Установка Docker (официальный способ)\napt-get update -qq\napt-get install -y ca-certificates curl gnupg\n\ninstall -m 0755 -d /etc/apt/keyrings\ncurl -fsSL https://download.docker.com/linux/ubuntu/gpg \\\n  | gpg --dearmor -o /etc/apt/keyrings/docker.gpg\nchmod a+r /etc/apt/keyrings/docker.gpg\n\necho "deb [arch=$(dpkg --print-architecture) \\\n  signed-by=/etc/apt/keyrings/docker.gpg] \\\n  https://download.docker.com/linux/ubuntu \\\n  $(. /etc/os-release &amp;&amp; echo "$VERSION_CODENAME") stable" \\\n  | tee /etc/apt/sources.list.d/docker.list &gt; /dev/null\n\napt-get update -qq\napt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin\n\n# Добавить vagrant в группу docker\nusermod -aG docker vagrant\n\nsystemctl enable docker\nsystemctl start docker\n</code></pre>\n<h3 id="h-42-первый-запуск-n8n-sqlite-для-проверки-ui" class="toc-header"><a class="toc-anchor" href="#h-42-первый-запуск-n8n-sqlite-для-проверки-ui">¶</a> 4.2 Первый запуск n8n (SQLite, для проверки UI)</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Самый простой запуск — n8n с SQLite (временно, для проверки UI)\ndocker run -d \\\n  --name n8n \\\n  --restart unless-stopped \\\n  -p 5678:5678 \\\n  -e N8N_HOST=0.0.0.0 \\\n  -e WEBHOOK_URL=http://192.168.56.10:5678 \\\n  n8nio/n8n:latest\n\n# Проверить статус\ndocker ps\ndocker logs n8n -f\n</code></pre>\n<h3 id="h-43-проверка-ui" class="toc-header"><a class="toc-anchor" href="#h-43-проверка-ui">¶</a> 4.3 Проверка UI</h3>\n<p>Открой в браузере: <strong><a href="http://192.168.56.10:5678" class="is-external-link">http://192.168.56.10:5678</a></strong> (или <a href="http://localhost:5678" class="is-external-link">http://localhost:5678</a> если пробросил порт)</p>\n<ol>\n<li>Пройди первичную регистрацию (имя, email, пароль)</li>\n<li>Нажми <strong>"+ New workflow"</strong></li>\n<li>Убедись, что пустой воркфлоу создаётся и сохраняется</li>\n</ol>\n<hr>\n<h2 id="h-5-n8n-перевод-на-postgresql-персистентность" class="toc-header"><a class="toc-anchor" href="#h-5-n8n-перевод-на-postgresql-персистентность">¶</a> 5. n8n → перевод на PostgreSQL + персистентность</h2>\n<h3 id="h-51-остановить-временный-контейнер" class="toc-header"><a class="toc-anchor" href="#h-51-остановить-временный-контейнер">¶</a> 5.1 Остановить временный контейнер</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">docker stop n8n &amp;&amp; docker rm n8n\n</code></pre>\n<h3 id="h-52-создать-volume-для-данных-n8n" class="toc-header"><a class="toc-anchor" href="#h-52-создать-volume-для-данных-n8n">¶</a> 5.2 Создать volume для данных n8n</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">docker volume create n8n_data\n</code></pre>\n<h3 id="h-53-запустить-n8n-с-postgresql" class="toc-header"><a class="toc-anchor" href="#h-53-запустить-n8n-с-postgresql">¶</a> 5.3 Запустить n8n с PostgreSQL</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">docker run -d \\\n  --name n8n \\\n  --restart unless-stopped \\\n  -p 5678:5678 \\\n  -v n8n_data:/home/node/.n8n \\\n  -e N8N_HOST=0.0.0.0 \\\n  -e WEBHOOK_URL=http://192.168.56.10:5678 \\\n  -e DB_TYPE=postgresdb \\\n  -e DB_POSTGRESDB_HOST=192.168.56.11 \\\n  -e DB_POSTGRESDB_PORT=5432 \\\n  -e DB_POSTGRESDB_DATABASE=n8n_db \\\n  -e DB_POSTGRESDB_USER=n8n_user \\\n  -e DB_POSTGRESDB_PASSWORD=n8n_strong_password_123 \\\n  -e N8N_ENCRYPTION_KEY=change-this-to-random-32-char-string \\\n  n8nio/n8n:latest\n</code></pre>\n<blockquote>\n<p>⚠️ <code>N8N_ENCRYPTION_KEY</code> — произвольная строка длиной 32+ символа. Запиши её и не меняй: она шифрует credentials.</p>\n</blockquote>\n<h3 id="h-54-альтернатива-docker-compose-рекомендуется" class="toc-header"><a class="toc-anchor" href="#h-54-альтернатива-docker-compose-рекомендуется">¶</a> 5.4 Альтернатива: docker-compose (рекомендуется)</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">mkdir -p /opt/n8n &amp;&amp; cd /opt/n8n\nnano docker-compose.yml\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-yaml"># /opt/n8n/docker-compose.yml\nversion: "3.8"\n\nservices:\n  n8n:\n    image: n8nio/n8n:latest\n    container_name: n8n\n    restart: unless-stopped\n    ports:\n      - "5678:5678"\n    volumes:\n      - n8n_data:/home/node/.n8n\n    environment:\n      - N8N_HOST=0.0.0.0\n      - WEBHOOK_URL=http://192.168.56.10:5678\n      - DB_TYPE=postgresdb\n      - DB_POSTGRESDB_HOST=192.168.56.11\n      - DB_POSTGRESDB_PORT=5432\n      - DB_POSTGRESDB_DATABASE=n8n_db\n      - DB_POSTGRESDB_USER=n8n_user\n      - DB_POSTGRESDB_PASSWORD=n8n_strong_password_123\n      - N8N_ENCRYPTION_KEY=change-this-to-random-32-char-string\n\nvolumes:\n  n8n_data:\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">docker compose up -d\ndocker compose logs -f\n</code></pre>\n<h3 id="h-55-проверка-персистентности" class="toc-header"><a class="toc-anchor" href="#h-55-проверка-персистентности">¶</a> 5.5 Проверка персистентности</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># 1. Открыть n8n UI и создать воркфлоу с каким-нибудь именем\n# 2. Перезапустить контейнер\ndocker restart n8n\n\n# 3. Открыть UI снова — воркфлоу должен быть на месте\n# 4. Проверить данные в PostgreSQL\npsql -h 192.168.56.11 -U n8n_user -d n8n_db -c "SELECT name, created_at FROM workflow_entity;"\n</code></pre>\n<hr>\n<h2 id="h-6-vm-ollama-docker-llm" class="toc-header"><a class="toc-anchor" href="#h-6-vm-ollama-docker-llm">¶</a> 6. VM: Ollama — Docker + LLM</h2>\n<h3 id="h-61-установка-docker-аналогично-n8n" class="toc-header"><a class="toc-anchor" href="#h-61-установка-docker-аналогично-n8n">¶</a> 6.1 Установка Docker (аналогично n8n)</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Файл: scripts/provision_ollama.sh\n#!/bin/bash\nset -e\n\napt-get update -qq\napt-get install -y ca-certificates curl gnupg\n\ninstall -m 0755 -d /etc/apt/keyrings\ncurl -fsSL https://download.docker.com/linux/ubuntu/gpg \\\n  | gpg --dearmor -o /etc/apt/keyrings/docker.gpg\nchmod a+r /etc/apt/keyrings/docker.gpg\n\necho "deb [arch=$(dpkg --print-architecture) \\\n  signed-by=/etc/apt/keyrings/docker.gpg] \\\n  https://download.docker.com/linux/ubuntu \\\n  $(. /etc/os-release &amp;&amp; echo "$VERSION_CODENAME") stable" \\\n  | tee /etc/apt/sources.list.d/docker.list &gt; /dev/null\n\napt-get update -qq\napt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin\nusermod -aG docker vagrant\nsystemctl enable docker\nsystemctl start docker\n</code></pre>\n<h3 id="h-62-запуск-ollama-в-docker" class="toc-header"><a class="toc-anchor" href="#h-62-запуск-ollama-в-docker">¶</a> 6.2 Запуск Ollama в Docker</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">mkdir -p /opt/ollama &amp;&amp; cd /opt/ollama\nnano docker-compose.yml\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-yaml"># /opt/ollama/docker-compose.yml\nversion: "3.8"\n\nservices:\n  ollama:\n    image: ollama/ollama:latest\n    container_name: ollama\n    restart: unless-stopped\n    ports:\n      - "11434:11434"\n    volumes:\n      - ollama_data:/root/.ollama\n    environment:\n      - OLLAMA_HOST=0.0.0.0\n\nvolumes:\n  ollama_data:\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">docker compose up -d\ndocker compose logs -f\n</code></pre>\n<h3 id="h-63-загрузка-модели" class="toc-header"><a class="toc-anchor" href="#h-63-загрузка-модели">¶</a> 6.3 Загрузка модели</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Войти в контейнер\ndocker exec -it ollama ollama pull llama3.2\n\n# Другие подходящие модели (выбери одну под свои ресурсы):\n# docker exec -it ollama ollama pull qwen2.5:3b     # лёгкая ~2GB\n# docker exec -it ollama ollama pull mistral:7b     # хорошая ~4GB\n# docker exec -it ollama ollama pull llama3.2:3b    # рекомендуем ~2GB\n\n# Список загруженных моделей\ndocker exec -it ollama ollama list\n</code></pre>\n<h3 id="h-64-проверка-через-cli" class="toc-header"><a class="toc-anchor" href="#h-64-проверка-через-cli">¶</a> 6.4 Проверка через CLI</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Тест прямо в терминале\ndocker exec -it ollama ollama run llama3.2 "Привет! Кто ты?"\n# Введи /bye чтобы выйти\n</code></pre>\n<h3 id="h-65-проверка-через-api" class="toc-header"><a class="toc-anchor" href="#h-65-проверка-через-api">¶</a> 6.5 Проверка через API</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># С VM ollama (или любой VM в подсети)\ncurl http://localhost:11434/api/generate \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "model": "llama3.2",\n    "prompt": "Скажи привет по-русски.",\n    "stream": false\n  }'\n\n# С другой VM в подсети\ncurl http://192.168.56.12:11434/api/generate \\\n  -H "Content-Type: application/json" \\\n  -d '{\n    "model": "llama3.2",\n    "prompt": "Hello!",\n    "stream": false\n  }'\n\n# Проверить список моделей через API\ncurl http://192.168.56.12:11434/api/tags\n</code></pre>\n<hr>\n<h2 id="h-7-n8n-credential-ollama-минимальный-workflow" class="toc-header"><a class="toc-anchor" href="#h-7-n8n-credential-ollama-минимальный-workflow">¶</a> 7. n8n: credential Ollama + минимальный workflow</h2>\n<h3 id="h-71-создание-credential-для-ollama" class="toc-header"><a class="toc-anchor" href="#h-71-создание-credential-для-ollama">¶</a> 7.1 Создание Credential для Ollama</h3>\n<ol>\n<li>Открой <strong><a href="http://192.168.56.10:5678" class="is-external-link">http://192.168.56.10:5678</a></strong></li>\n<li>Перейди в <strong>Settings → Credentials → New Credential</strong></li>\n<li>Выбери тип: <strong>Ollama API</strong></li>\n<li>Заполни:\n<ul>\n<li><strong>Base URL:</strong> <code>http://192.168.56.12:11434</code></li>\n</ul>\n</li>\n<li>Нажми <strong>Save</strong> и <strong>Test connection</strong> — должен получить ✅</li>\n</ol>\n<h3 id="h-72-минимальный-workflow-chat-ollama" class="toc-header"><a class="toc-anchor" href="#h-72-минимальный-workflow-chat-ollama">¶</a> 7.2 Минимальный workflow: Chat → Ollama</h3>\n<p>Создай новый воркфлоу с тремя нодами:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">[Chat Trigger] ──► [Ollama Chat Model] ──► (ответ в чат)\n</code></pre>\n<p><strong>Нода 1: Chat Trigger</strong></p>\n<ul>\n<li>Тип: <code>Chat Trigger</code></li>\n<li>Режим: <code>Respond to Webhook</code></li>\n</ul>\n<p><strong>Нода 2: Basic LLM Chain</strong></p>\n<ul>\n<li>Тип: <code>Basic LLM Chain</code></li>\n<li>Chat Model: выбери <code>Ollama Chat Model</code>\n<ul>\n<li>Credential: выбери созданный credential</li>\n<li>Model: <code>llama3.2</code></li>\n</ul>\n</li>\n</ul>\n<p><strong>Активация воркфлоу:</strong></p>\n<ul>\n<li>Нажми переключатель <strong>Active</strong> (вверху справа)</li>\n</ul>\n<h3 id="h-73-тест-в-чате" class="toc-header"><a class="toc-anchor" href="#h-73-тест-в-чате">¶</a> 7.3 Тест в чате</h3>\n<ol>\n<li>Нажми <strong>Open Chat</strong> (или перейди по ссылке воркфлоу)</li>\n<li>Напиши: <code>"Привет! Как тебя зовут?"</code></li>\n<li>Проверь, что ответ возвращается из Ollama</li>\n</ol>\n<hr>\n<h2 id="h-8-n8n-ai-agent-workflow" class="toc-header"><a class="toc-anchor" href="#h-8-n8n-ai-agent-workflow">¶</a> 8. n8n: AI Agent workflow</h2>\n<h3 id="h-81-схема-воркфлоу" class="toc-header"><a class="toc-anchor" href="#h-81-схема-воркфлоу">¶</a> 8.1 Схема воркфлоу</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">[Chat Trigger] ──► [AI Agent] ──► [Ollama Chat Model]\n                       │\n                  [Window Buffer Memory]\n</code></pre>\n<h3 id="h-82-создание-воркфлоу" class="toc-header"><a class="toc-anchor" href="#h-82-создание-воркфлоу">¶</a> 8.2 Создание воркфлоу</h3>\n<p><strong>Нода 1: Chat Trigger</strong></p>\n<ul>\n<li>Тип: <code>Chat Trigger</code></li>\n</ul>\n<p><strong>Нода 2: AI Agent</strong></p>\n<ul>\n<li>Тип: <code>AI Agent</code></li>\n<li>Подключи к Chat Trigger</li>\n<li>Agent Type: <code>Conversational Agent</code></li>\n<li>System Message:<pre class="prismjs line-numbers" v-pre="true"><code class="language-">Ты полезный AI-ассистент. Отвечай на русском языке.\nПомни контекст разговора и используй его в своих ответах.\n</code></pre>\n</li>\n</ul>\n<p><strong>Нода 3: Ollama Chat Model</strong> (подключить к AI Agent → Chat Model)</p>\n<ul>\n<li>Тип: <code>Ollama Chat Model</code></li>\n<li>Credential: твой Ollama credential</li>\n<li>Model: <code>llama3.2</code></li>\n<li>Temperature: <code>0.7</code></li>\n</ul>\n<p><strong>Нода 4: Window Buffer Memory</strong> (подключить к AI Agent → Memory)</p>\n<ul>\n<li>Тип: <code>Window Buffer Memory</code></li>\n<li>Session Key: <code v-pre="true">={{ $('Chat Trigger').item.json.sessionId }}</code></li>\n<li>Context Window Length: <code>10</code> (запоминать последние 10 сообщений)</li>\n</ul>\n<h3 id="h-83-тест-агента-35-запросов" class="toc-header"><a class="toc-anchor" href="#h-83-тест-агента-35-запросов">¶</a> 8.3 Тест агента (3–5 запросов)</h3>\n<p>Протестируй последовательно в чате:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">1. "Привет! Меня зовут Саня."\n   → Агент должен поприветствовать тебя по имени\n\n2. "Что ты умеешь?"\n   → Агент описывает возможности\n\n3. "Как меня зовут?"\n   → Агент должен ответить: "Тебя зовут Саня"\n\n4. "Придумай мне шутку про программирование"\n   → Агент генерирует шутку\n\n5. "Переведи на английский то, что ты только что сказал"\n   → Агент переводит предыдущий ответ (помнит контекст)\n</code></pre>\n<hr>\n<h2 id="h-9-память-агента-в-postgresql" class="toc-header"><a class="toc-anchor" href="#h-9-память-агента-в-postgresql">¶</a> 9. Память агента в PostgreSQL</h2>\n<h3 id="h-91-создание-таблицы-для-памяти" class="toc-header"><a class="toc-anchor" href="#h-91-создание-таблицы-для-памяти">¶</a> 9.1 Создание таблицы для памяти</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Подключиться к agent_db\npsql -h 192.168.56.11 -U agent_user -d agent_db &lt;&lt; 'EOF'\nCREATE TABLE IF NOT EXISTS agent_memory (\n    id          SERIAL PRIMARY KEY,\n    session_id  VARCHAR(255) NOT NULL,\n    role        VARCHAR(50)  NOT NULL,  -- 'user' или 'assistant'\n    content     TEXT         NOT NULL,\n    created_at  TIMESTAMPTZ  DEFAULT NOW()\n);\n\nCREATE INDEX IF NOT EXISTS idx_agent_memory_session\n    ON agent_memory(session_id, created_at);\n\n-- Проверка\n\\d agent_memory\nEOF\n</code></pre>\n<h3 id="h-92-настройка-postgres-chat-memory-в-n8n" class="toc-header"><a class="toc-anchor" href="#h-92-настройка-postgres-chat-memory-в-n8n">¶</a> 9.2 Настройка Postgres Chat Memory в n8n</h3>\n<p>Вместо <code>Window Buffer Memory</code> используй <strong>Postgres Chat Memory</strong>:</p>\n<p><strong>Нода Memory: Postgres Chat Memory</strong></p>\n<ul>\n<li>Тип: <code>Postgres Chat Memory</code></li>\n<li>Credential: создай новый <code>PostgreSQL</code> credential:\n<ul>\n<li>Host: <code>192.168.56.11</code></li>\n<li>Port: <code>5432</code></li>\n<li>Database: <code>agent_db</code></li>\n<li>User: <code>agent_user</code></li>\n<li>Password: <code>agent_strong_password_123</code></li>\n</ul>\n</li>\n<li>Table Name: <code>agent_memory</code></li>\n<li>Session ID: <code v-pre="true">={{ $('Chat Trigger').item.json.sessionId }}</code></li>\n<li>Context Window Length: <code>20</code></li>\n</ul>\n<h3 id="h-93-схема-воркфлоу-с-postgresql-памятью" class="toc-header"><a class="toc-anchor" href="#h-93-схема-воркфлоу-с-postgresql-памятью">¶</a> 9.3 Схема воркфлоу с PostgreSQL памятью</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">[Chat Trigger] ──► [AI Agent] ──► [Ollama Chat Model]\n                       │\n               [Postgres Chat Memory]\n                  (agent_db на 192.168.56.11)\n</code></pre>\n<h3 id="h-94-тест-персистентной-памяти" class="toc-header"><a class="toc-anchor" href="#h-94-тест-персистентной-памяти">¶</a> 9.4 Тест персистентной памяти</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Шаг 1: Отправь сообщение в чат\n# "Меня зовут Саня"\n# → Агент: "Приятно познакомиться, Саня!"\n\n# Шаг 2: Спроси\n# "Как меня зовут?"\n# → Агент: "Тебя зовут Саня"\n\n# Шаг 3: Рестарт n8n\ndocker restart n8n\n\n# Шаг 4: Дождись запуска (30-60 секунд), открой чат с тем же session_id\n# "Как меня зовут?"\n# → Агент: "Тебя зовут Саня" ← данные из PostgreSQL!\n\n# Проверка данных в БД\npsql -h 192.168.56.11 -U agent_user -d agent_db \\\n  -c "SELECT session_id, role, left(content,60) as content, created_at FROM agent_memory ORDER BY created_at;"\n</code></pre>\n<hr>\n<h2 id="h-10-vm-wikijs-docker-postgresql" class="toc-header"><a class="toc-anchor" href="#h-10-vm-wikijs-docker-postgresql">¶</a> 10. VM: Wiki.js — Docker + PostgreSQL</h2>\n<h3 id="h-101-запуск-wikijs" class="toc-header"><a class="toc-anchor" href="#h-101-запуск-wikijs">¶</a> 10.1 Запуск Wiki.js</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Файл: scripts/provision_wikijs.sh\n#!/bin/bash\nset -e\n\n# Установка Docker (аналогично другим VM)\napt-get update -qq\napt-get install -y ca-certificates curl gnupg\n# ... (те же шаги что для n8n)\n\nmkdir -p /opt/wikijs &amp;&amp; cd /opt/wikijs\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-yaml"># /opt/wikijs/docker-compose.yml\nversion: "3.8"\n\nservices:\n  wikijs:\n    image: ghcr.io/requarks/wiki:2\n    container_name: wikijs\n    restart: unless-stopped\n    ports:\n      - "3000:3000"\n    environment:\n      DB_TYPE: postgres\n      DB_HOST: 192.168.56.11\n      DB_PORT: 5432\n      DB_USER: wiki_user\n      DB_PASS: wiki_strong_password_123\n      DB_NAME: wiki_db\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">cd /opt/wikijs\ndocker compose up -d\ndocker compose logs -f\n</code></pre>\n<h3 id="h-102-начальная-настройка-wikijs" class="toc-header"><a class="toc-anchor" href="#h-102-начальная-настройка-wikijs">¶</a> 10.2 Начальная настройка Wiki.js</h3>\n<ol>\n<li>Открой <strong><a href="http://192.168.56.13:3000" class="is-external-link">http://192.168.56.13:3000</a></strong> (или <a href="http://localhost:3000" class="is-external-link">http://localhost:3000</a>)</li>\n<li>Пройди мастер настройки:\n<ul>\n<li>Administrator Email: <code>admin@local.dev</code></li>\n<li>Administrator Password: (придумай сам)</li>\n<li>Site URL: <code>http://192.168.56.13:3000</code></li>\n</ul>\n</li>\n<li>Нажми <strong>Install</strong> — Wiki.js создаст таблицы в PostgreSQL автоматически</li>\n</ol>\n<h3 id="h-103-проверка-бд" class="toc-header"><a class="toc-anchor" href="#h-103-проверка-бд">¶</a> 10.3 Проверка БД</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">psql -h 192.168.56.11 -U wiki_user -d wiki_db \\\n  -c "SELECT table_name FROM information_schema.tables WHERE table_schema='public' LIMIT 10;"\n</code></pre>\n<hr>\n<h2 id="h-11-страница-архитектура-ai-агента-в-wikijs" class="toc-header"><a class="toc-anchor" href="#h-11-страница-архитектура-ai-агента-в-wikijs">¶</a> 11. Страница «Архитектура AI-агента» в Wiki.js</h2>\n<h3 id="как-создать-страницу" class="toc-header"><a class="toc-anchor" href="#как-создать-страницу">¶</a> Как создать страницу</h3>\n<ol>\n<li>Войди в Wiki.js</li>\n<li>Нажми <strong>+ New Page</strong></li>\n<li>Путь: <code>architecture/ai-agent</code></li>\n<li>Заголовок: <code>Архитектура AI-агента</code></li>\n<li>Выбери редактор: <strong>Markdown</strong></li>\n<li>Вставь содержимое ниже</li>\n</ol>\n<hr>\n<h3 id="содержимое-страницы-markdown-для-wikijs" class="toc-header"><a class="toc-anchor" href="#содержимое-страницы-markdown-для-wikijs">¶</a> Содержимое страницы (Markdown для Wiki.js)</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-markdown"># Архитектура AI-агента\n\n&gt; Локальный AI-агент на базе n8n + Ollama + PostgreSQL + Wiki.js.  \n&gt; Версия: 1.0 | Обновлено: 2025\n\n## Компоненты системы\n\n| Компонент | IP | Порт | Технология | Роль |\n|-----------|-----|------|------------|------|\n| **n8n** | 192.168.56.10 | 5678 | Docker + n8n | Оркестратор воркфлоу, AI-агент |\n| **PostgreSQL** | 192.168.56.11 | 5432 | PostgreSQL 15 | Централизованное хранилище данных |\n| **Ollama** | 192.168.56.12 | 11434 | Docker + Ollama | LLM inference, языковая модель |\n| **Wiki.js** | 192.168.56.13 | 3000 | Docker + Wiki.js 2 | Документация, эта страница |\n\n## Схема взаимодействия\n\n</code></pre>\n<p>Пользователь (браузер)<br>\n│<br>\n▼ HTTP :5678<br>\n┌────────────┐<br>\n│    n8n     │<br>\n│  AI Agent  │<br>\n└─────┬──────┘<br>\n│              │<br>\n▼ HTTP :11434   ▼ PostgreSQL :5432<br>\n┌────────────┐   ┌─────────────────────┐<br>\n│   Ollama   │   │     PostgreSQL       │<br>\n│  llama3.2  │   │                     │<br>\n└────────────┘   │ • n8n_db (воркфлоу) │<br>\n│ • agent_db (память) │<br>\n│ • wiki_db (вики)    │<br>\n└─────────────────────┘</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">\n## Базы данных PostgreSQL\n\n### n8n_db\n- **Пользователь:** `n8n_user`\n- **Назначение:** Воркфлоу, credentials, история выполнений n8n\n- **Доступ:** Только с 192.168.56.10 (VM n8n)\n\n### agent_db\n- **Пользователь:** `agent_user`\n- **Назначение:** Долгосрочная память AI-агента (история диалогов)\n- **Ключевая таблица:** `agent_memory(session_id, role, content, created_at)`\n- **Доступ:** Только с 192.168.56.10 (VM n8n)\n\n### wiki_db\n- **Пользователь:** `wiki_user`\n- **Назначение:** Содержимое Wiki.js (страницы, пользователи, настройки)\n- **Доступ:** Только с 192.168.56.13 (VM wikijs)\n\n## Воркфлоу AI-агента в n8n\n\n</code></pre>\n<p>Chat Trigger<br>\n│<br>\n▼<br>\nAI Agent  ────► Ollama Chat Model (llama3.2)<br>\n│<br>\n▼<br>\nPostgres Chat Memory<br>\n(agent_db)</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">\n### Поток данных\n1. Пользователь отправляет сообщение через Chat Trigger\n2. AI Agent загружает историю из PostgreSQL (agent_db)\n3. AI Agent формирует промпт с контекстом и передаёт в Ollama\n4. Ollama генерирует ответ (LLM inference)\n5. AI Agent сохраняет сообщение и ответ в PostgreSQL\n6. Ответ возвращается пользователю\n\n## Что где хранится\n\n| Данные | Где хранятся | Путь / Таблица |\n|--------|-------------|----------------|\n| Воркфлоу n8n | PostgreSQL `n8n_db` | таблица `workflow_entity` |\n| Credentials n8n | PostgreSQL `n8n_db` | таблица `credentials_entity` |\n| Память агента | PostgreSQL `agent_db` | таблица `agent_memory` |\n| Модели Ollama | Docker Volume `ollama_data` | `/root/.ollama/models/` |\n| Конфиг n8n | Docker Volume `n8n_data` | `/home/node/.n8n/` |\n| Страницы Wiki | PostgreSQL `wiki_db` | таблица `pages` |\n\n## Сетевая безопасность\n\n- PostgreSQL слушает только `192.168.56.11` — недоступен снаружи подсети VM\n- `pg_hba.conf` ограничивает доступ к каждой БД конкретным источником\n- Ollama слушает `0.0.0.0:11434` — доступен из подсети (в продакшне закрыть файрволом)\n- n8n доступен с хоста через forwarded port 5678\n\n## Управление\n\n### Перезапуск сервисов\n\n```bash\n# n8n\nvagrant ssh n8n -c "docker restart n8n"\n\n# Ollama\nvagrant ssh ollama -c "cd /opt/ollama &amp;&amp; docker compose restart"\n\n# Wiki.js\nvagrant ssh wikijs -c "cd /opt/wikijs &amp;&amp; docker compose restart"\n\n# PostgreSQL\nvagrant ssh postgresql -c "sudo systemctl restart postgresql"\n</code></pre>\n<h3 id="просмотр-логов" class="toc-header"><a class="toc-anchor" href="#просмотр-логов">¶</a> Просмотр логов</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">vagrant ssh n8n -c "docker logs n8n --tail 50 -f"\nvagrant ssh ollama -c "docker logs ollama --tail 50 -f"\nvagrant ssh wikijs -c "docker logs wikijs --tail 50 -f"\nvagrant ssh postgresql -c "sudo journalctl -u postgresql -f"\n</code></pre>\n<h3 id="резервное-копирование-postgresql" class="toc-header"><a class="toc-anchor" href="#резервное-копирование-postgresql">¶</a> Резервное копирование PostgreSQL</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Бэкап всех БД\nvagrant ssh postgresql -c "\n  sudo -u postgres pg_dump n8n_db &gt; /tmp/n8n_db.sql\n  sudo -u postgres pg_dump agent_db &gt; /tmp/agent_db.sql\n  sudo -u postgres pg_dump wiki_db &gt; /tmp/wiki_db.sql\n"\n\n# Скопировать бэкапы на хост\nvagrant scp postgresql:/tmp/n8n_db.sql ./backups/\nvagrant scp postgresql:/tmp/agent_db.sql ./backups/\nvagrant scp postgresql:/tmp/wiki_db.sql ./backups/\n</code></pre>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">\n---\n\n## 12. Справочник портов и переменных\n\n### Порты\n\n| Сервис | VM | Порт внутри подсети | Порт на хосте |\n|--------|-----|---------------------|---------------|\n| n8n UI | 192.168.56.10 | :5678 | localhost:5678 |\n| PostgreSQL | 192.168.56.11 | :5432 | — (не пробрасывается) |\n| Ollama API | 192.168.56.12 | :11434 | localhost:11434 |\n| Wiki.js UI | 192.168.56.13 | :3000 | localhost:3000 |\n\n### Переменные окружения n8n\n\n| Переменная | Значение | Описание |\n|-----------|---------|---------|\n| `DB_TYPE` | `postgresdb` | Тип БД |\n| `DB_POSTGRESDB_HOST` | `192.168.56.11` | IP PostgreSQL |\n| `DB_POSTGRESDB_PORT` | `5432` | Порт PostgreSQL |\n| `DB_POSTGRESDB_DATABASE` | `n8n_db` | Имя БД |\n| `DB_POSTGRESDB_USER` | `n8n_user` | Пользователь |\n| `DB_POSTGRESDB_PASSWORD` | `n8n_strong_password_123` | Пароль |\n| `N8N_ENCRYPTION_KEY` | `&lt;32+ символа&gt;` | Ключ шифрования credentials |\n\n### Переменные окружения Wiki.js\n\n| Переменная | Значение |\n|-----------|---------|\n| `DB_TYPE` | `postgres` |\n| `DB_HOST` | `192.168.56.11` |\n| `DB_PORT` | `5432` |\n| `DB_USER` | `wiki_user` |\n| `DB_PASS` | `wiki_strong_password_123` |\n| `DB_NAME` | `wiki_db` |\n\n### Учётные данные PostgreSQL\n\n| БД | Пользователь | Пароль (поменяй!) |\n|----|-------------|-------------------|\n| `n8n_db` | `n8n_user` | `n8n_strong_password_123` |\n| `wiki_db` | `wiki_user` | `wiki_strong_password_123` |\n| `agent_db` | `agent_user` | `agent_strong_password_123` |\n\n---\n\n*Документация создана для проекта локального AI-агента. Обновляй при изменении конфигурации.*\n</code></pre>\n	[{"title":"Документация AI-агента на базе n8n + Ollama + PostgreSQL + Wiki.js","anchor":"#документация-ai-агента-на-базе-n8n-ollama-postgresql-wikijs","children":[{"title":"Содержание","anchor":"#содержание","children":[]},{"title":"1. Архитектура и топология сети","anchor":"#h-1-архитектура-и-топология-сети","children":[{"title":"Компоненты","anchor":"#компоненты","children":[]}]},{"title":"2. Подготовка окружения (Vagrant)","anchor":"#h-2-подготовка-окружения-vagrant","children":[{"title":"Vagrantfile","anchor":"#vagrantfile","children":[]},{"title":"Запуск","anchor":"#запуск","children":[]}]},{"title":"3. VM: PostgreSQL — установка и настройка","anchor":"#h-3-vm-postgresql-установка-и-настройка","children":[{"title":"3.1 Установка PostgreSQL","anchor":"#h-31-установка-postgresql","children":[]},{"title":"3.2 Настройка сетевого доступа","anchor":"#h-32-настройка-сетевого-доступа","children":[]},{"title":"3.3 Создание баз данных и пользователей","anchor":"#h-33-создание-баз-данных-и-пользователей","children":[]},{"title":"3.4 Проверка доступности из других VM","anchor":"#h-34-проверка-доступности-из-других-vm","children":[]},{"title":"3.5 Проверка ограничения доступа","anchor":"#h-35-проверка-ограничения-доступа","children":[]}]},{"title":"4. VM: n8n — Docker + первый запуск","anchor":"#h-4-vm-n8n-docker-первый-запуск","children":[{"title":"4.1 Установка Docker","anchor":"#h-41-установка-docker","children":[]},{"title":"4.2 Первый запуск n8n (SQLite, для проверки UI)","anchor":"#h-42-первый-запуск-n8n-sqlite-для-проверки-ui","children":[]},{"title":"4.3 Проверка UI","anchor":"#h-43-проверка-ui","children":[]}]},{"title":"5. n8n → перевод на PostgreSQL + персистентность","anchor":"#h-5-n8n-перевод-на-postgresql-персистентность","children":[{"title":"5.1 Остановить временный контейнер","anchor":"#h-51-остановить-временный-контейнер","children":[]},{"title":"5.2 Создать volume для данных n8n","anchor":"#h-52-создать-volume-для-данных-n8n","children":[]},{"title":"5.3 Запустить n8n с PostgreSQL","anchor":"#h-53-запустить-n8n-с-postgresql","children":[]},{"title":"5.4 Альтернатива: docker-compose (рекомендуется)","anchor":"#h-54-альтернатива-docker-compose-рекомендуется","children":[]},{"title":"5.5 Проверка персистентности","anchor":"#h-55-проверка-персистентности","children":[]}]},{"title":"6. VM: Ollama — Docker + LLM","anchor":"#h-6-vm-ollama-docker-llm","children":[{"title":"6.1 Установка Docker (аналогично n8n)","anchor":"#h-61-установка-docker-аналогично-n8n","children":[]},{"title":"6.2 Запуск Ollama в Docker","anchor":"#h-62-запуск-ollama-в-docker","children":[]},{"title":"6.3 Загрузка модели","anchor":"#h-63-загрузка-модели","children":[]},{"title":"6.4 Проверка через CLI","anchor":"#h-64-проверка-через-cli","children":[]},{"title":"6.5 Проверка через API","anchor":"#h-65-проверка-через-api","children":[]}]},{"title":"7. n8n: credential Ollama + минимальный workflow","anchor":"#h-7-n8n-credential-ollama-минимальный-workflow","children":[{"title":"7.1 Создание Credential для Ollama","anchor":"#h-71-создание-credential-для-ollama","children":[]},{"title":"7.2 Минимальный workflow: Chat → Ollama","anchor":"#h-72-минимальный-workflow-chat-ollama","children":[]},{"title":"7.3 Тест в чате","anchor":"#h-73-тест-в-чате","children":[]}]},{"title":"8. n8n: AI Agent workflow","anchor":"#h-8-n8n-ai-agent-workflow","children":[{"title":"8.1 Схема воркфлоу","anchor":"#h-81-схема-воркфлоу","children":[]},{"title":"8.2 Создание воркфлоу","anchor":"#h-82-создание-воркфлоу","children":[]},{"title":"8.3 Тест агента (3–5 запросов)","anchor":"#h-83-тест-агента-35-запросов","children":[]}]},{"title":"9. Память агента в PostgreSQL","anchor":"#h-9-память-агента-в-postgresql","children":[{"title":"9.1 Создание таблицы для памяти","anchor":"#h-91-создание-таблицы-для-памяти","children":[]},{"title":"9.2 Настройка Postgres Chat Memory в n8n","anchor":"#h-92-настройка-postgres-chat-memory-в-n8n","children":[]},{"title":"9.3 Схема воркфлоу с PostgreSQL памятью","anchor":"#h-93-схема-воркфлоу-с-postgresql-памятью","children":[]},{"title":"9.4 Тест персистентной памяти","anchor":"#h-94-тест-персистентной-памяти","children":[]}]},{"title":"10. VM: Wiki.js — Docker + PostgreSQL","anchor":"#h-10-vm-wikijs-docker-postgresql","children":[{"title":"10.1 Запуск Wiki.js","anchor":"#h-101-запуск-wikijs","children":[]},{"title":"10.2 Начальная настройка Wiki.js","anchor":"#h-102-начальная-настройка-wikijs","children":[]},{"title":"10.3 Проверка БД","anchor":"#h-103-проверка-бд","children":[]}]},{"title":"11. Страница «Архитектура AI-агента» в Wiki.js","anchor":"#h-11-страница-архитектура-ai-агента-в-wikijs","children":[{"title":"Как создать страницу","anchor":"#как-создать-страницу","children":[]},{"title":"Содержимое страницы (Markdown для Wiki.js)","anchor":"#содержимое-страницы-markdown-для-wikijs","children":[]},{"title":"Просмотр логов","anchor":"#просмотр-логов","children":[]},{"title":"Резервное копирование PostgreSQL","anchor":"#резервное-копирование-postgresql","children":[]}]}]}]	markdown	2026-03-20T16:52:03.461Z	2026-03-20T16:52:04.784Z	markdown	ru	1	1	{"js":"","css":""}
2	ClusterAPI	5cff0ea885cd9c037c58ef6bdd4deeae790108b0	ClusterAPI		f	t	\N			## Введение\n\nЕсли вы когда-нибудь создавали Kubernetes-кластеры вручную, то знаете, насколько это утомительно: подготовка VM, установка зависимостей, настройка сети, инициализация кластера, добавление worker-нод... И это только начало — потом нужно поддерживать, обновлять и масштабировать всё это хозяйство. Cluster API решает эту проблему, применяя философию Kubernetes к управлению самими кластерами. Вместо императивных команд вы описываете желаемое состояние в YAML-манифестах, а Cluster API автоматически создает, настраивает и поддерживает ваши кластеры.\n\nВ этой статье я расскажу, как запустить Cluster API (CAPI) на кластере Proxmox, который работает на Orange Pi 5 Plus с архитектурой ARM64. Для интеграции с Proxmox VE будем использовать Cluster API Provider Proxmox (CAPMOX) от [IONOS Cloud](https://github.com/ionos-cloud/cluster-api-provider-proxmox.git).\n\nВ результате мы получим полностью автоматизированное развёртывание Kubernetes-кластера, где Cluster API будет создавать виртуальные машины в Proxmox и сам устанавливать на них Kubernetes. \n\nПочему это интересно?\n\t\n- Orange Pi 5 Plus — это доступное и производительное ARM-устройство, которое отлично подходит для домашних лабораторий.\n- Proxmox VE позволяет удобно управлять виртуальными машинами и контейнерами.\n- Cluster API делает возможным управлять Kubernetes-кластерами как “инфраструктурой как код”.\n\nДалее не много теории, кому не интересно можно пролистать [сюда](#Proxmox)\n\n## Что такое Cluster API?\n\n**Cluster API (CAPI)** — это проект Kubernetes SIG Cluster Lifecycle, который предоставляет декларативные API и контроллеры для управления жизненным циклом Kubernetes-кластеров.\n\nГлавная идея:\n>Управлять кластерами Kubernetes так же, как и любыми другими ресурсами внутри Kubernetes, используя подход Infrastructure as Code.\n\n### Основные принципы Cluster API\n\n1. **Декларативное управление** - вы описываете желаемое состояние кластера в YAML-манифестах, а CAPI автоматически приводит инфраструктуру к этому состоянию.\n2. **Kubernetes-native подход** - все операции выполняются через стандартные Kubernetes API. Вам не нужны отдельные CLI или ручные действия — всё через kubectl.\n3. **Провайдер-агностичность** - Cluster API поддерживает разные инфраструктуры: AWS, Azure, Yandex, Proxmox, Docker и другие. Один и тот же подход работает везде.\n4. **Масштабируемость** - Можно управлять десятками кластеров из одного места — вашего management cluster.\n\n### Архитектура Cluster API\n\nCluster API состоит из нескольких ключевых компонентов, каждый из которых выполняет свою задачу:\n\t\n- **Management Cluster** — управляющий кластер\n- **Core Provider** — это набор основных контроллеров и CRD, которые образуют ядро Cluster API\n- **Infrastructure Provider** — провайдер инфраструктуры\n- **Bootstrap Provider** — провайдер начальной настройки\n- **Control Plane Provider** — провайдер управляющей плоскости\n- **Workload Cluster** — рабочий кластер\n\n## Основные компоненты Cluster API\n\n### 1. Management Cluster (Управляющий кластер)\n\n**Что это:** Kubernetes-кластер, который управляет всеми остальными. В нём запускаются контроллеры Cluster API и провайдеров инфраструктуры.\n\n**Функции:**\n- Хранит описание (манифесты) управляемых кластеров\n- Запускает контроллеры CAPI и следит за их состоянием\n- Координирует создание, обновление и удаление кластеров\n- Мониторит состояние управляемых кластеров\n\n**Простыми словами:** Это “мозг системы” — главный кластер, который управляет жизненным циклом всех остальных. В то же время, если management cluster упадёт, то все workload-кластеры продолжат работать как обычно, а доступ к ним сохранится при наличии kubeconfig. Однако без работающего management cluster вы не сможете создавать новые кластеры, масштабировать существующие или обновлять их конфигурацию — он нужен именно для управления, а не для работы приложений.\n\nВажно понимать: management cluster сам по себе не обязан быть большим и мощным.\n - Он может состоять всего из одной ноды,\n - Запускаться прямо в виртуалке на том же Proxmox,\n - Работать локально на ноутбуке через Kind или k3s.\n\nГлавное, чтобы он был доступен и мог управлять другими кластерами. \n\n### 2. Core Provider (Основной провайдер)\n\n**Что это:** \nЦентральный компонент Cluster API, который предоставляет базовую логику и оркестрацию всех операций с кластерами.\n\n**Состоит из:**\n- **Cluster API Controller Manager** — основной контроллер-оркестратор\n- **Custom Resource Definitions (CRDs)** — определения ресурсов Kubernetes\n- **Webhook сервер** — валидация и мутация ресурсов\n\n**Основные CRD:**\n```yaml\n# Cluster - описание целого кластера\napiVersion: cluster.x-k8s.io/v1beta1\nkind: Cluster\n\n# Machine - отдельная виртуальная машина/узел\napiVersion: cluster.x-k8s.io/v1beta1\nkind: Machine\n\n# MachineSet - группа идентичных машин (как ReplicaSet)\napiVersion: cluster.x-k8s.io/v1beta1\nkind: MachineSet\n\n# MachineDeployment - декларативные обновления машин (как Deployment)\napiVersion: cluster.x-k8s.io/v1beta1\nkind: MachineDeployment\n```\nФункции:\n\n- управление полным жизненным циклом кластеров\n- координация работы всех провайдеров (infrastructure, bootstrap, control plane)\n- обеспечение согласованности желаемого и текущего состояния\n- автоматическое восстановление при сбоях (self-healing)\n- реализация паттернов controller и reconciliation loop\n\nПростыми словами:\nЭто "дирижёр оркестра" — координирует всех остальных провайдеров и следит за общей картиной.\nВажно: Core Provider входит в базовую поставку cluster-api и устанавливается первым.\n\n### 3. Infrastructure Provider (провайдер инфраструктуры)\n\n**Что это:**\nКомпонент, отвечающий за взаимодействие с конкретной инфраструктурой (облаком или гипервизором).\n\n**Функции:**\n- создаёт виртуальные машины и сети\n- управляет их жизненным циклом (запуск, остановка, удаление)\n- работает через API выбранного провайдера\n- обеспечивает абстракцию от специфики инфраструктуры\n- автоматизирует подготовку окружения для кластеров\n\n**Простыми словами:**\nЭто "руки Cluster API", которые создают ресурсы там, где нужно. Каждый провайдер знает, как "разговаривать" со своей инфраструктурой.\n\n**Важно:** \n- Для каждого типа инфраструктуры нужен свой провайдер\n- Провайдеры унифицируют работу с разными платформами\n- В нашем случае используется **Proxmox Provider (CAPMOX)**\n\n**Популярные провайдеры:**\nAWS, Azure, GCP, VMware, OpenStack, Metal3, Docker\n\n### 4. Bootstrap Provider (провайдер начальной настройки)\n\n**Что это:**\nКомпонент, который превращает "чистую" VM в полноценную Kubernetes-ноду.\n\n**Функции:**\n- генерирует конфигурацию для инициализации узла\n- выполняет первичную настройку ОС и Kubernetes\n- подключает ноды к кластеру\n- обеспечивает безопасную передачу секретов и сертификатов\n- управляет процессом join новых узлов\n\n**Простыми словами:**\nЭто "пусковая установка" для каждой новой VM. Получает голую машину — возвращает готовый Kubernetes-узел.\n\n**Популярные Bootstrap Providers:**\n- **Kubeadm** — стандартный провайдер (по умолчанию)\n- **Talos** — immutable ОС, управляется через API\n- **K3s** — облегченный Kubernetes\n- **MicroK8s** — snap-based дистрибутив\n- **RKE2** — Rancher Kubernetes Engine\n- **k0s** — zero-deps дистрибутив\n\n**Важно:** Выбор bootstrap provider определяет, какая версия и дистрибутив Kubernetes будет использоваться в кластере.\n\n**В нашем случае используется kubeadm bootstrap provider.**\n\n### 5. Control Plane Provider (провайдер управляющей плоскости)\n\n**Что это:**\nКомпонент, который управляет **control plane** — "мозгом" Kubernetes-кластера (API server, etcd, controller-manager, scheduler).\n\n**Функции:**\n- создаёт и настраивает управляющие ноды\n- управляет масштабированием control plane (HA-режим)\n- контролирует rolling updates мастер-нод\n- следит за состоянием и здоровьем control plane компонентов\n- обеспечивает отказоустойчивость управляющего слоя\n\n**Простыми словами:**\nЭто "главврач" для мастер-нод. Следит, чтобы "мозг" кластера всегда был здоров и доступен.\n\n**Типы Control Plane Providers:**\n- **Kubeadm** — стандартный провайдер (самый популярный)\n- **Talos** — для immutable control plane\n- **K3s** — упрощенный control plane\n- **Managed** — для облачных managed Kubernetes (EKS, GKE, AKS)\n\n**Важно:** \n- В production рекомендуется минимум 3 control plane ноды для HA\n- Control plane и worker ноды могут использовать разные providers\n\n **В нашем случае используется kubeadm control plane provider.**\n\n### 6. Workload Cluster (рабочий кластер)\n\n**Что это:**\nЦелевой Kubernetes-кластер, в котором развертываются и выполняются ваши продуктивные приложения.\n\n**Функции:**\n- размещает рабочие нагрузки (Pods, Deployments, Services)\n- управляется декларативно через манифесты из management cluster\n- автоматически масштабируется и обновляется\n- изолирован от управляющего слоя для повышения безопасности\n- может располагаться в разных облаках или регионах\n\n**Простыми словами:**\nЭто "боевой" кластер, где живут ваши приложения. Management cluster его создает и настраивает, а workload cluster просто работает.\n\n**Важно:** Один management cluster может управлять множеством workload кластеров одновременно.\n\n# Как компоненты взаимодействуют\n\n## Процесс создания кластера\n\n1. **Пользователь** создает манифест `Cluster` в Management кластере\n2. **Core Provider** анализирует запрос и создает связанные ресурсы (Machine, MachineSet)\n3. **Infrastructure Provider** получает запрос на создание инфраструктуры и провиженит VM в Proxmox\n4. **Bootstrap Provider** генерирует cloud-init конфигурацию для установки и настройки Kubernetes\n5. **Control Plane Provider** инициализирует и настраивает control plane узлы (первый узел → join остальных)\n6. **Core Provider** координирует создание worker узлов через MachineDeployment\n7. **Workload кластер** становится готов к развертыванию приложений\n\n## Схема взаимодействия\n\n```\nManagement Cluster\n├── Core Provider (cluster-api-controller-manager)\n├── Infrastructure Provider (capmox-controller-manager)  \n├── Bootstrap Provider (kubeadm-bootstrap-controller-manager)\n└── Control Plane Provider (kubeadm-control-plane-controller-manager)\n     │\n     │ (API calls)\n     ▼\nProxmox Infrastructure\n├── Control Plane VMs (обычно 1 или 3+ для HA)\n└── Worker VMs (масштабируемо)\n     │\n     │ (kubeconfig)\n     ▼\nWorkload Cluster (новый кластер Kubernetes)\n└── Приложения пользователя\n```\n\n## Жизненный цикл ресурсов\n\n### Cluster (Кластер)\n- **Создание:** Координирует создание всех компонентов инфраструктуры\n- **Масштабирование:** Управляет горизонтальным добавлением/удалением узлов\n- **Обновление:** Координирует версионные апгрейды (Kubernetes, ОС, компонентов)\n- **Мониторинг:** Отслеживает состояние готовности всех узлов\n- **Удаление:** Очистка всех связанных ресурсов и инфраструктуры\n\n### Machine (Машина)\n- **Provisioning:** Создание VM через Infrastructure Provider\n- **Bootstrapping:** Установка и конфигурация Kubernetes через Bootstrap Provider\n- **Running:** Рабочее состояние узла с активным kubelet\n- **Draining:** Безопасная эвакуация подов перед обслуживанием\n- **Deleting:** Корректное удаление VM и очистка ресурсов\n\n### MachineDeployment (Развертывание машин)\n- Работает аналогично Kubernetes Deployment, но для физических машин\n- Обеспечивает декларативные обновления с контролем версий\n- Управляет rolling updates узлов с настраиваемой стратегией\n- Поддерживает горизонтальное автомасштабирование\n- Автоматически заменяет неисправные узлы (machine health checking)\n\n## Важные особенности\n\n**Reconciliation Loop:**\nКаждый провайдер работает по принципу "желаемое vs текущее состояние" и постоянно приводит систему к нужному состоянию.\n\n**Event-driven архитектура:**\nКомпоненты реагируют на изменения в Kubernetes API через watch механизм, что обеспечивает быструю реакцию на события.\n\n**Fail-safe механизмы:**\n- Автоматическое восстановление неисправных узлов\n- Проверка здоровья машин (machine health checks)\n- Graceful shutdown при удалении ресурсов\n\n**Multi-cluster management:**\nОдин Management кластер может одновременно управлять десятками Workload кластеров в разных окружениях.\n\n---\n\n<anchor>Proxmox</anchor>\n\n## **Начало установки**\nЗдесь я опишу по шагам как я пришел к конечной цели.  ARM64 стала популярным выбором для home lab'ов благодаря производительности и доступности. Многие энтузиасты покупают Orange Pi, Raspberry Pi 5 для экспериментов с Kubernetes. Железо доступное, энергоэффективное, а производительность впечатляет.  Но много подводных камней от начала создания ВМ в Proxmox (ошибка Bus 'ide.0' not found шина ide не поддерживается в Proxmox для ARM64)  до развертывания ClusterAPI, но все это решается.\n\n### Исходное состояние\n\nУ вас уже должен быть настроенный кластер Proxmox VE. Здесь я не буду описывать как установить Proxmox на Orange PI 5 plus. \n\n## Подготовка менеджмент-кластера\n\nCluster API всегда разворачивается из управляющего (management) кластера. Этот кластер нужен только для того, чтобы развернуть и управлять workload-кластерами. Сам он в продакшене не участвует, поэтому его можно поднять локально — на ноутбуке, рабочей станции или в отдельной VM.\n\nВариантов запуска менеджмент-кластера несколько:\n- **Minikube** — удобно для быстрого старта, но ограничено одной нодой.\n- **kind** — Kubernetes в Docker-контейнерах, простой и быстрый способ, подходит для локальной разработки.\n- **k3s / rke2** — лёгкий Kubernetes с упрощённой установкой, можно развернуть в VM или LXC.\n- **kubeadm** — классический способ, если хочется руками поднять «настоящий» кластер\n\nЯ выбрал kind, потому что:\n- не требует установки виртуализации или отдельных VM\n- быстро создаётся и удаляется\n- удобно использовать для тестов и работы с Cluster API\n\n### Установка kind\n\nНа ноутбуке (macOS):\n```\n# For M1 / ARM Macs\n[ $(uname -m) = arm64 ] && curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.30.0/kind-darwin-arm64\nchmod +x ./kind\nmv ./kind /some-dir-in-your-PATH/kind\n\n# проверка\nkind --version\n```\nДля других архитектур и систем можно посмотреть в официальной [документации](https://kind.sigs.k8s.io/docs/user/quick-start/) \n\nЕщё потребуется kubectl:\n```\ncurl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/$(uname | tr '[:upper:]' '[:lower:]')/arm64/kubectl"\nchmod +x kubectl\nsudo mv kubectl /usr/local/bin/\n```\n### Создание кластера\n\nСоздадим конфиг kind-config.yaml:\n```\nkind: Cluster\napiVersion: kind.x-k8s.io/v1alpha4\nname: capi-mgmt\nnodes:\n  - role: control-plane\n```\nПоднимаем кластер:\n```\nkind create cluster --config kind-config.yaml\n```\nПроверяем:\n```\nkubectl cluster-info\nkubectl get nodes\n```\n![](https://drive.google.com/file/d/19YhpVB_wd9RpMzgWsLVNN58HkcK6252W/view?usp=sharing)\n\nCluster API распространяется как набор контроллеров, которые устанавливаются в менеджмент-кластер и управляют жизненным циклом Kubernetes-кластеров. Для работы нам нужен инструмент **clusterctl**.\n\nУстановка clusterctl\n\nСкачаем бинарник (здесь и далее я буду приводить примеры для MacOS, для других OS ссылки можно взять в официальной документации):\n```\ncurl -L https://github.com/kubernetes-sigs/cluster-api/releases/download/v1.11.0/clusterctl-darwin-arm64 -o clusterctl\n\n#права на запуск \nchmod +x ./clusterctl\n\n#переместим в локальную директорию для  бинарей\nsudo mv ./clusterctl /usr/local/bin/clusterctl\n\n#проверка \nclusterctl version\n```\n\n### Подготовим настройки для инициализации ClusterAPI \n\nНужно создать выделенный токен для Proxmox user, это можно сделать в веб-интерфейсе или зайти на ноду Proxmox по ssh и дать команды:\n```\npveum user add capmox@pve\npveum aclmod / -user capmox@pve -role PVEVMAdmin\npveum user token add capmox@pve capi -privsep 0\n```\nПолученный токен нужно записать  в следующий файл ~/.cluster-api/clusterctl.yaml. В текущей директории пользователя нужно создать:\n```\nmkdir ~/.cluster-api\n```\nExample ~/.cluster-api/clusterctl.yaml\n```\n## -- Controller settings -- ##\nPROXMOX_URL: "https://192.168.1.11:8006"                       # The Proxmox VE host\nPROXMOX_TOKEN: "capmox@pve!capi"                                # The Proxmox VE TokenID for authentication\nPROXMOX_SECRET: "***********"                                    # Сюда пишем полученный токен\n\n\n## -- Required workload cluster default settings -- ##\nPROXMOX_SOURCENODE: "pimox2"                                     # Узел на котором размещен шаблон ВМ \nTEMPLATE_VMID: "5002"                                          # ID шаблона для клонирования\nALLOWED_NODES: "[pimox2]"                        # Узлы для развертывания ВМ, в моем случае один\nVM_SSH_KEYS: "ssh-ed25519 ..., ssh-ed25519 ..."               # The ssh authorized keys used to ssh to the machines.\n\n## -- networking configuration-- ##\nCONTROL_PLANE_ENDPOINT_IP: "192.168.1.30"                       # The IP that kube-vip is going to use as a control plane endpoint\nNODE_IP_RANGES: "[192.168.1.31-192.168.1.39]"               # The IP ranges for Cluster nodes\nGATEWAY: "192.168.1.1"                                         # The gateway for the machines network-config.\nIP_PREFIX: "24"                                               # Subnet Mask in CIDR notation for your node IP ranges\nDNS_SERVERS: "[8.8.8.8,8.8.4.4]"                              # The dns nameservers for the machines network-config.\nBRIDGE: "vmbr1"                                               # The network bridge device for Proxmox VE VMs\n\n## -- xl nodes -- ##\nBOOT_VOLUME_DEVICE: "scsi0"                                   # The device used for the boot disk.\nBOOT_VOLUME_SIZE: "30"                                       # The size of the boot disk in GB.\nNUM_SOCKETS: "2"                                              # The number of sockets for the VMs.\nNUM_CORES: "2"                                                # The number of cores for the VMs.\nMEMORY_MIB: "4096"                                            # The memory size for the VMs.\n\nEXP_CLUSTER_RESOURCE_SET: "true"                              # This enables the ClusterResourceSet feature that we are using to deploy CNI\nCLUSTER_TOPOLOGY: "true"                                      # This enables experimental ClusterClass templating\n```\nТут я привел свои настройки, по комментариям думаю все понятно.\n\nДальше нам нужно проинициализировать Cluster API в менеджмент кластер, после подготовки всех настроек нужно выполнить команду:\n```\nclusterctl init --infrastructure proxmox --ipam in-cluster\n``` \n---\n\nСейчас пройдемся по параметрам инициализации. Для чего нужен `--ipam in-cluster` я не описал его в начале статьи со всеми провайдерами. И так, IPAM (IP Address Management) провайдер отвечает за управление IP-адресами машин в кластере. Он особенно полезен для non-cloud развертываний, таких как Proxmox или bare metal.\n\n**Зачем это нужно:**\n- **Автоматическое выделение IP** — не нужно вручную указывать адреса для каждой VM\n- **Управление пулами адресов** — можете создать диапазоны IP для разных кластеров\n- **Предотвращение конфликтов** — система следит, чтобы адреса не пересекались\n- **Декларативность** — IP-адреса управляются через Kubernetes ресурсы\n\n**Альтернатива без IPAM:** Придется вручную прописывать IP-адреса в каждом манифесте Machine.\n\n## Все параметры `clusterctl init`\n\n### Основной синтаксис:\n```bash\nclusterctl init [flags] [provider1] [provider2] ...\n```\n\n### Основные флаги:\n\n| Параметр | Описание | Пример |\n|----------|----------|---------|\n| `--core` | Версия core провайдера | `--core cluster-api:v1.6.1` |\n| `--infrastructure` | Infrastructure провайдер | `--infrastructure proxmox` |\n| `--bootstrap` | Bootstrap провайдер | `--bootstrap kubeadm:v1.6.1` |\n| `--control-plane` | Control plane провайдер | `--control-plane kubeadm:v1.6.1` |\n| `--addon` | Addon провайдер | `--addon helm` |\n| `--ipam` | IPAM провайдер | `--ipam in-cluster` |\n\n### Дополнительные флаги:\n\n| Параметр | Описание | Пример |\n|----------|----------|---------|\n| `--target-namespace` | Namespace для установки | `--target-namespace capi-system` |\n| `--watching-namespace` | Namespace для мониторинга | `--watching-namespace ""` (все) |\n| `--config` | Путь к файлу конфигурации | `--config ~/.cluster-api/clusterctl.yaml` |\n| `--wait-providers` | Ждать готовности провайдеров | `--wait-providers` |\n| `--wait-provider-timeout` | Таймаут ожидания | `--wait-provider-timeout 5m` |\n\n### Примеры использования:\n\n#### Полная установка с версиями:\n```bash\nclusterctl init \\\n  --core cluster-api:v1.6.1 \\\n  --bootstrap kubeadm:v1.6.1 \\\n  --control-plane kubeadm:v1.6.1 \\\n  --infrastructure proxmox:v0.5.0 \\\n  --ipam in-cluster\n```\n\n#### Установка в custom namespace:\n```bash\nclusterctl init \\\n  --infrastructure aws \\\n  --target-namespace custom-capi-system\n```\n\n## Автоматические провайдеры\n\nclusterctl автоматически добавляет cluster-api core провайдер, kubeadm bootstrap провайдер и kubeadm control-plane провайдер, если они не указаны явно.\n\n**Это означает, что команда:**\n```bash\nclusterctl init --infrastructure proxmox\n```\n\n**Эквивалентна:**\n```bash\nclusterctl init \\\n  --core cluster-api \\\n  --bootstrap kubeadm \\\n  --control-plane kubeadm \\\n  --infrastructure proxmox\n```\n---\nИ так после выполнения команды `clusterctl init --infrastructure proxmox --ipam in-cluster` мы получили:\n![]("https://drive.google.com/file/d/1E14RjME2bJVS0zHZzLwb4QCd8ajNQJrx/view?usp=share_link")\nНе много подождав можно проверить запущенные провайдеры\n![]( "https://drive.google.com/file/d/1kcA1tFql-ZTKuGWVUrlCRdfJMW3rGrKE/view?usp=sharing")\n\nManagement кластер теперь готов создавать и управлять Kubernetes кластерами на Proxmox инфраструктуре. Достаточно применить нужные манифесты — и система автоматически развернет новый кластер. Теперь сгенерируем манифесты или можно написать с нуля:\n```\nclusterctl generate cluster myproxmoxcluster \\\n    --infrastructure proxmox \\\n    --kubernetes-version v1.32.0 \\\n    --control-plane-machine-count 1 \\\n    --worker-machine-count 1 > cluster.yaml\n``` \nСодержимое моего файла [cluster.yaml](https://github.com/filatof/example-cluster.yaml.git)\n\nКластер конфигурируется с одной control-plane и одной worker нодой, но можно легко изменить количество в манифестах через параметры `replicas` в соответствующих ресурсах.\n\nЗапускаем создание кластера:\n```bash\nkubectl apply -f cluster.yaml\n```\n>На этом этапе я получил первую проблему, которую долго не мог решить, и уже думал закончить эксперименты с ClusterAPI ))) Но нашел решение, в исходнике поменял значение константы и пересобрал Dockerfile. Я сделал [issues](https://github.com/ionos-cloud/cluster-api-provider-proxmox/issues/523#issue-3274555314) в репозиторий разработчика, с просьбой поправить этот момент и сделать настраиваемый выбор шины, но ответа так и не получил. На днях у них вышла новая версия 0.7.4 и метод с исправлением константы не работает, я написал еще [issues](https://github.com/ionos-cloud/cluster-api-provider-proxmox/issues/548#issue-3369940126). Так что пока можно использовать версию 0.7.3\n\nПри создании VM получаем ошибку:\n```\nBus 'ide.0' not found\nTASK ERROR: start failed: QEMU exited with code 1\n```\n\n**Корень проблемы:**\nProxmox Provider захардкодил в коде использование `ide0` шины для cloud-init ISO, но ARM64 архитектура в Proxmox **не поддерживает IDE шины**. Даже если в template VM настроена SCSI шина, провайдер принудительно пытается создать IDE устройство.\n### Решение проблемы\nМожно пересобрать `dockerfile` или взять мой готовый образ `docker pull filatof/capmox:v0.7.3`\n\n**Шаг 1:** Клонируем репозиторий провайдера\n```bash\ngit clone https://github.com/ionos-cloud/cluster-api-provider-proxmox.git\ncd cluster-api-provider-proxmox\n```\n\n**Шаг 2:** Правим константу в исходном коде, файл internal/inject/inject.go\n```go\n// Файл: internal/inject/inject.go\n// Было:\nconst CloudInitISODevice = "ide0"\n\n// Стало:\nconst CloudInitISODevice = "scsi1"\n```\n\n**Шаг 3:** Пересобираем Docker образ\n```bash\n# Сборка для ARM64\ndocker build --platform linux/arm64 -t filatof/capmox:v0.7.3 .\n\n# Или если собираете на x86_64 для ARM64\ndocker buildx build --platform linux/arm64 -t filatof/capmox:v0.7.3 .\n```\n\n**Шаг 4:** Обновляем деплоймент провайдера\n```bash\nkubectl patch deployment capmox-controller-manager \\\n  -n capmox-system \\\n  -p '{"spec":{"template":{"spec":{"containers":[{"name":"manager","image":"filatof/capmox:v0.7.3"}]}}}}'\n```\n\n### Важные моменты:\n\n**Почему именно `scsi1`:**\n- `scsi0` обычно занят основным диском VM\n- `scsi1` безопасный выбор для cloud-init ISO\n- `scsi` шина полностью поддерживается на ARM64\n\nПоправили образ Proxmox провайдера, и теперь  можно запускать создание кластера:\n```bash\nkubectl apply -f cluster.yaml\n```\nВМ не создаются, получаю следующую ошибку:\n![]("https://drive.google.com/file/d/1eZu6kpCGYZsios9UZY3DfJohPcByktoa/view?usp=sharing")\n\nПосмотрим так: \n```\nkubectl describe machine myproxmoxcluster-control-plane-qt52f\n```\nОшибка `InsufficientResources` говорит, что провайдер не смог выделить для VM память, указанную в манифесте. \n```\ncannot reserve 2147483648B of memory on node pimox2: 0B available memory left\n```\n- 2147483648B = 2 ГБ — именно столько просит ProxmoxMachine для запуска ноды.\n- 0B available memory left — провайдер думает, что на узле нет свободной памяти.\n\nПоэтому ресурс ProxmoxMachine уходит в статус Failed с причиной InsufficientResources.\n\n**Решение** \nДобавить параметр `schedulerHints` в манифест: \n```\napiVersion: infrastructure.cluster.x-k8s.io/v1alpha1\nkind: ProxmoxCluster\nmetadata:\n  name: myproxmoxcluster\n  namespace: default\nspec:\n  schedulerHints:\n    memoryAdjustment: 0\n```\nВ спецификации ProxmoxCluster есть параметр \n```\nschedulerHints:\n    memoryAdjustment: 0\n```\nОн определяет, как CAPMox учитывает доступную память на узле при запуске новых виртуальных машин.\n- Положительное значение (memoryAdjustment: 512)\nПровайдер зарезервирует дополнительно 512 МБ. Это полезно, если вы хотите оставить запас памяти для самого Proxmox и сервисов на хосте.\n- Ноль (memoryAdjustment: 0)\nПланировщик будет использовать всю доступную память. В этом случае узел максимально загружается, но есть риск, что Proxmox останется без резерва.\n- Отрицательное значение (memoryAdjustment: -512)\n«Обман» планировщика: он будет считать, что на узле есть больше памяти, чем реально. Можно использовать только для тестов, так как велик риск падения нод из-за OOM.\n\nНа ARM-платформах (Orange Pi, Raspberry Pi) часто встречается ситуация, когда CAPMox ошибочно считает, что на узле нет свободной памяти (0B available). В таких случаях установка:\n```\nschedulerHints:\n  memoryAdjustment: 0\n```\nпозволяет обойти проверку и успешно создавать кластеры.\nЗапускаем создание кластера:\n```bash\nkubectl apply -f cluster.yaml\n```\nИ получаю запущенные ВМ:\n![]( "https://drive.google.com/file/d/18pAfF5hB0Xsj7ezW-ZOVZNI8ZaIj9USS/view?usp=sharing")\n\nТеперь нужно получить `kubeconfig` для управления воркер кластером, выполним команду:\n```\nclusterctl get kubeconfig myproxmoxcluster > kubeconfig\n```\nЧтобы посмотреть запущенные поды кластера выполним команду:\n```\nKUBECONFIG=kubeconfig kubectl get pod -A\n```\n![]("https://drive.google.com/file/d/1TKQhw_jp-EV4C_uYeFHxahFXOAmn9jbP/view?usp=sharing")\n\nКластер совсем пустой. Ноды еще не перешли в готовность, потому-то не установлено CNI \n\n![]("https://drive.google.com/file/d/1MnexIjaB81JjUvbH6lBIZ_PEih6zMqyt/view?usp=sharing")\n\nУстановим calico, выполним команду: \n```\nKUBECONFIG=kubeconfig kubectl apply -f https://docs.projectcalico.org/manifests/calico.yaml\n```\nНе много подождем пока скачаются образы и запустятся поды. В итоге получаем рабочий кластер\n![]("https://drive.google.com/file/d/1cy0AmXK15D8c4-9mtqz7F44MhhcBccl0/view?usp=sharing")\n\n## Вывод\n\n**Что получилось:**\nВ результате всех экспериментов мы создали полноценную  платформу для автоматического развертывания Kubernetes-кластеров на ARM64 архитектуре. Orange Pi 5 Plus  база для домашней лаборатории — его производительности достаточно для одновременной работы Management кластера и нескольких Workload кластеров.\n\n**Экономия ресурсов:**\nCluster API кардинально меняет подход к управлению инфраструктурой. То, что раньше требовало многочасовой ручной работы и высокой вероятности ошибок, теперь выполняется за 5-10 минут одной командой `kubectl apply`. Декларативный подход превращает инфраструктуру в код — версионируемый, воспроизводимый и предсказуемый.\n\n**ARM64 как платформа:**\nСвязка ARM64 + Proxmox + Cluster API оказалась не только работоспособной, но и практичной для реальных задач. Энергоэффективность, доступность железа  делают ARM64 серьезной альтернативой x86_64 для  домашних лабораторий.\n\n**Практическая ценность:**\nТеперь у нас есть foundation для более сложных сценариев — управление множественными кластерами, быстрое восстановление после сбоев, и полноценного GitOps workflow.\n\n---\n\nВ следующей статье покажу, как сделать процесс развертывания кластера еще проще:\n- CNI (Cilium, Calico) устанавливается автоматически вместе с кластером\n- Управление кластерами через Git с помощью FluxCD\n- Создание кластеров простым commit'ом в репозиторий	<h2 id="введение" class="toc-header"><a class="toc-anchor" href="#введение">¶</a> Введение</h2>\n<p>Если вы когда-нибудь создавали Kubernetes-кластеры вручную, то знаете, насколько это утомительно: подготовка VM, установка зависимостей, настройка сети, инициализация кластера, добавление worker-нод... И это только начало — потом нужно поддерживать, обновлять и масштабировать всё это хозяйство. Cluster API решает эту проблему, применяя философию Kubernetes к управлению самими кластерами. Вместо императивных команд вы описываете желаемое состояние в YAML-манифестах, а Cluster API автоматически создает, настраивает и поддерживает ваши кластеры.</p>\n<p>В этой статье я расскажу, как запустить Cluster API (CAPI) на кластере Proxmox, который работает на Orange Pi 5 Plus с архитектурой ARM64. Для интеграции с Proxmox VE будем использовать Cluster API Provider Proxmox (CAPMOX) от <a href="https://github.com/ionos-cloud/cluster-api-provider-proxmox.git" class="is-external-link">IONOS Cloud</a>.</p>\n<p>В результате мы получим полностью автоматизированное развёртывание Kubernetes-кластера, где Cluster API будет создавать виртуальные машины в Proxmox и сам устанавливать на них Kubernetes.</p>\n<p>Почему это интересно?</p>\n<ul>\n<li>Orange Pi 5 Plus — это доступное и производительное ARM-устройство, которое отлично подходит для домашних лабораторий.</li>\n<li>Proxmox VE позволяет удобно управлять виртуальными машинами и контейнерами.</li>\n<li>Cluster API делает возможным управлять Kubernetes-кластерами как “инфраструктурой как код”.</li>\n</ul>\n<p>Далее не много теории, кому не интересно можно пролистать <a href="#Proxmox">сюда</a></p>\n<h2 id="что-такое-cluster-api" class="toc-header"><a class="toc-anchor" href="#что-такое-cluster-api">¶</a> Что такое Cluster API?</h2>\n<p><strong>Cluster API (CAPI)</strong> — это проект Kubernetes SIG Cluster Lifecycle, который предоставляет декларативные API и контроллеры для управления жизненным циклом Kubernetes-кластеров.</p>\n<p>Главная идея:</p>\n<blockquote>\n<p>Управлять кластерами Kubernetes так же, как и любыми другими ресурсами внутри Kubernetes, используя подход Infrastructure as Code.</p>\n</blockquote>\n<h3 id="основные-принципы-cluster-api" class="toc-header"><a class="toc-anchor" href="#основные-принципы-cluster-api">¶</a> Основные принципы Cluster API</h3>\n<ol>\n<li><strong>Декларативное управление</strong> - вы описываете желаемое состояние кластера в YAML-манифестах, а CAPI автоматически приводит инфраструктуру к этому состоянию.</li>\n<li><strong>Kubernetes-native подход</strong> - все операции выполняются через стандартные Kubernetes API. Вам не нужны отдельные CLI или ручные действия — всё через kubectl.</li>\n<li><strong>Провайдер-агностичность</strong> - Cluster API поддерживает разные инфраструктуры: AWS, Azure, Yandex, Proxmox, Docker и другие. Один и тот же подход работает везде.</li>\n<li><strong>Масштабируемость</strong> - Можно управлять десятками кластеров из одного места — вашего management cluster.</li>\n</ol>\n<h3 id="архитектура-cluster-api" class="toc-header"><a class="toc-anchor" href="#архитектура-cluster-api">¶</a> Архитектура Cluster API</h3>\n<p>Cluster API состоит из нескольких ключевых компонентов, каждый из которых выполняет свою задачу:</p>\n<ul>\n<li><strong>Management Cluster</strong> — управляющий кластер</li>\n<li><strong>Core Provider</strong> — это набор основных контроллеров и CRD, которые образуют ядро Cluster API</li>\n<li><strong>Infrastructure Provider</strong> — провайдер инфраструктуры</li>\n<li><strong>Bootstrap Provider</strong> — провайдер начальной настройки</li>\n<li><strong>Control Plane Provider</strong> — провайдер управляющей плоскости</li>\n<li><strong>Workload Cluster</strong> — рабочий кластер</li>\n</ul>\n<h2 id="основные-компоненты-cluster-api" class="toc-header"><a class="toc-anchor" href="#основные-компоненты-cluster-api">¶</a> Основные компоненты Cluster API</h2>\n<h3 id="h-1-management-cluster-управляющий-кластер" class="toc-header"><a class="toc-anchor" href="#h-1-management-cluster-управляющий-кластер">¶</a> 1. Management Cluster (Управляющий кластер)</h3>\n<p><strong>Что это:</strong> Kubernetes-кластер, который управляет всеми остальными. В нём запускаются контроллеры Cluster API и провайдеров инфраструктуры.</p>\n<p><strong>Функции:</strong></p>\n<ul>\n<li>Хранит описание (манифесты) управляемых кластеров</li>\n<li>Запускает контроллеры CAPI и следит за их состоянием</li>\n<li>Координирует создание, обновление и удаление кластеров</li>\n<li>Мониторит состояние управляемых кластеров</li>\n</ul>\n<p><strong>Простыми словами:</strong> Это “мозг системы” — главный кластер, который управляет жизненным циклом всех остальных. В то же время, если management cluster упадёт, то все workload-кластеры продолжат работать как обычно, а доступ к ним сохранится при наличии kubeconfig. Однако без работающего management cluster вы не сможете создавать новые кластеры, масштабировать существующие или обновлять их конфигурацию — он нужен именно для управления, а не для работы приложений.</p>\n<p>Важно понимать: management cluster сам по себе не обязан быть большим и мощным.</p>\n<ul>\n<li>Он может состоять всего из одной ноды,</li>\n<li>Запускаться прямо в виртуалке на том же Proxmox,</li>\n<li>Работать локально на ноутбуке через Kind или k3s.</li>\n</ul>\n<p>Главное, чтобы он был доступен и мог управлять другими кластерами.</p>\n<h3 id="h-2-core-provider-основной-провайдер" class="toc-header"><a class="toc-anchor" href="#h-2-core-provider-основной-провайдер">¶</a> 2. Core Provider (Основной провайдер)</h3>\n<p><strong>Что это:</strong><br>\nЦентральный компонент Cluster API, который предоставляет базовую логику и оркестрацию всех операций с кластерами.</p>\n<p><strong>Состоит из:</strong></p>\n<ul>\n<li><strong>Cluster API Controller Manager</strong> — основной контроллер-оркестратор</li>\n<li><strong>Custom Resource Definitions (CRDs)</strong> — определения ресурсов Kubernetes</li>\n<li><strong>Webhook сервер</strong> — валидация и мутация ресурсов</li>\n</ul>\n<p><strong>Основные CRD:</strong></p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-yaml"># Cluster - описание целого кластера\napiVersion: cluster.x-k8s.io/v1beta1\nkind: Cluster\n\n# Machine - отдельная виртуальная машина/узел\napiVersion: cluster.x-k8s.io/v1beta1\nkind: Machine\n\n# MachineSet - группа идентичных машин (как ReplicaSet)\napiVersion: cluster.x-k8s.io/v1beta1\nkind: MachineSet\n\n# MachineDeployment - декларативные обновления машин (как Deployment)\napiVersion: cluster.x-k8s.io/v1beta1\nkind: MachineDeployment\n</code></pre>\n<p>Функции:</p>\n<ul>\n<li>управление полным жизненным циклом кластеров</li>\n<li>координация работы всех провайдеров (infrastructure, bootstrap, control plane)</li>\n<li>обеспечение согласованности желаемого и текущего состояния</li>\n<li>автоматическое восстановление при сбоях (self-healing)</li>\n<li>реализация паттернов controller и reconciliation loop</li>\n</ul>\n<p>Простыми словами:<br>\nЭто "дирижёр оркестра" — координирует всех остальных провайдеров и следит за общей картиной.<br>\nВажно: Core Provider входит в базовую поставку cluster-api и устанавливается первым.</p>\n<h3 id="h-3-infrastructure-provider-провайдер-инфраструктуры" class="toc-header"><a class="toc-anchor" href="#h-3-infrastructure-provider-провайдер-инфраструктуры">¶</a> 3. Infrastructure Provider (провайдер инфраструктуры)</h3>\n<p><strong>Что это:</strong><br>\nКомпонент, отвечающий за взаимодействие с конкретной инфраструктурой (облаком или гипервизором).</p>\n<p><strong>Функции:</strong></p>\n<ul>\n<li>создаёт виртуальные машины и сети</li>\n<li>управляет их жизненным циклом (запуск, остановка, удаление)</li>\n<li>работает через API выбранного провайдера</li>\n<li>обеспечивает абстракцию от специфики инфраструктуры</li>\n<li>автоматизирует подготовку окружения для кластеров</li>\n</ul>\n<p><strong>Простыми словами:</strong><br>\nЭто "руки Cluster API", которые создают ресурсы там, где нужно. Каждый провайдер знает, как "разговаривать" со своей инфраструктурой.</p>\n<p><strong>Важно:</strong></p>\n<ul>\n<li>Для каждого типа инфраструктуры нужен свой провайдер</li>\n<li>Провайдеры унифицируют работу с разными платформами</li>\n<li>В нашем случае используется <strong>Proxmox Provider (CAPMOX)</strong></li>\n</ul>\n<p><strong>Популярные провайдеры:</strong><br>\nAWS, Azure, GCP, VMware, OpenStack, Metal3, Docker</p>\n<h3 id="h-4-bootstrap-provider-провайдер-начальной-настройки" class="toc-header"><a class="toc-anchor" href="#h-4-bootstrap-provider-провайдер-начальной-настройки">¶</a> 4. Bootstrap Provider (провайдер начальной настройки)</h3>\n<p><strong>Что это:</strong><br>\nКомпонент, который превращает "чистую" VM в полноценную Kubernetes-ноду.</p>\n<p><strong>Функции:</strong></p>\n<ul>\n<li>генерирует конфигурацию для инициализации узла</li>\n<li>выполняет первичную настройку ОС и Kubernetes</li>\n<li>подключает ноды к кластеру</li>\n<li>обеспечивает безопасную передачу секретов и сертификатов</li>\n<li>управляет процессом join новых узлов</li>\n</ul>\n<p><strong>Простыми словами:</strong><br>\nЭто "пусковая установка" для каждой новой VM. Получает голую машину — возвращает готовый Kubernetes-узел.</p>\n<p><strong>Популярные Bootstrap Providers:</strong></p>\n<ul>\n<li><strong>Kubeadm</strong> — стандартный провайдер (по умолчанию)</li>\n<li><strong>Talos</strong> — immutable ОС, управляется через API</li>\n<li><strong>K3s</strong> — облегченный Kubernetes</li>\n<li><strong>MicroK8s</strong> — snap-based дистрибутив</li>\n<li><strong>RKE2</strong> — Rancher Kubernetes Engine</li>\n<li><strong>k0s</strong> — zero-deps дистрибутив</li>\n</ul>\n<p><strong>Важно:</strong> Выбор bootstrap provider определяет, какая версия и дистрибутив Kubernetes будет использоваться в кластере.</p>\n<p><strong>В нашем случае используется kubeadm bootstrap provider.</strong></p>\n<h3 id="h-5-control-plane-provider-провайдер-управляющей-плоскости" class="toc-header"><a class="toc-anchor" href="#h-5-control-plane-provider-провайдер-управляющей-плоскости">¶</a> 5. Control Plane Provider (провайдер управляющей плоскости)</h3>\n<p><strong>Что это:</strong><br>\nКомпонент, который управляет <strong>control plane</strong> — "мозгом" Kubernetes-кластера (API server, etcd, controller-manager, scheduler).</p>\n<p><strong>Функции:</strong></p>\n<ul>\n<li>создаёт и настраивает управляющие ноды</li>\n<li>управляет масштабированием control plane (HA-режим)</li>\n<li>контролирует rolling updates мастер-нод</li>\n<li>следит за состоянием и здоровьем control plane компонентов</li>\n<li>обеспечивает отказоустойчивость управляющего слоя</li>\n</ul>\n<p><strong>Простыми словами:</strong><br>\nЭто "главврач" для мастер-нод. Следит, чтобы "мозг" кластера всегда был здоров и доступен.</p>\n<p><strong>Типы Control Plane Providers:</strong></p>\n<ul>\n<li><strong>Kubeadm</strong> — стандартный провайдер (самый популярный)</li>\n<li><strong>Talos</strong> — для immutable control plane</li>\n<li><strong>K3s</strong> — упрощенный control plane</li>\n<li><strong>Managed</strong> — для облачных managed Kubernetes (EKS, GKE, AKS)</li>\n</ul>\n<p><strong>Важно:</strong></p>\n<ul>\n<li>В production рекомендуется минимум 3 control plane ноды для HA</li>\n<li>Control plane и worker ноды могут использовать разные providers</li>\n</ul>\n<p><strong>В нашем случае используется kubeadm control plane provider.</strong></p>\n<h3 id="h-6-workload-cluster-рабочий-кластер" class="toc-header"><a class="toc-anchor" href="#h-6-workload-cluster-рабочий-кластер">¶</a> 6. Workload Cluster (рабочий кластер)</h3>\n<p><strong>Что это:</strong><br>\nЦелевой Kubernetes-кластер, в котором развертываются и выполняются ваши продуктивные приложения.</p>\n<p><strong>Функции:</strong></p>\n<ul>\n<li>размещает рабочие нагрузки (Pods, Deployments, Services)</li>\n<li>управляется декларативно через манифесты из management cluster</li>\n<li>автоматически масштабируется и обновляется</li>\n<li>изолирован от управляющего слоя для повышения безопасности</li>\n<li>может располагаться в разных облаках или регионах</li>\n</ul>\n<p><strong>Простыми словами:</strong><br>\nЭто "боевой" кластер, где живут ваши приложения. Management cluster его создает и настраивает, а workload cluster просто работает.</p>\n<p><strong>Важно:</strong> Один management cluster может управлять множеством workload кластеров одновременно.</p>\n<h1 id="как-компоненты-взаимодействуют" class="toc-header"><a class="toc-anchor" href="#как-компоненты-взаимодействуют">¶</a> Как компоненты взаимодействуют</h1>\n<h2 id="процесс-создания-кластера" class="toc-header"><a class="toc-anchor" href="#процесс-создания-кластера">¶</a> Процесс создания кластера</h2>\n<ol>\n<li><strong>Пользователь</strong> создает манифест <code>Cluster</code> в Management кластере</li>\n<li><strong>Core Provider</strong> анализирует запрос и создает связанные ресурсы (Machine, MachineSet)</li>\n<li><strong>Infrastructure Provider</strong> получает запрос на создание инфраструктуры и провиженит VM в Proxmox</li>\n<li><strong>Bootstrap Provider</strong> генерирует cloud-init конфигурацию для установки и настройки Kubernetes</li>\n<li><strong>Control Plane Provider</strong> инициализирует и настраивает control plane узлы (первый узел → join остальных)</li>\n<li><strong>Core Provider</strong> координирует создание worker узлов через MachineDeployment</li>\n<li><strong>Workload кластер</strong> становится готов к развертыванию приложений</li>\n</ol>\n<h2 id="схема-взаимодействия" class="toc-header"><a class="toc-anchor" href="#схема-взаимодействия">¶</a> Схема взаимодействия</h2>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">Management Cluster\n├── Core Provider (cluster-api-controller-manager)\n├── Infrastructure Provider (capmox-controller-manager)  \n├── Bootstrap Provider (kubeadm-bootstrap-controller-manager)\n└── Control Plane Provider (kubeadm-control-plane-controller-manager)\n     │\n     │ (API calls)\n     ▼\nProxmox Infrastructure\n├── Control Plane VMs (обычно 1 или 3+ для HA)\n└── Worker VMs (масштабируемо)\n     │\n     │ (kubeconfig)\n     ▼\nWorkload Cluster (новый кластер Kubernetes)\n└── Приложения пользователя\n</code></pre>\n<h2 id="жизненный-цикл-ресурсов" class="toc-header"><a class="toc-anchor" href="#жизненный-цикл-ресурсов">¶</a> Жизненный цикл ресурсов</h2>\n<h3 id="cluster-кластер" class="toc-header"><a class="toc-anchor" href="#cluster-кластер">¶</a> Cluster (Кластер)</h3>\n<ul>\n<li><strong>Создание:</strong> Координирует создание всех компонентов инфраструктуры</li>\n<li><strong>Масштабирование:</strong> Управляет горизонтальным добавлением/удалением узлов</li>\n<li><strong>Обновление:</strong> Координирует версионные апгрейды (Kubernetes, ОС, компонентов)</li>\n<li><strong>Мониторинг:</strong> Отслеживает состояние готовности всех узлов</li>\n<li><strong>Удаление:</strong> Очистка всех связанных ресурсов и инфраструктуры</li>\n</ul>\n<h3 id="machine-машина" class="toc-header"><a class="toc-anchor" href="#machine-машина">¶</a> Machine (Машина)</h3>\n<ul>\n<li><strong>Provisioning:</strong> Создание VM через Infrastructure Provider</li>\n<li><strong>Bootstrapping:</strong> Установка и конфигурация Kubernetes через Bootstrap Provider</li>\n<li><strong>Running:</strong> Рабочее состояние узла с активным kubelet</li>\n<li><strong>Draining:</strong> Безопасная эвакуация подов перед обслуживанием</li>\n<li><strong>Deleting:</strong> Корректное удаление VM и очистка ресурсов</li>\n</ul>\n<h3 id="machinedeployment-развертывание-машин" class="toc-header"><a class="toc-anchor" href="#machinedeployment-развертывание-машин">¶</a> MachineDeployment (Развертывание машин)</h3>\n<ul>\n<li>Работает аналогично Kubernetes Deployment, но для физических машин</li>\n<li>Обеспечивает декларативные обновления с контролем версий</li>\n<li>Управляет rolling updates узлов с настраиваемой стратегией</li>\n<li>Поддерживает горизонтальное автомасштабирование</li>\n<li>Автоматически заменяет неисправные узлы (machine health checking)</li>\n</ul>\n<h2 id="важные-особенности" class="toc-header"><a class="toc-anchor" href="#важные-особенности">¶</a> Важные особенности</h2>\n<p><strong>Reconciliation Loop:</strong><br>\nКаждый провайдер работает по принципу "желаемое vs текущее состояние" и постоянно приводит систему к нужному состоянию.</p>\n<p><strong>Event-driven архитектура:</strong><br>\nКомпоненты реагируют на изменения в Kubernetes API через watch механизм, что обеспечивает быструю реакцию на события.</p>\n<p><strong>Fail-safe механизмы:</strong></p>\n<ul>\n<li>Автоматическое восстановление неисправных узлов</li>\n<li>Проверка здоровья машин (machine health checks)</li>\n<li>Graceful shutdown при удалении ресурсов</li>\n</ul>\n<p><strong>Multi-cluster management:</strong><br>\nОдин Management кластер может одновременно управлять десятками Workload кластеров в разных окружениях.</p>\n<hr>\n<p>Proxmox</p>\n<h2 id="начало-установки" class="toc-header"><a class="toc-anchor" href="#начало-установки">¶</a> <strong>Начало установки</strong></h2>\n<p>Здесь я опишу по шагам как я пришел к конечной цели.  ARM64 стала популярным выбором для home lab'ов благодаря производительности и доступности. Многие энтузиасты покупают Orange Pi, Raspberry Pi 5 для экспериментов с Kubernetes. Железо доступное, энергоэффективное, а производительность впечатляет.  Но много подводных камней от начала создания ВМ в Proxmox (ошибка Bus 'ide.0' not found шина ide не поддерживается в Proxmox для ARM64)  до развертывания ClusterAPI, но все это решается.</p>\n<h3 id="исходное-состояние" class="toc-header"><a class="toc-anchor" href="#исходное-состояние">¶</a> Исходное состояние</h3>\n<p>У вас уже должен быть настроенный кластер Proxmox VE. Здесь я не буду описывать как установить Proxmox на Orange PI 5 plus.</p>\n<h2 id="подготовка-менеджмент-кластера" class="toc-header"><a class="toc-anchor" href="#подготовка-менеджмент-кластера">¶</a> Подготовка менеджмент-кластера</h2>\n<p>Cluster API всегда разворачивается из управляющего (management) кластера. Этот кластер нужен только для того, чтобы развернуть и управлять workload-кластерами. Сам он в продакшене не участвует, поэтому его можно поднять локально — на ноутбуке, рабочей станции или в отдельной VM.</p>\n<p>Вариантов запуска менеджмент-кластера несколько:</p>\n<ul>\n<li><strong>Minikube</strong> — удобно для быстрого старта, но ограничено одной нодой.</li>\n<li><strong>kind</strong> — Kubernetes в Docker-контейнерах, простой и быстрый способ, подходит для локальной разработки.</li>\n<li><strong>k3s / rke2</strong> — лёгкий Kubernetes с упрощённой установкой, можно развернуть в VM или LXC.</li>\n<li><strong>kubeadm</strong> — классический способ, если хочется руками поднять «настоящий» кластер</li>\n</ul>\n<p>Я выбрал kind, потому что:</p>\n<ul>\n<li>не требует установки виртуализации или отдельных VM</li>\n<li>быстро создаётся и удаляется</li>\n<li>удобно использовать для тестов и работы с Cluster API</li>\n</ul>\n<h3 id="установка-kind" class="toc-header"><a class="toc-anchor" href="#установка-kind">¶</a> Установка kind</h3>\n<p>На ноутбуке (macOS):</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-"># For M1 / ARM Macs\n[ $(uname -m) = arm64 ] &amp;&amp; curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.30.0/kind-darwin-arm64\nchmod +x ./kind\nmv ./kind /some-dir-in-your-PATH/kind\n\n# проверка\nkind --version\n</code></pre>\n<p>Для других архитектур и систем можно посмотреть в официальной <a href="https://kind.sigs.k8s.io/docs/user/quick-start/" class="is-external-link">документации</a></p>\n<p>Ещё потребуется kubectl:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/$(uname | tr '[:upper:]' '[:lower:]')/arm64/kubectl"\nchmod +x kubectl\nsudo mv kubectl /usr/local/bin/\n</code></pre>\n<h3 id="создание-кластера" class="toc-header"><a class="toc-anchor" href="#создание-кластера">¶</a> Создание кластера</h3>\n<p>Создадим конфиг kind-config.yaml:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">kind: Cluster\napiVersion: kind.x-k8s.io/v1alpha4\nname: capi-mgmt\nnodes:\n  - role: control-plane\n</code></pre>\n<p>Поднимаем кластер:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">kind create cluster --config kind-config.yaml\n</code></pre>\n<p>Проверяем:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">kubectl cluster-info\nkubectl get nodes\n</code></pre>\n<p><img src="https://drive.google.com/file/d/19YhpVB_wd9RpMzgWsLVNN58HkcK6252W/view?usp=sharing" alt=""></p>\n<p>Cluster API распространяется как набор контроллеров, которые устанавливаются в менеджмент-кластер и управляют жизненным циклом Kubernetes-кластеров. Для работы нам нужен инструмент <strong>clusterctl</strong>.</p>\n<p>Установка clusterctl</p>\n<p>Скачаем бинарник (здесь и далее я буду приводить примеры для MacOS, для других OS ссылки можно взять в официальной документации):</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">curl -L https://github.com/kubernetes-sigs/cluster-api/releases/download/v1.11.0/clusterctl-darwin-arm64 -o clusterctl\n\n#права на запуск \nchmod +x ./clusterctl\n\n#переместим в локальную директорию для  бинарей\nsudo mv ./clusterctl /usr/local/bin/clusterctl\n\n#проверка \nclusterctl version\n</code></pre>\n<h3 id="подготовим-настройки-для-инициализации-clusterapi" class="toc-header"><a class="toc-anchor" href="#подготовим-настройки-для-инициализации-clusterapi">¶</a> Подготовим настройки для инициализации ClusterAPI</h3>\n<p>Нужно создать выделенный токен для Proxmox user, это можно сделать в веб-интерфейсе или зайти на ноду Proxmox по ssh и дать команды:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">pveum user add capmox@pve\npveum aclmod / -user capmox@pve -role PVEVMAdmin\npveum user token add capmox@pve capi -privsep 0\n</code></pre>\n<p>Полученный токен нужно записать  в следующий файл ~/.cluster-api/clusterctl.yaml. В текущей директории пользователя нужно создать:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">mkdir ~/.cluster-api\n</code></pre>\n<p>Example ~/.cluster-api/clusterctl.yaml</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">## -- Controller settings -- ##\nPROXMOX_URL: "https://192.168.1.11:8006"                       # The Proxmox VE host\nPROXMOX_TOKEN: "capmox@pve!capi"                                # The Proxmox VE TokenID for authentication\nPROXMOX_SECRET: "***********"                                    # Сюда пишем полученный токен\n\n\n## -- Required workload cluster default settings -- ##\nPROXMOX_SOURCENODE: "pimox2"                                     # Узел на котором размещен шаблон ВМ \nTEMPLATE_VMID: "5002"                                          # ID шаблона для клонирования\nALLOWED_NODES: "[pimox2]"                        # Узлы для развертывания ВМ, в моем случае один\nVM_SSH_KEYS: "ssh-ed25519 ..., ssh-ed25519 ..."               # The ssh authorized keys used to ssh to the machines.\n\n## -- networking configuration-- ##\nCONTROL_PLANE_ENDPOINT_IP: "192.168.1.30"                       # The IP that kube-vip is going to use as a control plane endpoint\nNODE_IP_RANGES: "[192.168.1.31-192.168.1.39]"               # The IP ranges for Cluster nodes\nGATEWAY: "192.168.1.1"                                         # The gateway for the machines network-config.\nIP_PREFIX: "24"                                               # Subnet Mask in CIDR notation for your node IP ranges\nDNS_SERVERS: "[8.8.8.8,8.8.4.4]"                              # The dns nameservers for the machines network-config.\nBRIDGE: "vmbr1"                                               # The network bridge device for Proxmox VE VMs\n\n## -- xl nodes -- ##\nBOOT_VOLUME_DEVICE: "scsi0"                                   # The device used for the boot disk.\nBOOT_VOLUME_SIZE: "30"                                       # The size of the boot disk in GB.\nNUM_SOCKETS: "2"                                              # The number of sockets for the VMs.\nNUM_CORES: "2"                                                # The number of cores for the VMs.\nMEMORY_MIB: "4096"                                            # The memory size for the VMs.\n\nEXP_CLUSTER_RESOURCE_SET: "true"                              # This enables the ClusterResourceSet feature that we are using to deploy CNI\nCLUSTER_TOPOLOGY: "true"                                      # This enables experimental ClusterClass templating\n</code></pre>\n<p>Тут я привел свои настройки, по комментариям думаю все понятно.</p>\n<p>Дальше нам нужно проинициализировать Cluster API в менеджмент кластер, после подготовки всех настроек нужно выполнить команду:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">clusterctl init --infrastructure proxmox --ipam in-cluster\n</code></pre>\n<hr>\n<p>Сейчас пройдемся по параметрам инициализации. Для чего нужен <code>--ipam in-cluster</code> я не описал его в начале статьи со всеми провайдерами. И так, IPAM (IP Address Management) провайдер отвечает за управление IP-адресами машин в кластере. Он особенно полезен для non-cloud развертываний, таких как Proxmox или bare metal.</p>\n<p><strong>Зачем это нужно:</strong></p>\n<ul>\n<li><strong>Автоматическое выделение IP</strong> — не нужно вручную указывать адреса для каждой VM</li>\n<li><strong>Управление пулами адресов</strong> — можете создать диапазоны IP для разных кластеров</li>\n<li><strong>Предотвращение конфликтов</strong> — система следит, чтобы адреса не пересекались</li>\n<li><strong>Декларативность</strong> — IP-адреса управляются через Kubernetes ресурсы</li>\n</ul>\n<p><strong>Альтернатива без IPAM:</strong> Придется вручную прописывать IP-адреса в каждом манифесте Machine.</p>\n<h2 id="все-параметры-clusterctl-init" class="toc-header"><a class="toc-anchor" href="#все-параметры-clusterctl-init">¶</a> Все параметры <code>clusterctl init</code></h2>\n<h3 id="основной-синтаксис" class="toc-header"><a class="toc-anchor" href="#основной-синтаксис">¶</a> Основной синтаксис:</h3>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">clusterctl init [flags] [provider1] [provider2] ...\n</code></pre>\n<h3 id="основные-флаги" class="toc-header"><a class="toc-anchor" href="#основные-флаги">¶</a> Основные флаги:</h3>\n<div class="table-container"><table>\n<thead>\n<tr>\n<th>Параметр</th>\n<th>Описание</th>\n<th>Пример</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td><code>--core</code></td>\n<td>Версия core провайдера</td>\n<td><code>--core cluster-api:v1.6.1</code></td>\n</tr>\n<tr>\n<td><code>--infrastructure</code></td>\n<td>Infrastructure провайдер</td>\n<td><code>--infrastructure proxmox</code></td>\n</tr>\n<tr>\n<td><code>--bootstrap</code></td>\n<td>Bootstrap провайдер</td>\n<td><code>--bootstrap kubeadm:v1.6.1</code></td>\n</tr>\n<tr>\n<td><code>--control-plane</code></td>\n<td>Control plane провайдер</td>\n<td><code>--control-plane kubeadm:v1.6.1</code></td>\n</tr>\n<tr>\n<td><code>--addon</code></td>\n<td>Addon провайдер</td>\n<td><code>--addon helm</code></td>\n</tr>\n<tr>\n<td><code>--ipam</code></td>\n<td>IPAM провайдер</td>\n<td><code>--ipam in-cluster</code></td>\n</tr>\n</tbody>\n</table></div>\n<h3 id="дополнительные-флаги" class="toc-header"><a class="toc-anchor" href="#дополнительные-флаги">¶</a> Дополнительные флаги:</h3>\n<div class="table-container"><table>\n<thead>\n<tr>\n<th>Параметр</th>\n<th>Описание</th>\n<th>Пример</th>\n</tr>\n</thead>\n<tbody>\n<tr>\n<td><code>--target-namespace</code></td>\n<td>Namespace для установки</td>\n<td><code>--target-namespace capi-system</code></td>\n</tr>\n<tr>\n<td><code>--watching-namespace</code></td>\n<td>Namespace для мониторинга</td>\n<td><code>--watching-namespace ""</code> (все)</td>\n</tr>\n<tr>\n<td><code>--config</code></td>\n<td>Путь к файлу конфигурации</td>\n<td><code>--config ~/.cluster-api/clusterctl.yaml</code></td>\n</tr>\n<tr>\n<td><code>--wait-providers</code></td>\n<td>Ждать готовности провайдеров</td>\n<td><code>--wait-providers</code></td>\n</tr>\n<tr>\n<td><code>--wait-provider-timeout</code></td>\n<td>Таймаут ожидания</td>\n<td><code>--wait-provider-timeout 5m</code></td>\n</tr>\n</tbody>\n</table></div>\n<h3 id="примеры-использования" class="toc-header"><a class="toc-anchor" href="#примеры-использования">¶</a> Примеры использования:</h3>\n<h4 id="полная-установка-с-версиями" class="toc-header"><a class="toc-anchor" href="#полная-установка-с-версиями">¶</a> Полная установка с версиями:</h4>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">clusterctl init \\\n  --core cluster-api:v1.6.1 \\\n  --bootstrap kubeadm:v1.6.1 \\\n  --control-plane kubeadm:v1.6.1 \\\n  --infrastructure proxmox:v0.5.0 \\\n  --ipam in-cluster\n</code></pre>\n<h4 id="установка-в-custom-namespace" class="toc-header"><a class="toc-anchor" href="#установка-в-custom-namespace">¶</a> Установка в custom namespace:</h4>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">clusterctl init \\\n  --infrastructure aws \\\n  --target-namespace custom-capi-system\n</code></pre>\n<h2 id="автоматические-провайдеры" class="toc-header"><a class="toc-anchor" href="#автоматические-провайдеры">¶</a> Автоматические провайдеры</h2>\n<p>clusterctl автоматически добавляет cluster-api core провайдер, kubeadm bootstrap провайдер и kubeadm control-plane провайдер, если они не указаны явно.</p>\n<p><strong>Это означает, что команда:</strong></p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">clusterctl init --infrastructure proxmox\n</code></pre>\n<p><strong>Эквивалентна:</strong></p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">clusterctl init \\\n  --core cluster-api \\\n  --bootstrap kubeadm \\\n  --control-plane kubeadm \\\n  --infrastructure proxmox\n</code></pre>\n<hr>\n<p>И так после выполнения команды <code>clusterctl init --infrastructure proxmox --ipam in-cluster</code> мы получили:<br>\n<img src="%22https://drive.google.com/file/d/1E14RjME2bJVS0zHZzLwb4QCd8ajNQJrx/view?usp=share_link%22" alt=""><br>\nНе много подождав можно проверить запущенные провайдеры<br>\n<img src="%22https://drive.google.com/file/d/1kcA1tFql-ZTKuGWVUrlCRdfJMW3rGrKE/view?usp=sharing%22" alt=""></p>\n<p>Management кластер теперь готов создавать и управлять Kubernetes кластерами на Proxmox инфраструктуре. Достаточно применить нужные манифесты — и система автоматически развернет новый кластер. Теперь сгенерируем манифесты или можно написать с нуля:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">clusterctl generate cluster myproxmoxcluster \\\n    --infrastructure proxmox \\\n    --kubernetes-version v1.32.0 \\\n    --control-plane-machine-count 1 \\\n    --worker-machine-count 1 &gt; cluster.yaml\n</code></pre>\n<p>Содержимое моего файла <a href="https://github.com/filatof/example-cluster.yaml.git" class="is-external-link">cluster.yaml</a></p>\n<p>Кластер конфигурируется с одной control-plane и одной worker нодой, но можно легко изменить количество в манифестах через параметры <code>replicas</code> в соответствующих ресурсах.</p>\n<p>Запускаем создание кластера:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">kubectl apply -f cluster.yaml\n</code></pre>\n<blockquote>\n<p>На этом этапе я получил первую проблему, которую долго не мог решить, и уже думал закончить эксперименты с ClusterAPI ))) Но нашел решение, в исходнике поменял значение константы и пересобрал Dockerfile. Я сделал <a href="https://github.com/ionos-cloud/cluster-api-provider-proxmox/issues/523#issue-3274555314" class="is-external-link">issues</a> в репозиторий разработчика, с просьбой поправить этот момент и сделать настраиваемый выбор шины, но ответа так и не получил. На днях у них вышла новая версия 0.7.4 и метод с исправлением константы не работает, я написал еще <a href="https://github.com/ionos-cloud/cluster-api-provider-proxmox/issues/548#issue-3369940126" class="is-external-link">issues</a>. Так что пока можно использовать версию 0.7.3</p>\n</blockquote>\n<p>При создании VM получаем ошибку:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">Bus 'ide.0' not found\nTASK ERROR: start failed: QEMU exited with code 1\n</code></pre>\n<p><strong>Корень проблемы:</strong><br>\nProxmox Provider захардкодил в коде использование <code>ide0</code> шины для cloud-init ISO, но ARM64 архитектура в Proxmox <strong>не поддерживает IDE шины</strong>. Даже если в template VM настроена SCSI шина, провайдер принудительно пытается создать IDE устройство.</p>\n<h3 id="решение-проблемы" class="toc-header"><a class="toc-anchor" href="#решение-проблемы">¶</a> Решение проблемы</h3>\n<p>Можно пересобрать <code>dockerfile</code> или взять мой готовый образ <code>docker pull filatof/capmox:v0.7.3</code></p>\n<p><strong>Шаг 1:</strong> Клонируем репозиторий провайдера</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">git clone https://github.com/ionos-cloud/cluster-api-provider-proxmox.git\ncd cluster-api-provider-proxmox\n</code></pre>\n<p><strong>Шаг 2:</strong> Правим константу в исходном коде, файл internal/inject/inject.go</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-go">// Файл: internal/inject/inject.go\n// Было:\nconst CloudInitISODevice = "ide0"\n\n// Стало:\nconst CloudInitISODevice = "scsi1"\n</code></pre>\n<p><strong>Шаг 3:</strong> Пересобираем Docker образ</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash"># Сборка для ARM64\ndocker build --platform linux/arm64 -t filatof/capmox:v0.7.3 .\n\n# Или если собираете на x86_64 для ARM64\ndocker buildx build --platform linux/arm64 -t filatof/capmox:v0.7.3 .\n</code></pre>\n<p><strong>Шаг 4:</strong> Обновляем деплоймент провайдера</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">kubectl patch deployment capmox-controller-manager \\\n  -n capmox-system \\\n  -p '{"spec":{"template":{"spec":{"containers":[{"name":"manager","image":"filatof/capmox:v0.7.3"}]}}}}'\n</code></pre>\n<h3 id="важные-моменты" class="toc-header"><a class="toc-anchor" href="#важные-моменты">¶</a> Важные моменты:</h3>\n<p><strong>Почему именно <code>scsi1</code>:</strong></p>\n<ul>\n<li><code>scsi0</code> обычно занят основным диском VM</li>\n<li><code>scsi1</code> безопасный выбор для cloud-init ISO</li>\n<li><code>scsi</code> шина полностью поддерживается на ARM64</li>\n</ul>\n<p>Поправили образ Proxmox провайдера, и теперь  можно запускать создание кластера:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">kubectl apply -f cluster.yaml\n</code></pre>\n<p>ВМ не создаются, получаю следующую ошибку:<br>\n<img src="%22https://drive.google.com/file/d/1eZu6kpCGYZsios9UZY3DfJohPcByktoa/view?usp=sharing%22" alt=""></p>\n<p>Посмотрим так:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">kubectl describe machine myproxmoxcluster-control-plane-qt52f\n</code></pre>\n<p>Ошибка <code>InsufficientResources</code> говорит, что провайдер не смог выделить для VM память, указанную в манифесте.</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">cannot reserve 2147483648B of memory on node pimox2: 0B available memory left\n</code></pre>\n<ul>\n<li>2147483648B = 2 ГБ — именно столько просит ProxmoxMachine для запуска ноды.</li>\n<li>0B available memory left — провайдер думает, что на узле нет свободной памяти.</li>\n</ul>\n<p>Поэтому ресурс ProxmoxMachine уходит в статус Failed с причиной InsufficientResources.</p>\n<p><strong>Решение</strong><br>\nДобавить параметр <code>schedulerHints</code> в манифест:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">apiVersion: infrastructure.cluster.x-k8s.io/v1alpha1\nkind: ProxmoxCluster\nmetadata:\n  name: myproxmoxcluster\n  namespace: default\nspec:\n  schedulerHints:\n    memoryAdjustment: 0\n</code></pre>\n<p>В спецификации ProxmoxCluster есть параметр</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">schedulerHints:\n    memoryAdjustment: 0\n</code></pre>\n<p>Он определяет, как CAPMox учитывает доступную память на узле при запуске новых виртуальных машин.</p>\n<ul>\n<li>Положительное значение (memoryAdjustment: 512)<br>\nПровайдер зарезервирует дополнительно 512 МБ. Это полезно, если вы хотите оставить запас памяти для самого Proxmox и сервисов на хосте.</li>\n<li>Ноль (memoryAdjustment: 0)<br>\nПланировщик будет использовать всю доступную память. В этом случае узел максимально загружается, но есть риск, что Proxmox останется без резерва.</li>\n<li>Отрицательное значение (memoryAdjustment: -512)<br>\n«Обман» планировщика: он будет считать, что на узле есть больше памяти, чем реально. Можно использовать только для тестов, так как велик риск падения нод из-за OOM.</li>\n</ul>\n<p>На ARM-платформах (Orange Pi, Raspberry Pi) часто встречается ситуация, когда CAPMox ошибочно считает, что на узле нет свободной памяти (0B available). В таких случаях установка:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">schedulerHints:\n  memoryAdjustment: 0\n</code></pre>\n<p>позволяет обойти проверку и успешно создавать кластеры.<br>\nЗапускаем создание кластера:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-bash">kubectl apply -f cluster.yaml\n</code></pre>\n<p>И получаю запущенные ВМ:<br>\n<img src="%22https://drive.google.com/file/d/18pAfF5hB0Xsj7ezW-ZOVZNI8ZaIj9USS/view?usp=sharing%22" alt=""></p>\n<p>Теперь нужно получить <code>kubeconfig</code> для управления воркер кластером, выполним команду:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">clusterctl get kubeconfig myproxmoxcluster &gt; kubeconfig\n</code></pre>\n<p>Чтобы посмотреть запущенные поды кластера выполним команду:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">KUBECONFIG=kubeconfig kubectl get pod -A\n</code></pre>\n<p><img src="%22https://drive.google.com/file/d/1TKQhw_jp-EV4C_uYeFHxahFXOAmn9jbP/view?usp=sharing%22" alt=""></p>\n<p>Кластер совсем пустой. Ноды еще не перешли в готовность, потому-то не установлено CNI</p>\n<p><img src="%22https://drive.google.com/file/d/1MnexIjaB81JjUvbH6lBIZ_PEih6zMqyt/view?usp=sharing%22" alt=""></p>\n<p>Установим calico, выполним команду:</p>\n<pre class="prismjs line-numbers" v-pre="true"><code class="language-">KUBECONFIG=kubeconfig kubectl apply -f https://docs.projectcalico.org/manifests/calico.yaml\n</code></pre>\n<p>Не много подождем пока скачаются образы и запустятся поды. В итоге получаем рабочий кластер<br>\n<img src="%22https://drive.google.com/file/d/1cy0AmXK15D8c4-9mtqz7F44MhhcBccl0/view?usp=sharing%22" alt=""></p>\n<h2 id="вывод" class="toc-header"><a class="toc-anchor" href="#вывод">¶</a> Вывод</h2>\n<p><strong>Что получилось:</strong><br>\nВ результате всех экспериментов мы создали полноценную  платформу для автоматического развертывания Kubernetes-кластеров на ARM64 архитектуре. Orange Pi 5 Plus  база для домашней лаборатории — его производительности достаточно для одновременной работы Management кластера и нескольких Workload кластеров.</p>\n<p><strong>Экономия ресурсов:</strong><br>\nCluster API кардинально меняет подход к управлению инфраструктурой. То, что раньше требовало многочасовой ручной работы и высокой вероятности ошибок, теперь выполняется за 5-10 минут одной командой <code>kubectl apply</code>. Декларативный подход превращает инфраструктуру в код — версионируемый, воспроизводимый и предсказуемый.</p>\n<p><strong>ARM64 как платформа:</strong><br>\nСвязка ARM64 + Proxmox + Cluster API оказалась не только работоспособной, но и практичной для реальных задач. Энергоэффективность, доступность железа  делают ARM64 серьезной альтернативой x86_64 для  домашних лабораторий.</p>\n<p><strong>Практическая ценность:</strong><br>\nТеперь у нас есть foundation для более сложных сценариев — управление множественными кластерами, быстрое восстановление после сбоев, и полноценного GitOps workflow.</p>\n<hr>\n<p>В следующей статье покажу, как сделать процесс развертывания кластера еще проще:</p>\n<ul>\n<li>CNI (Cilium, Calico) устанавливается автоматически вместе с кластером</li>\n<li>Управление кластерами через Git с помощью FluxCD</li>\n<li>Создание кластеров простым commit'ом в репозиторий</li>\n</ul>\n	[{"title":"Как компоненты взаимодействуют","anchor":"#как-компоненты-взаимодействуют","children":[{"title":"Процесс создания кластера","anchor":"#процесс-создания-кластера","children":[]},{"title":"Схема взаимодействия","anchor":"#схема-взаимодействия","children":[]},{"title":"Жизненный цикл ресурсов","anchor":"#жизненный-цикл-ресурсов","children":[{"title":"Cluster (Кластер)","anchor":"#cluster-кластер","children":[]},{"title":"Machine (Машина)","anchor":"#machine-машина","children":[]},{"title":"MachineDeployment (Развертывание машин)","anchor":"#machinedeployment-развертывание-машин","children":[]}]},{"title":"Важные особенности","anchor":"#важные-особенности","children":[]},{"title":"Начало установки","anchor":"#начало-установки","children":[{"title":"Исходное состояние","anchor":"#исходное-состояние","children":[]}]},{"title":"Подготовка менеджмент-кластера","anchor":"#подготовка-менеджмент-кластера","children":[{"title":"Установка kind","anchor":"#установка-kind","children":[]},{"title":"Создание кластера","anchor":"#создание-кластера","children":[]},{"title":"Подготовим настройки для инициализации ClusterAPI","anchor":"#подготовим-настройки-для-инициализации-clusterapi","children":[]}]},{"title":"Все параметры clusterctl init","anchor":"#все-параметры-clusterctl-init","children":[{"title":"Основной синтаксис:","anchor":"#основной-синтаксис","children":[]},{"title":"Основные флаги:","anchor":"#основные-флаги","children":[]},{"title":"Дополнительные флаги:","anchor":"#дополнительные-флаги","children":[]},{"title":"Примеры использования:","anchor":"#примеры-использования","children":[{"title":"Полная установка с версиями:","anchor":"#полная-установка-с-версиями","children":[]},{"title":"Установка в custom namespace:","anchor":"#установка-в-custom-namespace","children":[]}]}]},{"title":"Автоматические провайдеры","anchor":"#автоматические-провайдеры","children":[{"title":"Решение проблемы","anchor":"#решение-проблемы","children":[]},{"title":"Важные моменты:","anchor":"#важные-моменты","children":[]}]},{"title":"Вывод","anchor":"#вывод","children":[]}]}]	markdown	2026-03-20T17:21:11.898Z	2026-03-20T17:21:13.252Z	markdown	ru	1	1	{"js":"","css":""}
\.


--
-- Data for Name: renderers; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.renderers (key, "isEnabled", config) FROM stdin;
asciidocCore	t	{"safeMode":"server"}
htmlAsciinema	f	{}
htmlBlockquotes	t	{}
htmlCodehighlighter	t	{}
htmlCore	t	{"absoluteLinks":false,"openExternalLinkNewTab":false,"relAttributeExternalLink":"noreferrer"}
htmlDiagram	t	{}
htmlImagePrefetch	f	{}
htmlMediaplayers	t	{}
htmlMermaid	t	{}
htmlSecurity	t	{"safeHTML":true,"allowDrawIoUnsafe":true,"allowIFrames":false}
htmlTabset	t	{}
htmlTwemoji	t	{}
markdownAbbr	t	{}
markdownCore	t	{"allowHTML":true,"linkify":true,"linebreaks":true,"underline":false,"typographer":false,"quotes":"English"}
markdownEmoji	t	{}
markdownExpandtabs	t	{"tabWidth":4}
markdownFootnotes	t	{}
markdownImsize	t	{}
markdownKatex	t	{"useInline":true,"useBlocks":true}
markdownKroki	f	{"server":"https://kroki.io","openMarker":"```kroki","closeMarker":"```"}
markdownMathjax	f	{"useInline":true,"useBlocks":true}
markdownMultiTable	f	{"multilineEnabled":true,"headerlessEnabled":true,"rowspanEnabled":true}
markdownPivotTable	f	{}
markdownPlantuml	t	{"server":"https://plantuml.requarks.io","openMarker":"```plantuml","closeMarker":"```","imageFormat":"svg"}
markdownSupsub	t	{"subEnabled":true,"supEnabled":true}
markdownTasklists	t	{}
openapiCore	t	{}
\.


--
-- Data for Name: searchEngines; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."searchEngines" (key, "isEnabled", config) FROM stdin;
algolia	f	{"appId":"","apiKey":"","indexName":"wiki"}
aws	f	{"domain":"","endpoint":"","region":"us-east-1","accessKeyId":"","secretAccessKey":"","AnalysisSchemeLang":"en"}
azure	f	{"serviceName":"","adminKey":"","indexName":"wiki"}
db	t	{}
elasticsearch	f	{"apiVersion":"7.x","hosts":"","verifyTLSCertificate":true,"tlsCertPath":"","indexName":"wiki","analyzer":"simple","sniffOnStart":false,"sniffInterval":0}
manticore	f	{}
postgres	f	{"dictLanguage":"english"}
solr	f	{"host":"solr","port":8983,"core":"wiki","protocol":"http"}
sphinx	f	{}
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.sessions (sid, sess, expired) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.settings (key, value, "updatedAt") FROM stdin;
auth	{"audience":"urn:wiki.js","tokenExpiration":"30m","tokenRenewal":"14d"}	2026-03-20T16:26:33.945Z
certs	{"jwk":{"kty":"RSA","n":"2FmiLTt6qCamtE78-ZCeArQ_zP2jPCHDkiOdNAI0gZKkSXLJJJShw89ywJorRHsFQULN0YGCaFN4XjH80CuXBEuG5yXZGjQjHnpAa2bje7WRVRWetMb9vpePw40WxWrynZRoI4p4pGbk1txebrRLWhrN1btnpgJit1S1VsZidIi8YEjSRLPoviUSEeHFIZ2nPAPHJOjMtLwOmxdBxXQxwFnxO4NEchWlPkc8-ejJqHM2z_MkcjaYzXJBWieHfY6wfvgs3HfNyOIsuFGl30-PHJEtZh1mO0Kk_3SoNz3WJaSl5L5NMBpgneCF7VEga_2mJK7sFWKhmy_j6QudOBMqAQ","e":"AQAB"},"public":"-----BEGIN RSA PUBLIC KEY-----\\nMIIBCgKCAQEA2FmiLTt6qCamtE78+ZCeArQ/zP2jPCHDkiOdNAI0gZKkSXLJJJSh\\nw89ywJorRHsFQULN0YGCaFN4XjH80CuXBEuG5yXZGjQjHnpAa2bje7WRVRWetMb9\\nvpePw40WxWrynZRoI4p4pGbk1txebrRLWhrN1btnpgJit1S1VsZidIi8YEjSRLPo\\nviUSEeHFIZ2nPAPHJOjMtLwOmxdBxXQxwFnxO4NEchWlPkc8+ejJqHM2z/MkcjaY\\nzXJBWieHfY6wfvgs3HfNyOIsuFGl30+PHJEtZh1mO0Kk/3SoNz3WJaSl5L5NMBpg\\nneCF7VEga/2mJK7sFWKhmy/j6QudOBMqAQIDAQAB\\n-----END RSA PUBLIC KEY-----\\n","private":"-----BEGIN RSA PRIVATE KEY-----\\nProc-Type: 4,ENCRYPTED\\nDEK-Info: AES-256-CBC,D91E976BCCD08FCB95491803FB64EE41\\n\\nG+7G73bcQWkKIa46+LsG+RMhOp3Yt/665+E6to1ebpZamOaqVDT03zcw9nOUKBu7\\nX3dJy15yCqNdI4sXFl759EPGcqdloUcw8K8cyQ8yAVnRPyr1t/nu7KweY6XA1AfI\\ngctiZju09Iqfd6c6de1L9aAbnt4FYcjJ+jQABkmP7hYxAeTlJCaJJg28mCFqurof\\n/UThd9Iy+EVodyEgNKtUWQWS7TP5nr/Cl9QcBmOW/rx1V7TsGz6l6Bv0E7ztQZbs\\nl96UtqI92DAzDKojuAsSNOPtZDLu1WbrRI3fCs1Xv/LXtrpp0caADlKGm/69HjXB\\n2n2TLRjRnuEe2soaIYsS6a1ySF7eWR9Ur1rh34wnQL1AZUfIFpMK7k5A++GJvurc\\n2X2g1n/+kSGyiWHWZVIFxp5bTYEM3nhBbqafQUVV9jPFt+1c+D1dWFqm0mX1aBAs\\nMQVaPKik4E4YBVOnzrPVraSdatFd2vEcdS279m0MoIGJEgHBiyNgPWaSo76HRSQZ\\n6l7Zi4EyAadeUIVWz3jDCukhTa7S4Awo6erS5i7UjyAxnwZCwLlxalKw9wqP+R85\\ngbzvDXbJ1bGwDCT0NGQ7udl3o6ntiXtlb4xumsvas49chDiSSNrfd1lohnzkKy1z\\n1f+ghhgpaUabvZs91Y3n47wjZiqIkwwCVZFICHXwVZeQMkQdexH+OlkaTBOJWeZ9\\nmMQRA9Y9zsbyhWrW5SEEOUcHVyEjtV23x9Zuk4J8ExpJBjGdA1Nuoed6q2+8umM0\\nEveFEVHpQJtKlL5EkrcRLGE+bFlNJQrQOnyg5Wxu+79UmFTNlQTxxrpudkG0f31l\\n88akMJ11XgYB+EGnXJf0S/hzdIXeYgAipiRhj8foxiUCU29nbbZaKzRoyI67TQg4\\nndR1aw6zdxXdKm448Xo9St9cm0m81fFzil56E4nRGCi4TNxkgV3xC/rfjsc7Fh1m\\n2MEnIcbF8Kp2a/ZdxGJXKp5XVo2rAVBXcH4YO6vvubxm5rStDJ7bJxv2fkph24jD\\nLzpvwhksfW3ew8MP7duvexWB6r06VLAxNINnztB+2ddVmMyKzrIvtNdO0zE01Rtz\\nbeV+bfx9GrESc+6jls4Tn8T1DDHttEigwNLJpMaHXvMEdKoU0kFEMAbG6HAybJ2E\\nEFNTTQ/BJWq+/+Sx9uND+vx6GVg6bHFwQyF+di+NdLSf7KHNVgW62v9CxX7MTbuJ\\ngHMJTXcwiEf3HSnYe/ZQwf2c5zzV9AD+FGWFO4bIwl0Xv4bm32x0neI2dPBjX27o\\nHcd2H9J5gVjhleCkvG5Fte7wbx78TBf0/aRoVoK4L5L8AqqbJMRY/7hpONHmdmpl\\niA0tOGZyephnbtEam3mNBHjY70MCiHwmzhAJL0AAOAUVvNDSVOsTRRRTnzOS4wU+\\nDlvsEkYoLCVJNN/TwbK27D8WIaRnMYBOpb1lkkirH+97nPxMQ9PcrG8RzcSsKed+\\nuVqBliA7IWLAIcEmVAJxopsx1lK5ojr4rU3UFgoJBRbB89V0o/zTyLf79Ke0PiqA\\nskmZUDhqlvBnHPxHfGCAAUGytm6e0SwwrApDj46LuNuYZL8SXs3so5nJWcS7jPy3\\n-----END RSA PRIVATE KEY-----\\n"}	2026-03-20T16:26:33.954Z
company	{"v":""}	2026-03-20T16:26:33.958Z
features	{"featurePageRatings":true,"featurePageComments":true,"featurePersonalWikis":true}	2026-03-20T16:26:33.962Z
graphEndpoint	{"v":"https://graph.requarks.io"}	2026-03-20T16:26:33.965Z
host	{"v":"https://wiki.eqlan.ru"}	2026-03-20T16:26:33.968Z
logo	{"hasLogo":false,"logoIsSquare":false}	2026-03-20T16:26:33.976Z
mail	{"senderName":"","senderEmail":"","host":"","port":465,"name":"","secure":true,"verifySSL":true,"user":"","pass":"","useDKIM":false,"dkimDomainName":"","dkimKeySelector":"","dkimPrivateKey":""}	2026-03-20T16:26:33.979Z
seo	{"description":"","robots":["index","follow"],"analyticsService":"","analyticsId":""}	2026-03-20T16:26:33.985Z
sessionSecret	{"v":"ba99986a0f7909369d5b58f16137d16615682ce87612803d09e0e5114e508181"}	2026-03-20T16:26:33.988Z
telemetry	{"isEnabled":true,"clientId":"900ba8da-3de7-4032-8efd-a8a21f41914c"}	2026-03-20T16:26:33.991Z
uploads	{"maxFileSize":5242880,"maxFiles":10,"scanSVG":true,"forceDownload":true}	2026-03-20T16:26:33.997Z
title	{"v":"Wiki.js"}	2026-03-20T16:26:34.000Z
lang	{"code":"ru","autoUpdate":true,"namespacing":false,"namespaces":["ru"],"rtl":false}	2026-03-20T16:30:00.852Z
theming	{"theme":"default","darkMode":false,"iconset":"fa","injectCSS":"","injectHead":"","injectBody":"","tocPosition":"left"}	2026-03-20T17:09:51.479Z
\.


--
-- Data for Name: storage; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.storage (key, "isEnabled", mode, config, "syncInterval", state) FROM stdin;
azure	f	push	{"accountName":"","accountKey":"","containerName":"wiki","storageTier":"Cool"}	P0D	{"status":"pending","message":"","lastAttempt":null}
box	f	push	{"clientId":"","clientSecret":"","rootFolder":""}	P0D	{"status":"pending","message":"","lastAttempt":null}
digitalocean	f	push	{"endpoint":"nyc3.digitaloceanspaces.com","bucket":"","accessKeyId":"","secretAccessKey":""}	P0D	{"status":"pending","message":"","lastAttempt":null}
disk	f	push	{"path":"","createDailyBackups":false}	P0D	{"status":"pending","message":"","lastAttempt":null}
dropbox	f	push	{"appKey":"","appSecret":""}	P0D	{"status":"pending","message":"","lastAttempt":null}
gdrive	f	push	{"clientId":"","clientSecret":""}	P0D	{"status":"pending","message":"","lastAttempt":null}
git	f	sync	{"authType":"ssh","repoUrl":"","branch":"master","sshPrivateKeyMode":"path","sshPrivateKeyPath":"","sshPrivateKeyContent":"","verifySSL":true,"basicUsername":"","basicPassword":"","defaultEmail":"name@company.com","defaultName":"John Smith","localRepoPath":"./data/repo","alwaysNamespace":false,"gitBinaryPath":""}	PT5M	{"status":"pending","message":"","lastAttempt":null}
onedrive	f	push	{"clientId":"","clientSecret":""}	P0D	{"status":"pending","message":"","lastAttempt":null}
s3	f	push	{"region":"","bucket":"","accessKeyId":"","secretAccessKey":""}	P0D	{"status":"pending","message":"","lastAttempt":null}
s3generic	f	push	{"endpoint":"https://service.region.example.com","bucket":"","accessKeyId":"","secretAccessKey":"","sslEnabled":true,"s3ForcePathStyle":false,"s3BucketEndpoint":false}	P0D	{"status":"pending","message":"","lastAttempt":null}
sftp	f	push	{"host":"","port":22,"authMode":"privateKey","username":"","privateKey":"","passphrase":"","password":"","basePath":"/root/wiki"}	P0D	{"status":"pending","message":"","lastAttempt":null}
\.


--
-- Data for Name: tags; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.tags (id, tag, title, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: userAvatars; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."userAvatars" (id, data) FROM stdin;
\.


--
-- Data for Name: userGroups; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."userGroups" (id, "userId", "groupId") FROM stdin;
1	1	1
2	2	2
\.


--
-- Data for Name: userKeys; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public."userKeys" (id, kind, token, "createdAt", "validUntil", "userId") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: wiki
--

COPY public.users (id, email, name, "providerId", password, "tfaIsActive", "tfaSecret", "jobTitle", location, "pictureUrl", timezone, "isSystem", "isActive", "isVerified", "mustChangePwd", "createdAt", "updatedAt", "providerKey", "localeCode", "defaultEditor", "lastLoginAt", "dateFormat", appearance) FROM stdin;
2	guest@example.com	Guest	\N		f	\N			\N	America/New_York	t	t	t	f	2026-03-20T16:26:34.436Z	2026-03-20T16:26:34.436Z	local	en	markdown	\N		
1	keeper-8.sip@icloud.com	Administrator	\N	$2a$12$ZNk0um3MGszM3I2Htf17qOmkKDhQoQ9hwTKmO2/r.ko0OzYG.kYOa	f	\N			\N	America/New_York	f	t	t	f	2026-03-20T16:26:34.172Z	2026-03-20T16:26:34.172Z	local	en	markdown	2026-03-24T19:47:11.491Z		
\.


--
-- Name: apiKeys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."apiKeys_id_seq"', 1, false);


--
-- Name: assetFolders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."assetFolders_id_seq"', 1, false);


--
-- Name: assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.assets_id_seq', 1, false);


--
-- Name: comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.comments_id_seq', 1, false);


--
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.groups_id_seq', 2, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.migrations_id_seq', 16, true);


--
-- Name: migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.migrations_lock_index_seq', 1, true);


--
-- Name: pageHistoryTags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."pageHistoryTags_id_seq"', 1, false);


--
-- Name: pageHistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."pageHistory_id_seq"', 1, false);


--
-- Name: pageLinks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."pageLinks_id_seq"', 1, false);


--
-- Name: pageTags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."pageTags_id_seq"', 1, false);


--
-- Name: pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.pages_id_seq', 2, true);


--
-- Name: tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.tags_id_seq', 1, false);


--
-- Name: userGroups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."userGroups_id_seq"', 2, true);


--
-- Name: userKeys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public."userKeys_id_seq"', 1, false);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: wiki
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: analytics analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_pkey PRIMARY KEY (key);


--
-- Name: apiKeys apiKeys_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."apiKeys"
    ADD CONSTRAINT "apiKeys_pkey" PRIMARY KEY (id);


--
-- Name: assetData assetData_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."assetData"
    ADD CONSTRAINT "assetData_pkey" PRIMARY KEY (id);


--
-- Name: assetFolders assetFolders_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."assetFolders"
    ADD CONSTRAINT "assetFolders_pkey" PRIMARY KEY (id);


--
-- Name: assets assets_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_pkey PRIMARY KEY (id);


--
-- Name: authentication authentication_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.authentication
    ADD CONSTRAINT authentication_pkey PRIMARY KEY (key);


--
-- Name: commentProviders commentProviders_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."commentProviders"
    ADD CONSTRAINT "commentProviders_pkey" PRIMARY KEY (key);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: editors editors_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.editors
    ADD CONSTRAINT editors_pkey PRIMARY KEY (key);


--
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: locales locales_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.locales
    ADD CONSTRAINT locales_pkey PRIMARY KEY (code);


--
-- Name: loggers loggers_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.loggers
    ADD CONSTRAINT loggers_pkey PRIMARY KEY (key);


--
-- Name: migrations_lock migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.migrations_lock
    ADD CONSTRAINT migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: navigation navigation_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.navigation
    ADD CONSTRAINT navigation_pkey PRIMARY KEY (key);


--
-- Name: pageHistoryTags pageHistoryTags_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistoryTags"
    ADD CONSTRAINT "pageHistoryTags_pkey" PRIMARY KEY (id);


--
-- Name: pageHistory pageHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistory"
    ADD CONSTRAINT "pageHistory_pkey" PRIMARY KEY (id);


--
-- Name: pageLinks pageLinks_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageLinks"
    ADD CONSTRAINT "pageLinks_pkey" PRIMARY KEY (id);


--
-- Name: pageTags pageTags_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTags"
    ADD CONSTRAINT "pageTags_pkey" PRIMARY KEY (id);


--
-- Name: pageTree pageTree_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTree"
    ADD CONSTRAINT "pageTree_pkey" PRIMARY KEY (id);


--
-- Name: pages pages_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_pkey PRIMARY KEY (id);


--
-- Name: renderers renderers_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.renderers
    ADD CONSTRAINT renderers_pkey PRIMARY KEY (key);


--
-- Name: searchEngines searchEngines_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."searchEngines"
    ADD CONSTRAINT "searchEngines_pkey" PRIMARY KEY (key);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (sid);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: storage storage_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.storage
    ADD CONSTRAINT storage_pkey PRIMARY KEY (key);


--
-- Name: tags tags_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_pkey PRIMARY KEY (id);


--
-- Name: tags tags_tag_unique; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.tags
    ADD CONSTRAINT tags_tag_unique UNIQUE (tag);


--
-- Name: userAvatars userAvatars_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userAvatars"
    ADD CONSTRAINT "userAvatars_pkey" PRIMARY KEY (id);


--
-- Name: userGroups userGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userGroups"
    ADD CONSTRAINT "userGroups_pkey" PRIMARY KEY (id);


--
-- Name: userKeys userKeys_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userKeys"
    ADD CONSTRAINT "userKeys_pkey" PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_providerkey_email_unique; Type: CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_providerkey_email_unique UNIQUE ("providerKey", email);


--
-- Name: pagelinks_path_localecode_index; Type: INDEX; Schema: public; Owner: wiki
--

CREATE INDEX pagelinks_path_localecode_index ON public."pageLinks" USING btree (path, "localeCode");


--
-- Name: sessions_expired_index; Type: INDEX; Schema: public; Owner: wiki
--

CREATE INDEX sessions_expired_index ON public.sessions USING btree (expired);


--
-- Name: assetFolders assetfolders_parentid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."assetFolders"
    ADD CONSTRAINT assetfolders_parentid_foreign FOREIGN KEY ("parentId") REFERENCES public."assetFolders"(id);


--
-- Name: assets assets_authorid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_authorid_foreign FOREIGN KEY ("authorId") REFERENCES public.users(id);


--
-- Name: assets assets_folderid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT assets_folderid_foreign FOREIGN KEY ("folderId") REFERENCES public."assetFolders"(id);


--
-- Name: comments comments_authorid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_authorid_foreign FOREIGN KEY ("authorId") REFERENCES public.users(id);


--
-- Name: comments comments_pageid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pageid_foreign FOREIGN KEY ("pageId") REFERENCES public.pages(id);


--
-- Name: pageHistory pagehistory_authorid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistory"
    ADD CONSTRAINT pagehistory_authorid_foreign FOREIGN KEY ("authorId") REFERENCES public.users(id);


--
-- Name: pageHistory pagehistory_editorkey_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistory"
    ADD CONSTRAINT pagehistory_editorkey_foreign FOREIGN KEY ("editorKey") REFERENCES public.editors(key);


--
-- Name: pageHistory pagehistory_localecode_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistory"
    ADD CONSTRAINT pagehistory_localecode_foreign FOREIGN KEY ("localeCode") REFERENCES public.locales(code);


--
-- Name: pageHistoryTags pagehistorytags_pageid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistoryTags"
    ADD CONSTRAINT pagehistorytags_pageid_foreign FOREIGN KEY ("pageId") REFERENCES public."pageHistory"(id) ON DELETE CASCADE;


--
-- Name: pageHistoryTags pagehistorytags_tagid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageHistoryTags"
    ADD CONSTRAINT pagehistorytags_tagid_foreign FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: pageLinks pagelinks_pageid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageLinks"
    ADD CONSTRAINT pagelinks_pageid_foreign FOREIGN KEY ("pageId") REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: pages pages_authorid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_authorid_foreign FOREIGN KEY ("authorId") REFERENCES public.users(id);


--
-- Name: pages pages_creatorid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_creatorid_foreign FOREIGN KEY ("creatorId") REFERENCES public.users(id);


--
-- Name: pages pages_editorkey_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_editorkey_foreign FOREIGN KEY ("editorKey") REFERENCES public.editors(key);


--
-- Name: pages pages_localecode_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.pages
    ADD CONSTRAINT pages_localecode_foreign FOREIGN KEY ("localeCode") REFERENCES public.locales(code);


--
-- Name: pageTags pagetags_pageid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTags"
    ADD CONSTRAINT pagetags_pageid_foreign FOREIGN KEY ("pageId") REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: pageTags pagetags_tagid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTags"
    ADD CONSTRAINT pagetags_tagid_foreign FOREIGN KEY ("tagId") REFERENCES public.tags(id) ON DELETE CASCADE;


--
-- Name: pageTree pagetree_localecode_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTree"
    ADD CONSTRAINT pagetree_localecode_foreign FOREIGN KEY ("localeCode") REFERENCES public.locales(code);


--
-- Name: pageTree pagetree_pageid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTree"
    ADD CONSTRAINT pagetree_pageid_foreign FOREIGN KEY ("pageId") REFERENCES public.pages(id) ON DELETE CASCADE;


--
-- Name: pageTree pagetree_parent_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."pageTree"
    ADD CONSTRAINT pagetree_parent_foreign FOREIGN KEY (parent) REFERENCES public."pageTree"(id) ON DELETE CASCADE;


--
-- Name: userGroups usergroups_groupid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userGroups"
    ADD CONSTRAINT usergroups_groupid_foreign FOREIGN KEY ("groupId") REFERENCES public.groups(id) ON DELETE CASCADE;


--
-- Name: userGroups usergroups_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userGroups"
    ADD CONSTRAINT usergroups_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: userKeys userkeys_userid_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public."userKeys"
    ADD CONSTRAINT userkeys_userid_foreign FOREIGN KEY ("userId") REFERENCES public.users(id);


--
-- Name: users users_defaulteditor_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_defaulteditor_foreign FOREIGN KEY ("defaultEditor") REFERENCES public.editors(key);


--
-- Name: users users_localecode_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_localecode_foreign FOREIGN KEY ("localeCode") REFERENCES public.locales(code);


--
-- Name: users users_providerkey_foreign; Type: FK CONSTRAINT; Schema: public; Owner: wiki
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_providerkey_foreign FOREIGN KEY ("providerKey") REFERENCES public.authentication(key);


--
-- PostgreSQL database dump complete
--

\unrestrict aCtPEEPC3d6vAsj1aAPCi0mV0bQGyzdjruwXBNUfAOyiUketlfPeay9gM3eGnEr

